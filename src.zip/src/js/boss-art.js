// ================= HÌNH VẼ 20 BOSS (mỗi con một thiết kế riêng, vẽ bằng canvas, quay mặt sang phải) =================
const TAU=Math.PI*2;
function _fs(X,f,s,lw){X.fillStyle=f;X.strokeStyle=s;X.lineWidth=lw;X.fill();X.stroke()}
function _eye(X,x,y,s,look,col){X.fillStyle=col||'#fff';X.beginPath();X.arc(x,y,s,0,TAU);X.fill();X.fillStyle='#1b1230';X.beginPath();X.arc(x+(look||0)*s*.3,y,s*.55,0,TAU);X.fill();X.fillStyle='#fff';X.beginPath();X.arc(x+(look||0)*s*.3-s*.2,y-s*.22,s*.2,0,TAU);X.fill()}
function _tent(X,x0,y0,dx,dy,len,t,ph,amp,wid,col,N){   // xúc tu uốn sóng
  N=N||10;X.strokeStyle=col;X.lineCap='round';X.lineJoin='round';const nx=-dy,ny=dx;X.beginPath();X.moveTo(x0,y0);
  for(let i=1;i<=N;i++){const u=i/N,w=Math.sin(t*2.4-u*4+ph)*amp*u;X.lineTo(x0+dx*len*u+nx*w,y0+dy*len*u+ny*w)}
  X.lineWidth=wid;X.stroke()}
function _grad(X,x,y,r0,r1,a,b){const g=X.createRadialGradient(x,y,r0,x,y,r1);g.addColorStop(0,a);g.addColorStop(1,b);return g}
function _spikes(X,n,r0,r1,w,rot,col){X.fillStyle=col;for(let i=0;i<n;i++){const a=rot+i/n*TAU;X.beginPath();X.moveTo(Math.cos(a-w)*r0,Math.sin(a-w)*r0);X.lineTo(Math.cos(a)*r1,Math.sin(a)*r1);X.lineTo(Math.cos(a+w)*r0,Math.sin(a+w)*r0);X.closePath();X.fill()}}
function _chain(X,n,fn){for(let i=0;i<n;i++)fn(i/(n-1||1),i)}   // dải thân rắn/lươn: fn(u,i)
const ART=[
 // 0 Sứa Gai Lục
 (X,r,t,o)=>{const[A,B,G]=o.c,p=Math.sin(t*3),w=r*(1+.07*p),h=r*(.95-.08*p);
  for(let i=0;i<7;i++)_tent(X,(i-3)*w*.27,r*.1,0,1,r*(1.2+.25*(i%2)),t,i*.9,r*.16,r*.07,'rgba(125,255,168,.7)');
  X.beginPath();X.moveTo(-w,0);X.bezierCurveTo(-w,-h*1.35,w,-h*1.35,w,0);for(let i=0;i<6;i++){X.quadraticCurveTo(w-(i+.5)*w/3,r*.24,w-(i+1)*w/3,0)}X.closePath();_fs(X,_grad(X,0,-h*.4,r*.1,w,'rgba(230,255,238,.95)',A),B,r*.05);
  X.fillStyle=B;for(let i=1;i<8;i++){const a=Math.PI+i/8*Math.PI,x=Math.cos(a)*w*.95,y=Math.sin(a)*h*1.0-h*.02;X.beginPath();X.moveTo(x-r*.06,y+r*.04);X.lineTo(x*1.12,y*1.18);X.lineTo(x+r*.06,y+r*.04);X.fill()}
  X.fillStyle='rgba(255,255,255,.55)';for(let i=0;i<4;i++){X.beginPath();X.arc(Math.sin(t+i*1.7)*w*.5,-h*.5+Math.cos(t*1.3+i)*h*.2,r*.05,0,TAU);X.fill()}
  _eye(X,-w*.3,-h*.32,r*.13,0);_eye(X,w*.3,-h*.32,r*.13,0)},
 // 1 Nóc Gai Phồng
 (X,r,t,o)=>{const[A,B,G]=o.c,k=1+.1*Math.sin(t*2.6),R=r*k;
  _spikes(X,16,R*.9,R*1.32,.09,t*.15,B);
  X.beginPath();X.moveTo(-R*.9,0);X.lineTo(-R*1.5,-R*.5+Math.sin(t*6)*R*.1);X.lineTo(-R*1.45,R*.5+Math.sin(t*6)*R*.1);X.closePath();_fs(X,B,B,2);
  X.beginPath();X.arc(0,0,R,0,TAU);_fs(X,_grad(X,-R*.3,-R*.35,R*.1,R*1.1,'#fff3c4',A),B,r*.05);
  X.fillStyle='rgba(255,255,255,.7)';X.beginPath();X.ellipse(0,R*.5,R*.62,R*.34,0,0,TAU);X.fill();
  X.beginPath();X.ellipse(-R*.05,R*.15,R*.3,R*.14,Math.sin(t*8)*.6,0,TAU);_fs(X,B,B,1);
  _eye(X,R*.38,-R*.22,R*.26,1);X.strokeStyle=B;X.lineWidth=r*.05;X.beginPath();X.arc(R*.6,R*.18,R*.1,0,TAU);X.stroke()},
 // 2 Cua Hoàng Đỏ
 (X,r,t,o)=>{const[A,B,G]=o.c;
  for(let s=-1;s<=1;s+=2)for(let i=0;i<3;i++){const a=.5+i*.45,sw=Math.sin(t*5+i*2+s)*.18;X.strokeStyle=B;X.lineWidth=r*.09;X.lineCap='round';X.beginPath();X.moveTo(s*r*.5,r*.15);X.lineTo(s*r*(1.0+i*.08),r*(.1+i*.28)+sw*r);X.lineTo(s*r*(1.1+i*.05),r*(.55+i*.2));X.stroke()}
  for(let s=-1;s<=1;s+=2){const cl=Math.sin(t*3+s)*.35,ax=s*r*.9,ay=-r*.45;X.strokeStyle=A;X.lineWidth=r*.14;X.beginPath();X.moveTo(s*r*.5,-r*.1);X.lineTo(ax,ay);X.stroke();
   X.save();X.translate(ax,ay);X.rotate(s*(.35+cl*.3));for(let k=-1;k<=1;k+=2){X.save();X.rotate(k*(.28+Math.max(0,cl)*.3));X.beginPath();X.moveTo(0,0);X.quadraticCurveTo(s*r*.35,-r*.5,s*r*.1,-r*.75);X.quadraticCurveTo(-s*r*.05,-r*.5,-s*r*.12,-r*.1);X.closePath();_fs(X,A,B,r*.05);X.restore()}X.restore()}
  X.beginPath();X.ellipse(0,0,r*.95,r*.7,0,0,TAU);_fs(X,_grad(X,-r*.2,-r*.3,r*.1,r,'#ff9d8a',A),B,r*.06);
  X.fillStyle=G;X.strokeStyle=B;X.lineWidth=r*.04;X.beginPath();X.moveTo(-r*.38,-r*.55);X.lineTo(-r*.3,-r*1.02);X.lineTo(-r*.13,-r*.7);X.lineTo(0,-r*1.15);X.lineTo(r*.13,-r*.7);X.lineTo(r*.3,-r*1.02);X.lineTo(r*.38,-r*.55);X.closePath();X.fill();X.stroke();
  for(let s=-1;s<=1;s+=2){X.strokeStyle=B;X.lineWidth=r*.05;X.beginPath();X.moveTo(s*r*.2,-r*.45);X.lineTo(s*r*.22,-r*.62);X.stroke();_eye(X,s*r*.22,-r*.66,r*.12,s)}
  X.strokeStyle=B;X.lineWidth=r*.05;X.beginPath();X.arc(0,r*.12,r*.2,.15*Math.PI,.85*Math.PI);X.stroke()},
 // 3 Mực Mặc Tối
 (X,r,t,o)=>{const[A,B,G]=o.c;
  for(let i=0;i<8;i++){const a=(i-3.5)*.22;_tent(X,r*.55,(i-3.5)*r*.11,Math.cos(a),Math.sin(a),r*1.15,t,i,r*.18,r*.085,i%2?A:B,9)}
  X.beginPath();X.moveTo(-r*1.5,0);X.quadraticCurveTo(-r*.5,-r*.82,r*.7,-r*.45);X.quadraticCurveTo(r*.95,0,r*.7,r*.45);X.quadraticCurveTo(-r*.5,r*.82,-r*1.5,0);_fs(X,_grad(X,0,-r*.2,r*.1,r*1.5,'#e6d8ff',A),B,r*.05);
  X.beginPath();X.moveTo(-r*1.5,0);X.lineTo(-r*1.05,-r*.9+Math.sin(t*5)*r*.08);X.lineTo(-r*.7,-r*.35);X.lineTo(-r*.7,r*.35);X.lineTo(-r*1.05,r*.9-Math.sin(t*5)*r*.08);X.closePath();_fs(X,B,B,2);
  X.fillStyle=G;for(let i=0;i<5;i++){X.beginPath();X.arc(-r*.6+i*r*.25,-r*.12+Math.sin(i)*r*.05,r*.05,0,TAU);X.fill()}
  _eye(X,r*.38,-r*.18,r*.22,1,'#fff7b0');X.fillStyle='rgba(20,10,40,.7)';X.beginPath();X.arc(r*.38,-r*.18,r*.08,0,TAU);X.fill()},
 // 4 Mập Trắng Hung Tợn
 (X,r,t,o)=>{const[A,B,G]=o.c,sw=Math.sin(t*5)*r*.12;
  X.beginPath();X.moveTo(-r*1.5,sw);X.lineTo(-r*1.9,-r*.55+sw*2);X.quadraticCurveTo(-r*1.65,sw,-r*1.9,r*.65+sw*2);X.closePath();_fs(X,A,B,r*.05);
  X.beginPath();X.moveTo(r*1.45,r*.05);X.bezierCurveTo(r*.9,-r*.75,-r*.8,-r*.78,-r*1.5,sw);X.bezierCurveTo(-r*.8,r*.55,r*.7,r*.62,r*1.45,r*.05);X.closePath();_fs(X,_grad(X,0,-r*.5,r*.1,r*1.5,A,'#6b7b92'),B,r*.05);
  X.beginPath();X.moveTo(r*1.4,r*.1);X.bezierCurveTo(r*.8,r*.5,-r*.6,r*.5,-r*1.4,sw*.8);X.bezierCurveTo(-r*.4,r*.62,r*.8,r*.66,r*1.4,r*.1);X.fillStyle='#f4f8ff';X.fill();
  X.beginPath();X.moveTo(-r*.2,-r*.72);X.lineTo(-r*.55,-r*1.35);X.lineTo(r*.3,-r*.65);X.closePath();_fs(X,A,B,r*.05);
  X.beginPath();X.moveTo(r*.1,r*.35);X.lineTo(-r*.25,r*.95+Math.sin(t*5)*r*.05);X.lineTo(r*.45,r*.4);X.closePath();_fs(X,A,B,r*.05);
  X.strokeStyle=B;X.lineWidth=r*.04;for(let i=0;i<3;i++){X.beginPath();X.moveTo(r*.35+i*r*.1,-r*.2);X.quadraticCurveTo(r*.28+i*r*.1,r*.02,r*.35+i*r*.1,r*.25);X.stroke()}
  X.fillStyle='#fff';const m=r*.14*(1+Math.max(0,o.cast)*.8);X.beginPath();X.moveTo(r*.45,r*.18);X.lineTo(r*1.35,r*.14);for(let i=0;i<8;i++){X.lineTo(r*1.3-i*r*.12,r*.14+(i%2?1:0)*m*.8+m*.2)}X.closePath();X.fill();
  _eye(X,r*.82,-r*.22,r*.11,1,'#ff4d4d')},
 // 5 Lươn Điện Tím
 (X,r,t,o)=>{const[A,B,G]=o.c;
  X.lineCap='round';_chain(X,18,(u)=>{const x=r*(1.3-u*3.3),y=Math.sin(t*4-u*7)*r*.38*(.4+u),w=r*(.34-u*.17);X.fillStyle=u%.2<.1?A:B;X.strokeStyle='#4a3a00';X.lineWidth=2;X.beginPath();X.arc(x,y,w,0,TAU);X.fill();X.stroke()});
  X.strokeStyle=G;X.lineWidth=r*.04;for(let k=0;k<4;k++){X.beginPath();let x=r*(1.1-Math.random()*3),y=Math.sin(t*4-(1.3-x/r)/3.3*7)*r*.3;X.moveTo(x,y);for(let i=0;i<4;i++){x+=R(-r*.2,r*.2);y+=R(-r*.28,r*.28);X.lineTo(x,y)}X.stroke()}
  X.beginPath();X.ellipse(r*1.4,0,r*.42,r*.3,0,0,TAU);_fs(X,A,B,r*.05);_eye(X,r*1.52,-r*.1,r*.11,1,'#fff');
  X.fillStyle=B;X.beginPath();X.arc(r*1.7,r*.06,r*.05,0,TAU);X.fill();
  if(o.cast>0){X.globalAlpha=o.cast;X.fillStyle=G;X.beginPath();X.arc(r*1.8,0,r*(.15+o.cast*.3),0,TAU);X.fill();X.globalAlpha=1}},
 // 6 Nhím Biển Độc
 (X,r,t,o)=>{const[A,B,G]=o.c;X.lineCap='round';
  for(let i=0;i<30;i++){const a=i/30*TAU+t*.12,L=r*(1.45+.15*Math.sin(t*3+i*1.7)),w=i%2?r*.05:r*.075;X.strokeStyle=B;X.lineWidth=w;X.beginPath();X.moveTo(Math.cos(a)*r*.7,Math.sin(a)*r*.7);X.lineTo(Math.cos(a)*L,Math.sin(a)*L);X.stroke();X.fillStyle=G;X.beginPath();X.arc(Math.cos(a)*L,Math.sin(a)*L,w*.7,0,TAU);X.fill()}
  X.beginPath();X.arc(0,0,r*.82,0,TAU);_fs(X,_grad(X,-r*.25,-r*.3,r*.1,r*.9,'#c7a0ff',A),B,r*.05);
  X.fillStyle='rgba(125,255,107,.55)';for(let i=0;i<6;i++){X.beginPath();X.arc(Math.cos(i*1.1)*r*.5,Math.sin(i*1.7)*r*.45,r*.07,0,TAU);X.fill()}
  _eye(X,-r*.25,-r*.1,r*.2,1,'#d9ff7a');_eye(X,r*.25,-r*.1,r*.2,1,'#d9ff7a');X.strokeStyle='#1b0a33';X.lineWidth=r*.07;X.beginPath();X.moveTo(-r*.5,-r*.38);X.lineTo(-r*.05,-r*.24);X.moveTo(r*.5,-r*.38);X.lineTo(r*.05,-r*.24);X.stroke();
  X.beginPath();X.moveTo(-r*.28,r*.34);for(let i=0;i<5;i++)X.lineTo(-r*.28+(i+1)*r*.112,r*.34+(i%2?-1:1)*r*.09);X.stroke()},
 // 7 Đuối Quỷ Bão Tố
 (X,r,t,o)=>{const[A,B,G]=o.c,f=Math.sin(t*3)*r*.35;
  _tent(X,-r*.7,0,-1,0,r*1.8,t,0,r*.35,r*.07,B,12);
  X.beginPath();X.moveTo(r*1.1,0);X.quadraticCurveTo(r*.4,-r*.5,-r*.2,-r*1.3-f);X.quadraticCurveTo(-r*.75,-r*.8,-r*.8,0);X.quadraticCurveTo(-r*.75,r*.8,-r*.2,r*1.3+f);X.quadraticCurveTo(r*.4,r*.5,r*1.1,0);X.closePath();_fs(X,_grad(X,0,-r*.3,r*.1,r*1.4,'#9fd0ff',A),B,r*.05);
  X.fillStyle='rgba(255,255,255,.75)';X.beginPath();X.ellipse(r*.05,0,r*.5,r*.35,0,0,TAU);X.fill();
  X.strokeStyle=G;X.lineWidth=r*.03;for(let k=-1;k<=1;k+=2){X.beginPath();X.moveTo(-r*.1,k*r*.2);X.quadraticCurveTo(-r*.35,k*r*.7,-r*.15,k*(r*1.1+f*.8));X.stroke()}
  X.fillStyle=B;for(let k=-1;k<=1;k+=2){X.beginPath();X.moveTo(r*.95,k*r*.12);X.quadraticCurveTo(r*1.35,k*r*.4,r*1.2,k*r*.62);X.quadraticCurveTo(r*1.05,k*r*.3,r*.88,k*r*.2);X.fill()}
  _eye(X,r*.6,-r*.2,r*.11,1,'#ffe45e');_eye(X,r*.6,r*.2,r*.11,1,'#ffe45e')},
 // 8 Lồng Đèn Âm Phủ
 (X,r,t,o)=>{const[A,B,G]=o.c,op=.5+.5*Math.sin(t*3)+Math.max(0,o.cast);
  X.beginPath();X.moveTo(-r*1.2,0);X.quadraticCurveTo(-r*1.5,-r*.5,-r*1.6,-r*.1);X.quadraticCurveTo(-r*1.5,r*.45,-r*1.2,r*.1);_fs(X,A,B,r*.04);
  X.strokeStyle=B;X.lineWidth=r*.07;X.beginPath();X.moveTo(r*.1,-r*.85);X.bezierCurveTo(r*.5,-r*1.8,r*1.3,-r*1.5,r*1.45,-r*.7+Math.sin(t*2)*r*.1);X.stroke();
  const lx=r*1.45,ly=-r*.7+Math.sin(t*2)*r*.1,gl=_grad(X,lx,ly,0,r*(.9+op*.4),'rgba(255,255,255,.95)','rgba(159,246,255,0)');X.fillStyle=gl;X.beginPath();X.arc(lx,ly,r*(.9+op*.4),0,TAU);X.fill();X.fillStyle=G;X.beginPath();X.arc(lx,ly,r*.17,0,TAU);X.fill();
  X.beginPath();X.arc(0,0,r*.95,0,TAU);_fs(X,_grad(X,-r*.3,-r*.4,r*.1,r,'#3a5fa8',A),B,r*.05);
  const m=r*(.25+.2*Math.max(0,Math.sin(t*2.2))+Math.max(0,o.cast)*.2);X.fillStyle='#0a0f26';X.beginPath();X.moveTo(r*.15,-m*.2);X.quadraticCurveTo(r*.85,-m*1.4,r*1.0,-m*.3);X.quadraticCurveTo(r*1.0,m*1.3,r*.15,m*1.1);X.closePath();X.fill();
  X.fillStyle='#e8f6ff';for(let i=0;i<7;i++){const x=r*.28+i*r*.1;X.beginPath();X.moveTo(x,-m*.3-i*.5);X.lineTo(x+r*.04,m*.2);X.lineTo(x-r*.04,-m*.3);X.fill();X.beginPath();X.moveTo(x,m*.95);X.lineTo(x+r*.04,m*.3);X.lineTo(x-r*.04,m*.9);X.fill()}
  _eye(X,r*.1,-r*.45,r*.15,1,'#9ff6ff')},
 // 9 Bạch Tuộc Hư Ảnh
 (X,r,t,o)=>{const[A,B,G]=o.c;
  for(let i=0;i<8;i++){const a=Math.PI*.1+i/7*Math.PI*.8,x0=Math.cos(a)*r*.6,y0=Math.sin(a)*r*.5+r*.2;X.save();_tent(X,x0,y0,Math.cos(a)*.7,Math.sin(a)*.7+.5,r*1.5,t,i*.8,r*.4,r*.17,i%2?A:B,12);X.restore();
   X.fillStyle='rgba(255,220,255,.7)';for(let k=1;k<5;k++){const u=k/5,w=Math.sin(t*2.4-u*4+i*.8)*r*.4*u*.7;X.beginPath();X.arc(x0+Math.cos(a)*.7*r*1.5*u-(Math.sin(a)*.7+.5)*w*.3,y0+(Math.sin(a)*.7+.5)*r*1.5*u*.9,r*.035,0,TAU);X.fill()}}
  X.beginPath();X.moveTo(-r*.8,r*.25);X.bezierCurveTo(-r*1.0,-r*1.6,r*1.1,-r*1.6,r*.8,r*.25);X.bezierCurveTo(r*.5,r*.55,-r*.5,r*.55,-r*.8,r*.25);_fs(X,_grad(X,0,-r*.7,r*.1,r*1.2,'#f3c9ff',A),B,r*.05);
  X.fillStyle='rgba(255,255,255,.35)';for(let i=0;i<6;i++){X.beginPath();X.arc(Math.cos(i*2.1)*r*.35,-r*.7+Math.sin(i*1.3)*r*.3,r*.06,0,TAU);X.fill()}
  for(let s=-1;s<=1;s+=2){X.fillStyle='#fff7a8';X.beginPath();X.arc(s*r*.32,-r*.05,r*.2,0,TAU);X.fill();X.fillStyle='#1b0a33';X.beginPath();X.ellipse(s*r*.35,-r*.05,r*.045,r*.14,0,0,TAU);X.fill()}},
 // 10 Rùa Đá Cổ Đại
 (X,r,t,o)=>{const[A,B,G]=o.c,sw=Math.sin(t*2.5)*.3;
  for(const[sx,sy,s]of[[-.5,.5,1],[.5,.5,-1]]){X.save();X.translate(sx*r,sy*r);X.rotate(sw*s*.8);X.beginPath();X.ellipse(0,r*.3,r*.2,r*.46,s*.3,0,TAU);_fs(X,'#7f9a7a',B,r*.04);X.restore()}
  X.beginPath();X.ellipse(-r*1.0,r*.05,r*.3,r*.14,.2,0,TAU);_fs(X,'#7f9a7a',B,r*.04);
  X.beginPath();X.ellipse(r*1.15,-r*.2,r*.38,r*.3,0,0,TAU);_fs(X,'#7f9a7a',B,r*.05);_eye(X,r*1.28,-r*.3,r*.09,1,'#ffe45e');X.strokeStyle=B;X.lineWidth=r*.04;X.beginPath();X.arc(r*1.3,-r*.1,r*.1,.2,2.6);X.stroke();
  X.beginPath();X.moveTo(-r*1.05,r*.3);X.bezierCurveTo(-r*1.1,-r*1.2,r*1.1,-r*1.2,r*1.05,r*.3);X.closePath();_fs(X,_grad(X,-r*.2,-r*.7,r*.1,r*1.2,'#b6c7b0',A),B,r*.06);
  X.strokeStyle=B;X.lineWidth=r*.04;for(let i=-2;i<=2;i++){X.beginPath();X.moveTo(i*r*.38,-r*.92+Math.abs(i)*r*.18);X.lineTo(i*r*.3,r*.25);X.stroke()}X.beginPath();X.moveTo(-r*.95,-r*.2);X.quadraticCurveTo(0,-r*.55,r*.95,-r*.2);X.stroke();
  X.fillStyle=G;X.globalAlpha=.6;for(let i=0;i<5;i++){X.beginPath();X.arc(-r*.6+i*r*.3,-r*.6+Math.sin(i*2.3)*r*.2,r*.1,0,TAU);X.fill()}X.globalAlpha=1},
 // 11 Hải Mã Rồng
 (X,r,t,o)=>{const[A,B,G]=o.c;
  _chain(X,12,(u)=>{const x=-r*.3*u+Math.sin(u*3+t*2)*r*.15-r*.2,y=r*(.1+u*1.5),w=r*(.46-u*.32);X.fillStyle=u%.18<.09?A:B;X.strokeStyle=B;X.lineWidth=2;X.beginPath();X.arc(x-u*r*.2,y,w,0,TAU);X.fill();X.stroke()});
  X.beginPath();X.ellipse(0,-r*.05,r*.62,r*.82,.1,0,TAU);_fs(X,_grad(X,-r*.2,-r*.4,r*.1,r,'#ffd9b3',A),B,r*.05);
  X.fillStyle=G;for(let i=0;i<6;i++){const y=-r*.7+i*r*.28,w=r*(.2+Math.sin(t*5+i)*.05);X.beginPath();X.moveTo(-r*.55,y);X.quadraticCurveTo(-r*.95-w,y+r*.05,-r*.62,y+r*.22);X.fill()}
  X.beginPath();X.moveTo(r*.3,-r*.62);X.lineTo(r*1.25,-r*.62);X.lineTo(r*1.25,-r*.38);X.lineTo(r*.4,-r*.28);X.closePath();_fs(X,A,B,r*.05);
  X.strokeStyle=B;X.lineWidth=r*.05;X.beginPath();X.moveTo(r*.1,-r*.85);X.lineTo(r*.0,-r*1.35);X.moveTo(-r*.15,-r*.8);X.lineTo(-r*.35,-r*1.25);X.moveTo(r*.3,-r*.8);X.lineTo(r*.4,-r*1.25);X.stroke();
  _eye(X,r*.22,-r*.5,r*.15,1,'#fff');
  if(o.cast>0){X.fillStyle=G;X.globalAlpha=o.cast;X.beginPath();X.arc(r*1.35,-r*.5,r*.3*o.cast+r*.05,0,TAU);X.fill();X.globalAlpha=1}},
 // 12 Anh Vũ Hố Đen
 (X,r,t,o)=>{const[A,B,G]=o.c;
  for(let i=0;i<9;i++)_tent(X,r*.45,-r*.1+(i-4)*r*.1,.9,(i-4)*.12,r*1.0,t,i,r*.14,r*.07,'#ffd1e6',8);
  X.save();X.rotate(Math.sin(t)*.05);X.beginPath();X.moveTo(r*.45,-r*.8);X.bezierCurveTo(-r*.8,-r*1.4,-r*1.35,r*.3,-r*.3,r*.95);X.bezierCurveTo(r*.3,r*1.0,r*.65,r*.55,r*.45,-r*.1);X.closePath();_fs(X,_grad(X,-r*.3,-r*.2,r*.1,r*1.4,'#ffe6f4',A),B,r*.06);
  X.strokeStyle=B;X.lineWidth=r*.035;X.beginPath();for(let a=0;a<14;a+=.1){const k=Math.exp(-a*.2)*r*.85,x=-r*.15+Math.cos(a+Math.PI*.5)*k*1.0,y=r*.05+Math.sin(a+Math.PI*.5)*k*.92;a?X.lineTo(x,y):X.moveTo(x,y)}X.stroke();
  X.fillStyle='rgba(255,120,200,.35)';for(let i=0;i<4;i++){X.beginPath();X.ellipse(-r*.5-i*r*.1,-r*.45+i*r*.28,r*.3,r*.06,.3,0,TAU);X.fill()}X.restore();
  X.fillStyle=G;X.globalAlpha=.5+.5*Math.sin(t*3);X.beginPath();X.arc(-r*.2,r*.05,r*.18,0,TAU);X.fill();X.globalAlpha=1;
  _eye(X,r*.55,-r*.15,r*.15,1,'#fff')},
 // 13 Cưa Sắt Tử Thần
 (X,r,t,o)=>{const[A,B,G]=o.c,sw=Math.sin(t*6)*r*.1;
  X.beginPath();X.moveTo(-r*1.2,sw);X.lineTo(-r*1.7,-r*.55);X.lineTo(-r*1.5,sw);X.lineTo(-r*1.65,r*.45);X.closePath();_fs(X,A,B,r*.05);
  X.beginPath();X.moveTo(r*.9,0);X.bezierCurveTo(r*.5,-r*.62,-r*.6,-r*.6,-r*1.25,sw);X.bezierCurveTo(-r*.6,r*.5,r*.5,r*.5,r*.9,0);_fs(X,_grad(X,0,-r*.5,r*.1,r*1.4,'#d5e2ee',A),B,r*.05);
  X.beginPath();X.moveTo(r*.85,-r*.1);X.lineTo(r*2.35,-r*.04);X.lineTo(r*2.35,r*.04);X.lineTo(r*.85,r*.14);X.closePath();_fs(X,'#c7d4e0',B,r*.04);
  X.fillStyle=G;for(let i=0;i<9;i++){const x=r*1.0+i*r*.15;X.beginPath();X.moveTo(x,-r*.08);X.lineTo(x+r*.05,-r*.27);X.lineTo(x+r*.1,-r*.07);X.fill();X.beginPath();X.moveTo(x,r*.13);X.lineTo(x+r*.05,r*.32);X.lineTo(x+r*.1,r*.12);X.fill()}
  X.beginPath();X.moveTo(-r*.1,-r*.55);X.lineTo(-r*.5,-r*1.15);X.lineTo(r*.2,-r*.5);X.closePath();_fs(X,A,B,r*.05);X.beginPath();X.moveTo(r*.1,r*.3);X.lineTo(-r*.3,r*.85);X.lineTo(r*.4,r*.32);X.closePath();_fs(X,A,B,r*.05);
  _eye(X,r*.5,-r*.17,r*.13,1,'#ff8a4d');X.strokeStyle=B;X.lineWidth=r*.03;for(let i=0;i<3;i++){X.beginPath();X.moveTo(r*.05+i*r*.09,-r*.15);X.lineTo(r*.0+i*r*.09,r*.2);X.stroke()}},
 // 14 Sư Tử Biển Độc
 (X,r,t,o)=>{const[A,B,G]=o.c;
  for(let i=0;i<13;i++){const u=i/12,a=-Math.PI*.95+u*Math.PI*.9+Math.sin(t*2+i)*.04,L=r*(1.45+.35*Math.sin(u*3.1));X.strokeStyle=i%2?'#fff':A;X.lineWidth=r*.07;X.lineCap='round';X.beginPath();X.moveTo(Math.cos(a)*r*.4,Math.sin(a)*r*.35);X.lineTo(Math.cos(a)*L,Math.sin(a)*L);X.stroke();X.fillStyle=G;X.beginPath();X.arc(Math.cos(a)*L,Math.sin(a)*L,r*.05,0,TAU);X.fill()}
  for(let i=0;i<7;i++){const a=Math.PI*.15+i/6*Math.PI*.6,L=r*(1.1+Math.sin(t*3+i)*.08);X.strokeStyle=i%2?'#fff':A;X.lineWidth=r*.08;X.beginPath();X.moveTo(r*.2,r*.1);X.lineTo(r*.2+Math.cos(a)*L*.8,r*.1+Math.sin(a)*L);X.stroke()}
  X.beginPath();X.moveTo(-r*1.3,0);X.lineTo(-r*1.9,-r*.5);X.lineTo(-r*1.7,0);X.lineTo(-r*1.9,r*.5);X.closePath();_fs(X,A,B,r*.04);
  X.beginPath();X.ellipse(0,0,r*1.1,r*.62,0,0,TAU);_fs(X,'#fff0e8',B,r*.05);X.save();X.clip();X.fillStyle=A;for(let i=-3;i<=3;i++){X.fillRect(i*r*.3-r*.08,-r,r*.16,r*2)}X.restore();X.beginPath();X.ellipse(0,0,r*1.1,r*.62,0,0,TAU);X.stroke();
  _eye(X,r*.72,-r*.15,r*.13,1,'#ffd24d');X.strokeStyle=B;X.lineWidth=r*.04;X.beginPath();X.arc(r*1.0,r*.14,r*.09,0,Math.PI);X.stroke()},
 // 15 Thủy Quái Độc Nhãn
 (X,r,t,o)=>{const[A,B,G]=o.c,b=Math.sin(t*3)*r*.04;
  for(let s=-1;s<=1;s+=2){X.strokeStyle=B;X.lineWidth=r*.13;X.lineCap='round';X.beginPath();X.moveTo(s*r*.75,r*.1);X.quadraticCurveTo(s*r*1.15,r*.2+b,s*r*1.1,r*.6);X.stroke();X.fillStyle=A;X.beginPath();X.arc(s*r*1.1,r*.65,r*.17,0,TAU);X.fill();X.stroke()}
  X.beginPath();X.moveTo(-r*.95,r*.55);X.bezierCurveTo(-r*1.15,-r*1.1+b,r*1.15,-r*1.1+b,r*.95,r*.55);X.bezierCurveTo(r*.5,r*.85,-r*.5,r*.85,-r*.95,r*.55);_fs(X,_grad(X,-r*.2,-r*.5,r*.1,r*1.3,'#c8ffd9',A),B,r*.06);
  X.fillStyle=B;for(const[x,h]of[[-.55,.5],[0,.65],[.55,.5]]){X.beginPath();X.moveTo((x-.12)*r,-r*.85);X.lineTo(x*r,-r*(.85+h*.5));X.lineTo((x+.12)*r,-r*.85);X.fill()}
  X.fillStyle='#fff';X.beginPath();X.ellipse(0,-r*.2,r*.52,r*.46,0,0,TAU);X.fill();X.strokeStyle=B;X.lineWidth=r*.04;X.stroke();
  const lk=o.look||1,ix=lk*r*.12;X.fillStyle=G;X.beginPath();X.arc(ix,-r*.2,r*.28+o.cast*r*.08,0,TAU);X.fill();X.fillStyle='#09221a';X.beginPath();X.arc(ix+lk*r*.03,-r*.2,r*.13,0,TAU);X.fill();X.fillStyle='#fff';X.beginPath();X.arc(ix-r*.07,-r*.28,r*.05,0,TAU);X.fill();
  X.fillStyle='#0b2a20';X.beginPath();X.moveTo(-r*.5,r*.35);X.quadraticCurveTo(0,r*.75,r*.5,r*.35);X.quadraticCurveTo(0,r*.5,-r*.5,r*.35);X.fill();X.fillStyle='#fff';for(let i=0;i<6;i++){X.beginPath();X.moveTo(-r*.4+i*r*.16,r*.42);X.lineTo(-r*.34+i*r*.16,r*.58);X.lineTo(-r*.28+i*r*.16,r*.42);X.fill()}},
 // 16 Kraken Vực Thẳm
 (X,r,t,o)=>{const[A,B,G]=o.c;
  for(let i=0;i<7;i++){const a=Math.PI*.12+i/6*Math.PI*.76,dx=Math.cos(a)*.9-.1,dy=Math.sin(a);_tent(X,Math.cos(a)*r*.55,Math.sin(a)*r*.4+r*.1,dx,dy,r*1.9,t,i*.7,r*.55,r*.25,i%2?B:A,14);
   _tent(X,Math.cos(a)*r*.55,Math.sin(a)*r*.4+r*.1,dx,dy,r*1.9,t,i*.7,r*.55,r*.1,'rgba(122,255,238,.35)',14)}
  X.beginPath();X.moveTo(-r*1.0,r*.3);X.bezierCurveTo(-r*1.3,-r*1.9,r*1.3,-r*1.9,r*1.0,r*.3);X.bezierCurveTo(r*.5,r*.8,-r*.5,r*.8,-r*1.0,r*.3);_fs(X,_grad(X,0,-r*.8,r*.1,r*1.5,'#7fe0d4',A),B,r*.06);
  X.strokeStyle=B;X.lineWidth=r*.05;for(let i=-2;i<=2;i++){X.beginPath();X.moveTo(i*r*.25,-r*1.35+Math.abs(i)*r*.1);X.quadraticCurveTo(i*r*.4,-r*.5,i*r*.3,r*.3);X.stroke()}
  X.fillStyle=G;X.globalAlpha=.7+.3*Math.sin(t*3);for(let s=-1;s<=1;s+=2){X.beginPath();X.ellipse(s*r*.38,-r*.15,r*.22,r*.12,s*.3,0,TAU);X.fill()}X.globalAlpha=1;X.fillStyle='#04202a';for(let s=-1;s<=1;s+=2){X.beginPath();X.ellipse(s*r*.38,-r*.15,r*.05,r*.1,0,0,TAU);X.fill()}
  X.fillStyle='#062a33';X.beginPath();X.ellipse(0,r*.4,r*.28,r*.14,0,0,TAU);X.fill()},
 // 17 Mập Ma Lưỡi Hái
 (X,r,t,o)=>{const[A,B,G]=o.c,sw=Math.sin(t*5)*r*.1;X.globalAlpha=.78+.12*Math.sin(t*4);
  X.beginPath();X.moveTo(-r*1.3,sw);X.lineTo(-r*1.95,-r*.8+sw*2);X.lineTo(-r*1.65,sw);X.lineTo(-r*1.9,r*.75+sw*2);X.closePath();_fs(X,'rgba(168,240,255,.45)',B,r*.04);
  X.beginPath();X.moveTo(r*1.4,r*.05);X.bezierCurveTo(r*.9,-r*.7,-r*.7,-r*.7,-r*1.3,sw);X.bezierCurveTo(-r*.7,r*.55,r*.8,r*.6,r*1.4,r*.05);X.closePath();_fs(X,_grad(X,0,-r*.3,r*.1,r*1.4,'rgba(224,255,255,.7)','rgba(80,170,200,.45)'),B,r*.04);
  X.strokeStyle='rgba(38,96,110,.8)';X.lineWidth=r*.04;for(let i=0;i<6;i++){X.beginPath();X.moveTo(-r*.8+i*r*.28,-r*.4);X.quadraticCurveTo(-r*.7+i*r*.28,r*.0,-r*.8+i*r*.28,r*.35);X.stroke()}X.beginPath();X.moveTo(-r*1.1,sw*.7);X.lineTo(r*.7,r*.0);X.stroke();
  X.beginPath();X.moveTo(-r*.1,-r*.62);X.lineTo(-r*.7,-r*1.4);X.quadraticCurveTo(-r*.3,-r*.95,r*.35,-r*.55);X.closePath();_fs(X,'rgba(168,240,255,.5)',B,r*.04);
  X.fillStyle='#0c2630';X.beginPath();X.ellipse(r*.95,-r*.12,r*.2,r*.17,0,0,TAU);X.fill();X.fillStyle=G;X.globalAlpha=1;X.beginPath();X.ellipse(r*.98,-r*.14,r*.09,r*.14,0,0,TAU);X.fill();
  X.fillStyle='#e7fbff';X.globalAlpha=.85;for(let i=0;i<7;i++){X.beginPath();X.moveTo(r*.7+i*r*.1,r*.15);X.lineTo(r*.75+i*r*.1,r*.3);X.lineTo(r*.8+i*r*.1,r*.15);X.fill()}X.globalAlpha=1},
 // 18 Thần Long Biển Sâu
 (X,r,t,o)=>{const[A,B,G]=o.c;
  _chain(X,22,(u,i)=>{const x=-r*(u*2.8-1.0),y=Math.sin(t*3.2-u*6)*r*.45*(.3+u),w=r*(.4-u*.26);X.fillStyle=i%2?A:B;X.strokeStyle='#073a44';X.lineWidth=2;X.beginPath();X.arc(x,y,w,0,TAU);X.fill();X.stroke();
   if(i%3==0){X.fillStyle=G;X.beginPath();X.moveTo(x-w*.4,y-w*.9);X.lineTo(x,y-w*1.5);X.lineTo(x+w*.4,y-w*.9);X.fill()}});
  X.beginPath();X.moveTo(r*.5,-r*.5);X.lineTo(r*1.55,-r*.3);X.lineTo(r*1.7,r*.1);X.lineTo(r*1.45,r*.45);X.lineTo(r*.5,r*.5);X.closePath();_fs(X,_grad(X,r*.5,-r*.3,r*.1,r*1.2,'#fff0a8',A),'#073a44',r*.05);
  X.strokeStyle=G;X.lineWidth=r*.07;X.lineCap='round';X.beginPath();X.moveTo(r*.6,-r*.5);X.quadraticCurveTo(r*.3,-r*1.1,-r*.1,-r*1.05);X.moveTo(r*.85,-r*.45);X.quadraticCurveTo(r*.7,-r*1.1,r*.35,-r*1.3);X.stroke();
  X.strokeStyle='#fff3b0';X.lineWidth=r*.04;for(let s=-1;s<=1;s+=2){X.beginPath();X.moveTo(r*1.6,s*r*.2);X.quadraticCurveTo(r*2.0,s*r*(.5+Math.sin(t*3)*.1),r*2.25,s*r*.25);X.stroke()}
  X.fillStyle='#fff';for(let i=0;i<4;i++){X.beginPath();X.moveTo(r*1.0+i*r*.12,r*.32);X.lineTo(r*1.05+i*r*.12,r*.5);X.lineTo(r*1.1+i*r*.12,r*.32);X.fill()}
  _eye(X,r*1.1,-r*.18,r*.13,1,'#7affd9');X.fillStyle=B;X.beginPath();X.arc(r*1.68,0,r*.05,0,TAU);X.fill();
  if(o.cast>0){X.fillStyle=G;X.globalAlpha=o.cast*.8;X.beginPath();X.arc(r*1.95,0,r*(.1+o.cast*.4),0,TAU);X.fill();X.globalAlpha=1}},
 // 19 Hải Vương Tối Thượng
 (X,r,t,o)=>{const[A,B,G]=o.c,ph=o.ph||0;
  X.save();X.rotate(t*.3);X.strokeStyle=G;X.globalAlpha=.55;X.lineWidth=r*.025;X.setLineDash([r*.12,r*.1]);X.beginPath();X.arc(0,0,r*1.45,0,TAU);X.stroke();X.rotate(-t*.7);X.beginPath();X.arc(0,0,r*1.25,0,TAU);X.stroke();X.setLineDash([]);X.restore();X.globalAlpha=1;
  for(let i=0;i<5;i++){const a=Math.PI*.65+i*.2;_tent(X,Math.cos(a)*r*.3,r*.45,Math.cos(a)*.3,Math.sin(a),r*.95,t,i*1.1,r*.28,r*.13,i%2?'#e8fff7':'#bfe9ff',10)}
  X.beginPath();X.moveTo(-r*.6,r*.1);X.bezierCurveTo(-r*1.6,r*.3+Math.sin(t*2)*r*.1,-r*1.5,r*1.1,-r*.9,r*1.2);X.bezierCurveTo(-r*.5,r*.9,-r*.4,r*.5,-r*.4,r*.3);X.closePath();_fs(X,'rgba(120,70,190,.85)','#2a1250',r*.04);
  X.beginPath();X.arc(0,0,r*.78,0,TAU);_fs(X,_grad(X,-r*.25,-r*.3,r*.1,r*.85,'#fff3b0',A),B,r*.06);
  X.strokeStyle=B;X.lineWidth=r*.04;for(let i=0;i<3;i++){X.beginPath();X.arc(0,r*.08,r*(.3+i*.17),Math.PI*.15,Math.PI*.85);X.stroke()}
  X.fillStyle=G;X.strokeStyle=B;X.lineWidth=r*.04;X.beginPath();X.moveTo(-r*.55,-r*.55);X.lineTo(-r*.5,-r*1.12);X.lineTo(-r*.25,-r*.75);X.lineTo(0,-r*1.3);X.lineTo(r*.25,-r*.75);X.lineTo(r*.5,-r*1.12);X.lineTo(r*.55,-r*.55);X.closePath();X.fill();X.stroke();
  X.fillStyle=['#ff4d6d','#7affd9','#9f7aff','#ff9d00'][Math.min(3,ph)];X.beginPath();X.arc(0,-r*.95,r*.07,0,TAU);X.fill();
  _eye(X,-r*.25,-r*.12,r*.13,1,'#ff9d00');_eye(X,r*.25,-r*.12,r*.13,1,'#ff9d00');X.strokeStyle='#4a2a00';X.lineWidth=r*.05;X.beginPath();X.moveTo(-r*.4,-r*.3);X.lineTo(-r*.1,-r*.2);X.moveTo(r*.4,-r*.3);X.lineTo(r*.1,-r*.2);X.stroke();
  X.fillStyle='#e8fff7';X.beginPath();X.moveTo(-r*.3,r*.2);X.quadraticCurveTo(0,r*.85,r*.3,r*.2);X.quadraticCurveTo(0,r*.5,-r*.3,r*.2);X.fill();
  const hx=r*1.25;X.strokeStyle='#d8b85a';X.lineWidth=r*.07;X.lineCap='round';X.beginPath();X.moveTo(hx,-r*1.1);X.lineTo(hx,r*1.05);X.stroke();X.beginPath();X.moveTo(hx-r*.38,-r*.75);X.quadraticCurveTo(hx-r*.38,-r*1.15,hx,-r*1.2);X.quadraticCurveTo(hx+r*.38,-r*1.15,hx+r*.38,-r*.75);X.moveTo(hx,-r*1.05);X.lineTo(hx,-r*1.45);X.stroke();
  X.fillStyle=G;X.globalAlpha=.6+.4*Math.sin(t*4);X.beginPath();X.arc(hx,-r*1.5,r*.09,0,TAU);X.fill();X.globalAlpha=1}
];
const NOFLIP={0:1,1:0,2:1,9:1,10:0,12:0,15:1,16:1,19:0};   // các Boss đối xứng/đứng, không lật hình theo hướng bơi
