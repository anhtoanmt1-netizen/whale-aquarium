// ================= HỆ THỐNG BOSS (chế độ Hải Vực Chinh Phục): AI · 13 kỹ năng · giai đoạn · hiệu ứng · âm thanh =================
let bosses=[],bfx=[],SHKX=0,SHKY=0,SHAKE=0,FLASH=null;
const BS=()=>Math.max(.6,Math.min(1,Math.min(W,H*.75)/560));      // tỉ lệ cỡ Boss theo màn hình
const SKW={heal:1,pulse:.9,stunall:2.4,hole:.9,laser:1.5,summon:1,shield:.8,meteor:.7,poison:.8,clone:1,dash:.9,burst:.7,leech:2.6};   // thời gian tích tụ / cảnh báo
const SKN={heal:'Hồi máu',pulse:'Sóng xung kích',stunall:'CHOÁNG TOÀN BẢN ĐỒ',hole:'Hố đen',laser:'Tia năng lượng',summon:'Triệu hồi',shield:'Khiên',meteor:'Mưa thiên thạch',poison:'Vùng độc',clone:'Phân thân',dash:'Lao tới',burst:'Bắn gai',leech:'Hút máu'};
const PHN=['','Tăng cường!','CUỒNG NỘ!','BÙNG NỔ!'],PHC=['','#ffb454','#ff4d4d','#e6a8ff'];
const DMGK=.55,DMGZ=[1,1,1,.9,.72,.5];   // hệ số cân bằng chung: sát thương Boss lên đơn vị của người chơi (chỉnh một chỗ để dễ cân bằng lại)
const units=()=>fish.concat(swords,horses,crabs).filter(u=>!u.dead);
const mainBoss=()=>{for(const b of bosses)if(!b.mini&&!b.fake&&b.state!=='dying'&&b.state!=='warn'&&b.vis>.4)return b;return null};
const bossAlive=()=>bosses.some(b=>!b.mini&&!b.fake&&b.state!=='dying');

// ---------- âm thanh (dùng chung bộ WebAudio của game, không tạo hệ thống riêng) ----------
const bsT={};
function bsfx(k,v){
  if(!AC||S.snd=='off')return;const n=performance.now();if(n-(bsT[k]||0)<(k=='tap'?40:150))return;bsT[k]=n;
  const t0=AC.currentTime,out=AC.createGain();out.connect(MG);v=v||1;
  const tn=(ty,f0,f1,d,g,dl,flt)=>{const o=AC.createOscillator(),e=AC.createGain();o.type=ty;o.frequency.setValueAtTime(f0,t0+(dl||0));o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t0+(dl||0)+d);e.gain.setValueAtTime(.0001,t0+(dl||0));e.gain.exponentialRampToValueAtTime(g*v,t0+(dl||0)+.02);e.gain.exponentialRampToValueAtTime(.0001,t0+(dl||0)+d);o.connect(e);let nd=e;if(flt){const f=AC.createBiquadFilter();f.type='lowpass';f.frequency.value=flt;o.disconnect();o.connect(f);f.connect(e)}e.connect(out);o.start(t0+(dl||0));o.stop(t0+(dl||0)+d+.05)};
  const nz=(d,f0,f1,g,ty)=>{const b=AC.createBuffer(1,Math.floor(AC.sampleRate*d),AC.sampleRate),a=b.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=(Math.random()*2-1)*(1-i/a.length);const s=AC.createBufferSource(),f=AC.createBiquadFilter(),e=AC.createGain();s.buffer=b;f.type=ty||'bandpass';f.Q.value=1.4;f.frequency.setValueAtTime(f0,t0);f.frequency.exponentialRampToValueAtTime(Math.max(40,f1),t0+d);e.gain.setValueAtTime(g*v,t0);e.gain.exponentialRampToValueAtTime(.0001,t0+d);s.connect(f);f.connect(e);e.connect(out);s.start(t0)};
  const p=typeof k=='object'?k:null;
  if(p){ // gầm: p.f = giọng riêng của từng Boss
    tn('sawtooth',p.f*1.6,p.f*.7,.7,.16,0,700);tn('square',p.f*.8,p.f*.45,.6,.08,.05,500);nz(.5,900,200,.07,'lowpass');return}
  switch(k){
   case'appear':tn('sine',60,220,1.1,.22,0,400);nz(1,300,1400,.08);break;
   case'charge':tn('sawtooth',160,900,1.0,.07,0,1500);tn('sine',320,1800,1.0,.05);break;
   case'attack':nz(.18,1800,300,.12);tn('triangle',170,60,.16,.18);break;
   case'heal':[523,659,784,1047].forEach((f,i)=>tn('sine',f,f*1.01,.3,.07,i*.09));break;
   case'stun':tn('square',900,300,.5,.1);tn('sine',1180,420,.6,.1,.02);nz(.25,3000,500,.08);break;
   case'stunall':tn('sawtooth',80,40,.9,.22,0,300);nz(.8,2400,120,.16);tn('square',1000,200,.9,.07);break;
   case'hole':tn('sine',320,45,1.6,.2);nz(1.4,200,900,.09);tn('sawtooth',90,180,1.4,.07,.1,300);break;
   case'laser':tn('sawtooth',1500,200,.55,.1,0,2500);tn('square',700,120,.55,.06);break;
   case'summon':[300,420,560].forEach((f,i)=>tn('sine',f,f*1.8,.18,.12,i*.1));break;
   case'shield':[880,1175,1568].forEach((f,i)=>tn('triangle',f,f*1.02,.4,.06,i*.07));break;
   case'shieldbreak':nz(.3,4000,600,.14);tn('triangle',1400,300,.3,.1);break;
   case'rage':tn('sawtooth',110,70,.9,.22,0,900);tn('square',165,90,.9,.12);nz(.7,800,150,.12);break;
   case'phase':tn('sine',200,800,.8,.15);tn('sawtooth',100,400,.8,.1,0,1200);break;
   case'die':tn('sawtooth',260,35,1.4,.26,0,600);nz(1.2,2000,80,.2,'lowpass');tn('sine',90,30,1.2,.25,.15);break;
   case'meteor':tn('sine',1400,200,.6,.06);tn('sawtooth',90,40,.5,.18,.5,300);nz(.4,700,100,.1);break;
   case'burst':tn('triangle',500,900,.12,.08);tn('triangle',650,1100,.12,.06,.05);break;
   case'poison':nz(.5,500,200,.07,'lowpass');tn('sine',300,180,.4,.07);break;
   case'dash':nz(.35,2200,350,.12);tn('sawtooth',200,500,.3,.07,0,1200);break;
   case'clone':tn('sine',700,350,.3,.08);tn('sine',350,700,.3,.06,.1);break;
   case'boom':tn('sine',120,30,.5,.25);nz(.4,1500,90,.15,'lowpass');break;
   case'tap':tn('triangle',420+(v>1?0:0),180,.09,.15);break;
  }
}
const tapSfx=lv=>{if(!AC||S.snd=='off')return;const t0=AC.currentTime,o=AC.createOscillator(),g=AC.createGain();o.type=lv>5?'sawtooth':'triangle';o.frequency.setValueAtTime(260+lv*70,t0);o.frequency.exponentialRampToValueAtTime(90+lv*15,t0+.1);g.gain.setValueAtTime(.05+lv*.012,t0);g.gain.exponentialRampToValueAtTime(.0001,t0+.14);o.connect(g);g.connect(MG);o.start(t0);o.stop(t0+.16);
  if(lv>=4){const o2=AC.createOscillator(),g2=AC.createGain();o2.type='sine';o2.frequency.setValueAtTime(900+lv*120,t0+.02);g2.gain.setValueAtTime(.04,t0+.02);g2.gain.exponentialRampToValueAtTime(.0001,t0+.25);o2.connect(g2);g2.connect(MG);o2.start(t0+.02);o2.stop(t0+.27)}};

// ---------- sinh Boss ----------
const SIDES=['top','left','right','bottom'],SIDEN={top:'phía trên',left:'bên trái',right:'bên phải',bottom:'phía dưới'};
function spawnBoss(bid,L,side,idx,n,o){
  o=o||{};const d=BD[bid],bs=BS(),r=(o.r||d.r)*bs,mini=!!o.mini,fake=!!o.fake;
  const hp=o.hp||Math.round(d.hp*L.hpM),pad=r*.9;let x,y,tx,ty;const fx0=(idx+1)/(n+1);
  if(o.x!=null){x=o.x;y=o.y;tx=x;ty=y}
  else if(side=='top'){x=cl(W*fx0,pad,W-pad);y=-r*1.5;tx=x;ty=TOP+r*1.1+30}
  else if(side=='bottom'){x=cl(W*fx0,pad,W-pad);y=H+r*1.5;tx=x;ty=H-r*1.2-30}
  else if(side=='left'){x=-r*1.6;y=cl(TOP+(H-TOP)*fx0,TOP+pad,H-pad);tx=r*1.2+20;ty=y}
  else{x=W+r*1.6;y=cl(TOP+(H-TOP)*fx0,TOP+pad,H-pad);tx=W-r*1.2-20;ty=y}
  const b={boss:true,mini,fake,bid,nm:d.nm,c:d.c,r,x,y,tx,ty,vx:0,vy:0,hp,max:hp,dmg:fake?0:(o.dmg||d.dmg*L.dmgM),spd:(o.spd||d.spd*L.spdM)*(mini?1.35:1),atk:d.atk,atkT:1.2,eat:d.eat,eatT:d.eat,ai:d.ai,keep:(d.keep||0)*bs,dir:1,fl:1,hit:0,vis:o.x!=null?1:0,
    state:o.x!=null?'fight':'warn',warnT:1.5,side,ph:0,pm:1,pth:d.ph,cdM:L.cdM,skills:(mini||fake)?[]:d.sk.map(s=>({k:s[0],cd:s[1]*L.cdM,t:R(5,9)+s[1]*.2,ph:s[2]})),cast:null,skGap:2.5,shield:0,shieldMax:0,shieldT:0,age:0,life:o.life||0,transT:0,deadT:0,
    dash:null,heal:0,strafe:Math.random()<.5?1:-1,sTt:R(2,4),id:'b'+Math.random().toString(36).slice(2,7),by:o.by,tapped:0};
  bosses.push(b);if(!mini&&!fake){say('⚠️ '+d.nm+' sắp xuất hiện từ '+SIDEN[side]+'!');bsfx('appear')}return b;
}
function arenaClamp(b){const p=b.r*.7;b.x=cl(b.x,p,W-p);b.y=cl(b.y,TOP+p,H-p-10)}

// ---------- sát thương lên đơn vị của người chơi ----------
function hurtUnit(u,d,src,quiet){
  if(u.dead||d<=0)return false;d*=DMGK*DMGZ[LV[CAMP.lv-1].z];
  if(u.role||u.crab){u.hp-=d;u.hurt=.3;if(!quiet)dmgText(u.x,u.y-26,Math.round(d));if(u.hp<=0){u.dead=true;CAMP.lost++;say((u.crab?'🦀 ':u.role=='sup'?'🌟 ':'⚔️ ')+u.name+' đã hy sinh 😢')}}
  else{if(u.hp==null)u.hp=40+30*u.stage;u.hp-=d*.5;u.freeze=.25;if(!quiet)dmgText(u.x,u.y-18,Math.round(d*.5));if(u.hp<=0){u.dead=true;CAMP.lost++;say('Cá bị tiêu diệt! 😱')}}
  return true;
}
const stunUnit=(u,s)=>{u.stun=Math.max(u.stun||0,s);if(!u.role&&!u.crab)u.freeze=Math.max(u.freeze||0,s)};

// ---------- nhận sát thương của Boss (dùng chung cho Chiến Binh và chạm tay) ----------
function bossHit(b,d,who,px,py,tap){
  if(b.state==='dying'||b.state==='warn')return false;
  if(b.state==='trans'){dmgText(px,py,'MIỄN');return false}
  if(b.fake){b.hp=0;bossDie(b,who);return true}
  if(b.shield>0){const a=Math.min(b.shield,d);b.shield-=a;d-=a;fx.push({x:px,y:py,l:.3,m:.3,e:'🛡️'});if(b.shield<=0){b.shieldT=0;bsfx('shieldbreak')}if(d<=0)return false}
  b.hp-=d;b.hit=tap?.25:.3;CAMP.dealt+=d;dmgText(px,py,Math.round(d));if(!tap)fx.push({x:b.x,y:b.y,l:.4,e:'💥'});
  if(b.hp<=0&&!b.mini){b.hp=0;bossDie(b,who);return true}
  if(b.hp<=0){bossDie(b,who);return true}
  return false;
}
function bossDie(b,who){
  if(b.state==='dying')return;b.state='dying';b.cast=null;b.dash=null;b.deadT=b.bid==19&&!b.mini&&!b.fake?2.6:(b.mini||b.fake?.5:1.4);b.dmg=0;
  if(b.mini||b.fake){boom(b.x,b.y,b.r,b.c[2],6);return}
  bsfx('die');bsfx('boom');SHAKE=Math.max(SHAKE,.6);boom(b.x,b.y,b.r*1.6,b.c[2],b.bid==19?34:18);
  const rw=BD[b.bid].rw;S.coins+=rw;CAMP.gold+=rw;CAMP.kills++;say('💀 '+b.nm+' bị hạ'+(who&&who!='tap'?' bởi '+who:'')+'! +'+rw+' 🪙');
  for(const o of bosses)if(o.by===b.id&&o.state!=='dying')bossDie(o,'');    // quái con / phân thân biến mất theo chủ
  if(b.bid==19)FLASH={t:0,dur:1.4,c:'#fff3b0'};crewCheer();
}
function boom(x,y,r,col,n){const m=Math.min(n,PF.spk);for(let i=0;i<m;i++){const a=R(0,TAU),v=R(80,260);bfx.push({k:'sp',x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,t:0,dur:R(.4,.9),c:col,s:R(2,6)})}bfx.push({k:'rg',x,y,r0:r*.3,r1:r*2.2,t:0,dur:.6,c:col})}

// ---------- AI chính ----------
function bossTarget(b){
  let n=null,bs=1e9,isU=false;b._td=1e9;
  const pk=(o,wt)=>{if(o.dead)return;const d=Math.hypot(o.x-b.x,o.y-b.y);if(d*wt<bs){bs=d*wt;b._td=d;n=o;isU=true}};
  for(const w of swords)pk(w,1);for(const o of horses)pk(o,1);for(const o of crabs)pk(o,1.35);
  let bf=1e9,nf=null;for(const f of fish){if(f.dead)continue;const d=Math.hypot(f.x-b.x,f.y-b.y);if(d<bf){bf=d;nf=f}}
  if(!isU||bf<bs*.6){n=nf;b._td=bf;isU=false}b._tu=isU;return n;
}
function skillOK(b,s){
  switch(s.k){
   case'heal':return b.hp<b.max*.85;
   case'summon':return bosses.filter(o=>o.by===b.id&&o.mini&&o.state!=='dying').length<(b.bid==19?6:4);
   case'shield':return b.shield<=0;
   case'clone':return !bosses.some(o=>o.by===b.id&&o.fake&&o.state!=='dying');
   case'hole':return !bfx.some(e=>e.k=='hole');
   case'stunall':return units().length>2&&!bosses.some(o=>o!==b&&o.cast&&o.cast.k=='stunall');
   case'leech':return b._td<300*BS();
  }return true;
}
function startCast(b,s){
  const tg=bossTarget(b),cs={k:s.k,t:0,dur:SKW[s.k],s};
  if(s.k=='laser'||s.k=='dash'){const tx=tg?tg.x:W/2,ty=tg?tg.y:H/2;cs.ang=Math.atan2(ty-b.y,tx-b.x)}
  b.cast=cs;b.skGap=1+R(0,.8);s.t=s.cd*R(.9,1.15);
  if(s.k=='stunall'){say('⚠️ '+b.nm+' đang tích tụ năng lượng CHOÁNG TOÀN BẢN ĐỒ!');bsfx('charge')}
  else if(s.k=='laser'||s.k=='meteor'||s.k=='hole'||s.k=='dash')bsfx('charge',.6);
  if(s.k=='meteor')meteorSpawn(b);
}
function meteorSpawn(b){const us=units(),n=3+b.ph+(b.bid==19?2:0)+(LV[CAMP.lv-1].z>=3?1:0);
  for(let i=0;i<n&&bfx.length<90;i++){const u=us.length?us[Math.floor(Math.random()*us.length)]:null,x=cl((u?u.x:R(60,W-60))+R(-70,70),50,W-50),y=cl((u?u.y:R(TOP+60,H-60))+R(-50,50),TOP+40,H-40);
    bfx.push({k:'met',x,y,t:0,warn:1.7+i*.12,r:72*BS(),dmg:b.dmg*1.6,done:false})}bsfx('meteor')}
function fireSkill(b,cs){
  const k=cs.k,bs=BS();
  switch(k){
   case'heal':b.heal=b.max*(.06+.015*b.ph);b.healT=2.2;bsfx('heal');break;    // hồi tối đa ~6–10% máu để không tạo thế bế tắc
   case'pulse':bfx.push({k:'ring',x:b.x,y:b.y,r0:b.r*.6,r1:b.r+235*bs,t:0,dur:.75,dmg:b.dmg*1.1,stun:1.6,c:b.c[2],hit:new Set(),reg:false});bsfx('stun');SHAKE=Math.max(SHAKE,.25);break;
   case'stunall':{for(const u of units())stunUnit(u,2.6);bfx.push({k:'rg',x:b.x,y:b.y,r0:b.r,r1:Math.max(W,H)*1.1,t:0,dur:.9,c:b.c[2]});FLASH={t:0,dur:.8,c:b.c[2]};SHAKE=.9;bsfx('stunall');CAMP.hits++;break}
   case'hole':bfx.push({k:'hole',x:b.x,y:b.y,r:300*bs,t:0,dur:4.2,pull:200,dmg:b.dmg*.35,tk:0,reg:false});bsfx('hole');break;
   case'laser':{bfx.push({k:'beam',x:b.x,y:b.y,ang:cs.ang,len:Math.max(W,H)*1.4,w:40*bs,t:0,dur:.6,dmg:b.dmg*2,c:b.c[2],hit:new Set(),reg:false,src:b});bsfx('laser');SHAKE=Math.max(SHAKE,.2);break}
   case'summon':{const have=bosses.filter(o=>o.by===b.id&&o.mini&&o.state!=='dying').length,cap=b.bid==19?6:4,n=Math.min(cap-have,2+b.ph);for(let i=0;i<n;i++){const a=R(0,TAU);spawnBoss(b.bid,LV[CAMP.lv-1],'',0,1,{mini:true,x:cl(b.x+Math.cos(a)*b.r*1.3,40,W-40),y:cl(b.y+Math.sin(a)*b.r*1.3,TOP+40,H-40),r:Math.max(18,BD[b.bid].r*.32),hp:60+Math.round(b.max*.012),dmg:b.dmg*.3,spd:78,life:18,by:b.id});}bsfx('summon');boom(b.x,b.y,b.r,b.c[2],8);break}
   case'shield':b.shieldMax=b.max*.1*(1+.12*b.ph);b.shield=b.shieldMax;b.shieldT=9;bsfx('shield');break;
   case'poison':{const us=units(),n=2+b.ph;for(let i=0;i<n&&bfx.length<90;i++){const u=us.length?us[Math.floor(Math.random()*us.length)]:null;bfx.push({k:'pool',x:cl((u?u.x:b.x)+R(-50,50),60,W-60),y:cl((u?u.y:b.y)+R(-40,40),TOP+50,H-50),r:88*bs,t:0,dur:7,dps:b.dmg*.35,tk:0,reg:false,c:b.c[2]})}bsfx('poison');break}
   case'clone':{const n=2+(b.ph>=2?1:0);for(let i=0;i<n;i++){const a=i/n*TAU+R(0,1);spawnBoss(b.bid,LV[CAMP.lv-1],'',0,1,{fake:true,x:cl(b.x+Math.cos(a)*b.r*2.2,b.r,W-b.r),y:cl(b.y+Math.sin(a)*b.r*1.6,TOP+b.r,H-b.r),r:BD[b.bid].r,hp:Math.max(80,Math.round(b.max*.01)),life:10,by:b.id})}bsfx('clone');boom(b.x,b.y,b.r,b.c[2],10);
        b.vx=0;b.x=cl(b.x+R(-b.r*3,b.r*3),b.r,W-b.r);b.y=cl(b.y+R(-b.r*2,b.r*2),TOP+b.r,H-b.r);break}
   case'dash':b.dash={t:.6,vx:Math.cos(cs.ang)*620*bs,vy:Math.sin(cs.ang)*620*bs,hit:new Set()};bsfx('dash');break;
   case'burst':{const n=10+2*b.ph;for(let i=0;i<n&&bfx.length<110;i++){const a=i/n*TAU+R(0,.2);bfx.push({k:'bul',x:b.x,y:b.y,vx:Math.cos(a)*190*bs,vy:Math.sin(a)*190*bs,r:9*bs,dmg:b.dmg*.7,t:0,dur:4,c:b.c[2]})}bsfx('burst');break}
  }
}
function phaseUp(b){
  b.ph++;b.state='trans';b.transT=1.5;b.cast=null;b.dash=null;b.pm=1+.15*b.ph;
  say('🔥 '+b.nm+' '+PHN[Math.min(3,b.ph)]);bsfx(b.ph>=2?'rage':'phase');SHAKE=Math.max(SHAKE,.5);FLASH={t:0,dur:.5,c:PHC[Math.min(3,b.ph)]};
  bfx.push({k:'rg',x:b.x,y:b.y,r0:b.r,r1:b.r*3.5,t:0,dur:.9,c:PHC[Math.min(3,b.ph)]});boom(b.x,b.y,b.r,PHC[Math.min(3,b.ph)],14);
  if(b.bid==19&&b.ph>=2){b.skGap=.8;for(const s of b.skills)s.t=Math.min(s.t,2+Math.random()*3)}
}
function updBosses(dt){
  if(SHAKE>0){SHAKE=Math.max(0,SHAKE-dt*1.8);SHKX=R(-1,1)*SHAKE*9;SHKY=R(-1,1)*SHAKE*9}else SHKX=SHKY=0;
  if(FLASH){FLASH.t+=dt;if(FLASH.t>=FLASH.dur)FLASH=null}
  for(const b of bosses){
    b.age+=dt;b.hit-=dt;b.atkT-=dt;
    if(b.state==='dying'){b.deadT-=dt;b.vis=Math.max(0,b.deadT/(b.mini||b.fake?.5:1.4));if(Math.random()<dt*14&&!b.mini&&!b.fake)boom(b.x+R(-b.r,b.r),b.y+R(-b.r,b.r),b.r*.4,b.c[2],3);continue}
    if(b.life){b.life-=dt;if(b.life<=0){bossDie(b,'');continue}}
    if(b.state==='warn'){b.warnT-=dt;if(b.warnT<=0){b.state='enter';bsfx({f:BD[b.bid].vf});say('🚨 '+b.nm+' xuất hiện!')}continue}
    if(b.state==='enter'){const dx=b.tx-b.x,dy=b.ty-b.y,d=Math.hypot(dx,dy)||1;b.vis=Math.min(1,b.vis+dt*1.4);const sp=Math.max(150,b.spd*2.4);b.x+=dx/d*Math.min(d,sp*dt);b.y+=dy/d*Math.min(d,sp*dt);b.dir=dx>=0?1:-1;
      if(d<8||b.age>5){b.state='fight';b.vis=1}continue}
    if(b.state==='trans'){b.transT-=dt;b.vx*=.9;b.vy*=.9;if(b.transT<=0)b.state='fight';continue}
    // giai đoạn theo mốc máu
    if(!b.mini&&!b.fake&&b.ph<b.pth.length&&b.hp<=b.max*b.pth[b.ph]){phaseUp(b);continue}
    // tự hồi máu (kỹ năng hồi máu)
    if(b.healT>0){const h=b.heal/2.2*dt;b.hp=Math.min(b.max,b.hp+h);b.healT-=dt;if(Math.random()<dt*10)bfx.push({k:'sp',x:b.x+R(-b.r,b.r),y:b.y+R(-b.r*.6,b.r*.6),vx:0,vy:-50,t:0,dur:.8,c:'#7dffa8',s:R(2,4)})}
    if(b.shield>0){b.shieldT-=dt;if(b.shieldT<=0)b.shield=0}
    const tg=bossTarget(b);
    const spM=b.pm*(b.cast?(b.cast.k=='laser'||b.cast.k=='dash'?.05:.35):1);
    // kỹ năng
    if(!b.mini&&!b.fake){
      for(const s of b.skills)s.t-=dt;b.skGap-=dt;
      if(!b.cast&&!b.dash&&b.skGap<=0){for(const s of b.skills)if(s.t<=0&&s.ph<=b.ph&&skillOK(b,s)){startCast(b,s);break}}
      if(b.cast){const cs=b.cast;cs.t+=dt;
        if((cs.k=='laser')&&cs.t<cs.dur-.45){const t2=bossTarget(b);if(t2)cs.ang+=Math.atan2(Math.sin(Math.atan2(t2.y-b.y,t2.x-b.x)-cs.ang),Math.cos(Math.atan2(t2.y-b.y,t2.x-b.x)-cs.ang))*Math.min(1,dt*2.5)}
        if(cs.k=='leech'&&cs.t>.3){cs.tk=(cs.tk||0)-dt;if(cs.tk<=0){cs.tk=.4;let n=0,reg=false;const us=units().sort((p,q)=>Math.hypot(p.x-b.x,p.y-b.y)-Math.hypot(q.x-b.x,q.y-b.y));for(const u of us){if(n>=3||Math.hypot(u.x-b.x,u.y-b.y)>310*BS())break;if(hurtUnit(u,b.dmg*.45,b)){n++;reg=true;b.hp=Math.min(b.max,b.hp+b.dmg*.35);bfx.push({k:'sp',x:u.x,y:u.y,vx:(b.x-u.x)*1.4,vy:(b.y-u.y)*1.4,t:0,dur:.7,c:'#ff7a9a',s:4})}}if(reg&&!cs.reg){CAMP.hits++;cs.reg=true}}}
        if(cs.t>=cs.dur){b.cast=null;if(cs.k!=='leech')fireSkill(b,cs)}}
    }
    // di chuyển
    let vx=0,vy=0;
    if(b.dash){const dd=b.dash;dd.t-=dt;vx=dd.vx;vy=dd.vy;
      for(const u of units()){if(dd.hit.has(u))continue;if(Math.hypot(u.x-b.x,u.y-b.y)<b.r+34){dd.hit.add(u);if(hurtUnit(u,b.dmg*1.8,b)){CAMP.hits++;stunUnit(u,.8)}}}
      if(Math.random()<dt*30)bfx.push({k:'sp',x:b.x-b.dir*b.r*.5,y:b.y+R(-b.r*.4,b.r*.4),vx:0,vy:0,t:0,dur:.5,c:b.c[2],s:R(3,6)});
      b.x+=vx*dt;b.y+=vy*dt;if(dd.t<=0)b.dash=null;b.vx=vx;b.vy=vy}
    else{
      if(tg){const dx=tg.x-b.x,dy=tg.y-b.y,d=Math.hypot(dx,dy)||1,sp=b.spd*spM;
        if(b.ai=='k'&&b.keep){if(d<b.keep*.8){vx=-dx/d*sp;vy=-dy/d*sp}else if(d>b.keep*1.2){vx=dx/d*sp;vy=dy/d*sp}else{b.sTt-=dt;if(b.sTt<=0){b.strafe*=-1;b.sTt=R(2,4)}vx=-dy/d*sp*.7*b.strafe;vy=dx/d*sp*.7*b.strafe}}
        else{vx=dx/d*sp;vy=dy/d*sp;b.sTt-=dt;if(b.sTt<=0){b.strafe*=-1;b.sTt=R(1.5,3)}vx+=-dy/d*sp*.25*b.strafe;vy+=dx/d*sp*.25*b.strafe}}
      for(const o of bosses){if(o===b||o.state==='dying'||o.state==='warn')continue;const ex=b.x-o.x,ey=b.y-o.y,ed=Math.hypot(ex,ey)||1,mn=(b.r+o.r)*.9;if(ed<mn){vx+=ex/ed*(mn-ed)*4;vy+=ey/ed*(mn-ed)*4}}   // không chồng lấn
      b.vx+=(vx-b.vx)*Math.min(1,dt*2.5);b.vy+=(vy-b.vy)*Math.min(1,dt*2.5);b.x+=b.vx*dt;b.y+=b.vy*dt}
    arenaClamp(b);
    if(Math.abs(b.vx)>10)b.dir=b.vx>0?1:-1;b.fl+=(b.dir-b.fl)*Math.min(1,dt*8);
    // tấn công cận chiến / nuốt cá
    if(tg&&b.dmg>0&&!b.cast&&!b.dash){
      if(b._tu){if(b._td<b.r*.9+34&&b.atkT<=0){b.atkT=b.atk/b.pm;if(hurtUnit(tg,b.dmg*(1+.1*b.ph),b)){CAMP.hits++;bsfx('attack',.7)}}}
      else if(b._td<b.r*.8+16){b.eatT-=dt*b.pm;if(b.eatT<=0){b.eatT=b.eat;tg.dead=true;CAMP.lost++;CAMP.hits++;say('Cá bị ăn mất! 😱');bsfx('attack',.7)}}else b.eatT=Math.min(b.eat,b.eatT+dt)}
  }
  bosses=bosses.filter(b=>b.state!=='dying'||b.deadT>0);
  // hồi máu cho cá khi không còn Boss
  if(!mainBoss())for(const f of fish)if(f.hp!=null){f.hp=Math.min(40+30*f.stage,f.hp+dt*3)}
  updBossFx(dt);
}
function updBossFx(dt){
  const us=units();
  for(let i=bfx.length-1;i>=0;i--){const e=bfx[i];e.t+=dt;let rm=false;
    switch(e.k){
     case'sp':e.x+=e.vx*dt;e.y+=e.vy*dt;e.vx*=Math.pow(.2,dt);e.vy*=Math.pow(.2,dt);rm=e.t>=e.dur;break;
     case'rg':rm=e.t>=e.dur;break;
     case'ring':{const p=e.t/e.dur,rad=e.r0+(e.r1-e.r0)*p;for(const u of us){if(e.hit.has(u))continue;if(Math.hypot(u.x-e.x,u.y-e.y)<=rad+14){e.hit.add(u);if(hurtUnit(u,e.dmg,null)){stunUnit(u,e.stun);if(!e.reg){e.reg=true;CAMP.hits++}}}}rm=p>=1;break}
     case'beam':{const dx=Math.cos(e.ang),dy=Math.sin(e.ang);if(e.src&&e.src.state!=='dying'){e.x=e.src.x;e.y=e.src.y}
       for(const u of us){if(e.hit.has(u))continue;const px=u.x-e.x,py=u.y-e.y,pr=px*dx+py*dy;if(pr<0||pr>e.len)continue;if(Math.abs(px*dy-py*dx)<e.w*.5+26){e.hit.add(u);if(hurtUnit(u,e.dmg,null)&&!e.reg){e.reg=true;CAMP.hits++}}}
       if(Math.random()<dt*40&&bfx.length<120){const pr=R(0,Math.min(e.len,Math.max(W,H)));bfx.push({k:'sp',x:e.x+dx*pr,y:e.y+dy*pr,vx:R(-30,30),vy:R(-30,30),t:0,dur:.4,c:e.c,s:R(2,4)})}rm=e.t>=e.dur;break}
     case'hole':{e.tk-=dt;for(const u of us){const dx=e.x-u.x,dy=e.y-u.y,d=Math.hypot(dx,dy);if(d<e.r&&d>6){const f=e.pull*(1-d/e.r*.6)*dt;if(u.crab)u.x+=dx/d*f;else{u.x+=dx/d*f;u.y+=dy/d*f}}
         if(e.tk<=0&&d<62){if(hurtUnit(u,e.dmg,null,true)&&!e.reg){e.reg=true;CAMP.hits++}}}
       if(e.tk<=0)e.tk=.5;if(Math.random()<dt*30&&bfx.length<120){const a=R(0,TAU),rr=e.r*R(.4,1);bfx.push({k:'sp',x:e.x+Math.cos(a)*rr,y:e.y+Math.sin(a)*rr,vx:-Math.cos(a)*90,vy:-Math.sin(a)*90,t:0,dur:.6,c:'#c9a0ff',s:R(2,4)})}rm=e.t>=e.dur;break}
     case'pool':{e.tk-=dt;if(e.tk<=0){e.tk=.5;for(const u of us)if(Math.hypot(u.x-e.x,u.y-e.y)<e.r&&hurtUnit(u,e.dps*.5,null,true)&&!e.reg){e.reg=true;CAMP.hits++}}
       if(Math.random()<dt*6&&bubbles.length<PF.bub*2)bubbles.push({x:e.x+R(-e.r,e.r)*.8,y:e.y+R(-e.r,e.r)*.5,r:R(2,4),ph:R(0,6)});rm=e.t>=e.dur;break}
     case'bul':{e.x+=e.vx*dt;e.y+=e.vy*dt;for(const u of us){if(Math.hypot(u.x-e.x,u.y-e.y)<e.r+24){if(hurtUnit(u,e.dmg,null)){CAMP.hits++;rm=true;boom(e.x,e.y,e.r,e.c,3);break}}}
       if(e.x<-20||e.x>W+20||e.y<-20||e.y>H+20||e.t>e.dur)rm=true;break}
     case'met':{if(!e.done&&e.t>=e.warn+.3){e.done=true;let reg=false;for(const u of us)if(Math.hypot(u.x-e.x,u.y-e.y)<e.r+16&&hurtUnit(u,e.dmg,null)){if(!reg){reg=true;CAMP.hits++}stunUnit(u,.5)}
         boom(e.x,e.y,e.r,'#ffb454',10);bfx.push({k:'rg',x:e.x,y:e.y,r0:e.r*.3,r1:e.r*1.3,t:0,dur:.45,c:'#ff8a3d'});SHAKE=Math.max(SHAKE,.18);bsfx('boom',.6)}rm=e.t>=e.warn+.9;break}
     case'tp':rm=e.t>=e.dur;break;
    }
    if(rm)bfx.splice(i,1);
  }
  if(bfx.length>140)bfx.splice(0,bfx.length-140);
}

// ---------- vẽ ----------
function drawBosses(){
  for(const b of bosses){
    if(b.state==='warn'){drawWarnEdge(b);continue}
    const ph=Math.min(3,b.ph),vis=b.vis,r=b.r;if(vis<=0)continue;
    c.save();c.translate(b.x+(b.hit>0&&!b.mini?R(-3,3):0),b.y);c.globalAlpha=vis*(b.fake?.62+.18*Math.sin(t*14):1);
    let sc=b.state==='enter'?.35+.65*vis:b.state==='dying'?(.4+.6*vis):1;if(b.state==='trans')sc=1+.08*Math.sin(b.transT*26);
    c.scale(sc,sc);
    // hào quang theo giai đoạn
    const gc=ph?PHC[ph]:b.c[2],gr=r*(1.55+.15*Math.sin(t*3)+(b.cast?b.cast.t/b.cast.dur*.4:0));
    if(!b.mini||ph){const g=c.createRadialGradient(0,0,r*.4,0,0,gr);g.addColorStop(0,gc+(ph?'55':'33'));g.addColorStop(1,gc+'00');c.fillStyle=g;c.beginPath();c.arc(0,0,gr,0,TAU);c.fill()}
    c.save();if(NOFLIP[b.bid]!==1)c.scale(b.fl,1);
    if(b.hit>0&&b.state!=='dying'){c.filter='brightness(1.7)'}
    if(ph>=2&&b.state!=='dying'){c.filter=(c.filter&&c.filter!=='none'?c.filter+' ':'')+'saturate(1.5) hue-rotate(-12deg)'}
    ART[b.bid](c,r,t+b.age*.0,{c:b.c,cast:b.cast?b.cast.t/b.cast.dur:0,ph,look:b.fl});
    c.filter='none';c.restore();
    if(b.shield>0){c.strokeStyle='rgba(130,210,255,.85)';c.lineWidth=4;c.fillStyle='rgba(130,210,255,.18)';c.beginPath();c.arc(0,0,r*1.25,0,TAU);c.fill();c.stroke()}
    c.restore();c.globalAlpha=1;
    if(b.state!=='dying')drawCastTele(b);
    drawBossBar(b);
  }
}
function drawWarnEdge(b){   // mũi tên cảnh báo ở mép màn hình nơi Boss sắp vào
  const x=cl(b.x,30,W-30),y=cl(b.y,TOP+20,H-30),p=Math.sin(b.warnT*14)*.5+.5;c.save();c.globalAlpha=.4+.5*p;c.fillStyle='#ff3d3d';c.translate(x,y);
  c.rotate(b.side=='top'?Math.PI/2:b.side=='bottom'?-Math.PI/2:b.side=='left'?Math.PI:0);c.beginPath();c.moveTo(-26,0);c.lineTo(10,-20);c.lineTo(10,20);c.closePath();c.fill();c.font='900 22px Montserrat,sans-serif';c.textAlign='center';c.fillText('!',-4,8);
  c.globalAlpha=.18*p;c.fillStyle='#ff3d3d';if(b.side=='top')c.fillRect(-W,-y,W*3,60);c.restore();
  if(b.side=='top'){c.save();c.globalAlpha=.16*p;c.fillStyle='#ff3d3d';c.fillRect(0,TOP,W,36);c.restore()}else if(b.side=='left'||b.side=='right'){c.save();c.globalAlpha=.16*p;c.fillStyle='#ff3d3d';c.fillRect(b.side=='left'?0:W-36,TOP,36,H-TOP);c.restore()}else{c.save();c.globalAlpha=.16*p;c.fillStyle='#ff3d3d';c.fillRect(0,H-36,W,36);c.restore()}
}
function drawCastTele(b){
  const cs=b.cast;if(!cs)return;const p=cs.t/cs.dur,col=b.c[2],bs=BS();c.save();
  switch(cs.k){
   case'laser':{const dx=Math.cos(cs.ang),dy=Math.sin(cs.ang);c.strokeStyle='rgba(255,60,60,'+(.25+.6*p)+')';c.lineWidth=2+p*(40*bs*.5);c.setLineDash([14,10]);c.beginPath();c.moveTo(b.x,b.y);c.lineTo(b.x+dx*Math.max(W,H)*1.4,b.y+dy*Math.max(W,H)*1.4);c.stroke();c.setLineDash([]);break}
   case'dash':{const dx=Math.cos(cs.ang),dy=Math.sin(cs.ang),L=620*bs*.6;c.strokeStyle='rgba(255,90,60,'+(.3+.5*p)+')';c.lineWidth=b.r*.9;c.globalAlpha=.25+.3*p;c.beginPath();c.moveTo(b.x,b.y);c.lineTo(b.x+dx*L,b.y+dy*L);c.stroke();break}
   case'pulse':{const rr=(b.r+235*bs)*(1-p*.75);c.strokeStyle=col;c.lineWidth=3;c.globalAlpha=.3+.5*p;c.beginPath();c.arc(b.x,b.y,rr,0,TAU);c.stroke();break}
   case'stunall':{c.strokeStyle=col;c.lineWidth=4;c.globalAlpha=.4+.4*Math.sin(t*20)*.5;for(let i=0;i<3;i++){c.beginPath();c.arc(b.x,b.y,Math.max(8,b.r*(2.6-p*2.2)+i*18),0,TAU);c.stroke()}c.globalAlpha=.07*p;c.fillStyle=col;c.fillRect(0,0,W,H);break}
   case'heal':{c.strokeStyle='#7dffa8';c.lineWidth=4;c.globalAlpha=.6;c.beginPath();c.arc(b.x,b.y,b.r*(1.9-p*.7),0,TAU);c.stroke();break}
   case'shield':{c.strokeStyle='#8ad7ff';c.lineWidth=4;c.globalAlpha=.7;c.beginPath();c.arc(b.x,b.y,b.r*(1.9-p*.65),0,TAU);c.stroke();break}
   case'hole':{c.strokeStyle='#c9a0ff';c.lineWidth=3;c.globalAlpha=.7;for(let i=0;i<3;i++){c.beginPath();c.arc(b.x,b.y,b.r*(.8+i*.5)*(1.4-p*.4),t*3+i,t*3+i+3.6);c.stroke()}break}
   case'summon':case'clone':{c.strokeStyle='#e0a8ff';c.lineWidth=3;c.globalAlpha=.7;c.setLineDash([8,8]);c.beginPath();c.arc(b.x,b.y,b.r*(1.3+p*.7),t,t+TAU);c.stroke();c.setLineDash([]);break}
   case'leech':{c.strokeStyle='rgba(255,110,150,.6)';c.lineWidth=3;for(const u of units()){if(Math.hypot(u.x-b.x,u.y-b.y)<310*bs&&p>.12){c.beginPath();c.moveTo(b.x,b.y);c.lineTo(u.x,u.y);c.stroke()}}break}
   default:{c.strokeStyle=col;c.lineWidth=3;c.globalAlpha=.6;c.beginPath();c.arc(b.x,b.y,b.r*(1.7-p*.5),0,TAU);c.stroke()}
  }
  c.restore();
}
function drawBossBar(b){
  if(b.state==='dying'||b.vis<.5)return;const mini=b.mini||b.fake,w=mini?Math.max(34,b.r*1.5):Math.max(86,b.r*2),y=b.y-b.r*1.35-(mini?6:14),h=mini?4:9;
  c.fillStyle='#0008';c.fillRect(b.x-w/2-1,y-1,w+2,h+2);c.fillStyle=b.fake?'#b6a0d0':b.ph>=2?'#ff3d3d':b.ph==1?'#ff9d3d':'#ff5a5a';c.fillRect(b.x-w/2,y,w*Math.max(0,b.hp/b.max),h);
  if(b.shield>0){c.fillStyle='#8ad7ff';c.fillRect(b.x-w/2,y-4,w*(b.shield/b.shieldMax),3)}
  if(!mini){c.fillStyle='#fff6';for(const th of b.pth)c.fillRect(b.x-w/2+w*th-.5,y,1.5,h);
    c.font='800 10px Montserrat,sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillStyle='#fff';c.strokeStyle='#000a';c.lineWidth=3;const tx=b.nm+(b.ph?' · '+'🔥'.repeat(Math.min(3,b.ph)):'');c.strokeText(tx,b.x,y-8);c.fillText(tx,b.x,y-8);
    if(b.cast){c.fillStyle='#ffe45e';c.strokeText('⚡ '+SKN[b.cast.k],b.x,y+h+9);c.fillText('⚡ '+SKN[b.cast.k],b.x,y+h+9)}}
}
function drawBossFx(){
  c.save();
  for(const e of bfx){
    switch(e.k){
     case'sp':c.globalAlpha=Math.max(0,1-e.t/e.dur);c.fillStyle=e.c;c.beginPath();c.arc(e.x,e.y,e.s*(1-e.t/e.dur*.5),0,TAU);c.fill();break;
     case'rg':{const p=e.t/e.dur;c.globalAlpha=(1-p)*.8;c.strokeStyle=e.c;c.lineWidth=6*(1-p)+1;c.beginPath();c.arc(e.x,e.y,e.r0+(e.r1-e.r0)*p,0,TAU);c.stroke();break}
     case'ring':{const p=e.t/e.dur,rad=e.r0+(e.r1-e.r0)*p;c.globalAlpha=(1-p)*.85;c.strokeStyle=e.c;c.lineWidth=14*(1-p)+2;c.beginPath();c.arc(e.x,e.y,rad,0,TAU);c.stroke();c.globalAlpha=(1-p)*.18;c.fillStyle=e.c;c.fill();break}
     case'beam':{const p=e.t/e.dur,dx=Math.cos(e.ang),dy=Math.sin(e.ang);c.globalAlpha=Math.min(1,(1-p)*1.6);c.lineCap='round';c.strokeStyle=e.c;c.lineWidth=e.w*(1-p*.5);c.beginPath();c.moveTo(e.x,e.y);c.lineTo(e.x+dx*e.len,e.y+dy*e.len);c.stroke();c.strokeStyle='#fff';c.lineWidth=e.w*.4*(1-p*.5);c.stroke();break}
     case'hole':{const p=Math.min(1,e.t/.5)*(e.t>e.dur-.5?(e.dur-e.t)/.5:1);c.globalAlpha=.9*p;const g=c.createRadialGradient(e.x,e.y,0,e.x,e.y,e.r*.5);g.addColorStop(0,'#000');g.addColorStop(.6,'rgba(60,20,110,.75)');g.addColorStop(1,'rgba(60,20,110,0)');c.fillStyle=g;c.beginPath();c.arc(e.x,e.y,e.r*.5,0,TAU);c.fill();
       c.strokeStyle='#c9a0ff';c.lineWidth=2.5;for(let i=0;i<4;i++){c.globalAlpha=.7*p;c.beginPath();for(let a=0;a<5.2;a+=.2){const rr=e.r*.5*(1-a/6)*(1-.12*i)+4,x=e.x+Math.cos(a+t*4+i*1.57)*rr,y=e.y+Math.sin(a+t*4+i*1.57)*rr;a?c.lineTo(x,y):c.moveTo(x,y)}c.stroke()}
       c.globalAlpha=.25*p;c.strokeStyle='#c9a0ff';c.setLineDash([6,10]);c.lineWidth=2;c.beginPath();c.arc(e.x,e.y,e.r,0,TAU);c.stroke();c.setLineDash([]);break}
     case'pool':{const p=Math.min(1,e.t/.4)*(e.t>e.dur-.8?(e.dur-e.t)/.8:1);c.globalAlpha=.5*p;const g=c.createRadialGradient(e.x,e.y,e.r*.2,e.x,e.y,e.r);g.addColorStop(0,'rgba(110,255,80,.75)');g.addColorStop(1,'rgba(110,255,80,.1)');c.fillStyle=g;c.beginPath();c.ellipse(e.x,e.y,e.r,e.r*.62,0,0,TAU);c.fill();c.strokeStyle='#8dff6a';c.lineWidth=2;c.globalAlpha=.7*p;c.stroke();
       c.fillStyle='#d4ffb0';c.globalAlpha=.7*p;for(let i=0;i<5;i++){c.beginPath();c.arc(e.x+Math.sin(t*2+i*1.9)*e.r*.6,e.y-((t*20+i*13)%(e.r*.6))+e.r*.2,2.5+i%2,0,TAU);c.fill()}break}
     case'bul':c.globalAlpha=1;c.fillStyle=e.c;c.strokeStyle='#fff';c.lineWidth=1.5;c.beginPath();c.moveTo(e.x+e.vx*.04,e.y+e.vy*.04);const a=Math.atan2(e.vy,e.vx);c.lineTo(e.x+Math.cos(a+2.5)*e.r,e.y+Math.sin(a+2.5)*e.r);c.lineTo(e.x-Math.cos(a)*e.r*.4,e.y-Math.sin(a)*e.r*.4);c.lineTo(e.x+Math.cos(a-2.5)*e.r,e.y+Math.sin(a-2.5)*e.r);c.closePath();c.fill();c.stroke();break;
     case'met':{const w=e.warn,p=Math.min(1,e.t/w);if(e.t<w+.3){c.globalAlpha=.25+.3*Math.sin(e.t*12)*.5+.2;c.strokeStyle='#ff5a3d';c.lineWidth=3;c.beginPath();c.arc(e.x,e.y,e.r*(.45+.55*p),0,TAU);c.stroke();c.fillStyle='rgba(255,90,61,.16)';c.beginPath();c.arc(e.x,e.y,e.r,0,TAU);c.fill()}
       if(e.t>=w&&e.t<w+.3){const q=(e.t-w)/.3,my=e.y-(1-q)*(e.y-TOP+80);c.globalAlpha=1;c.fillStyle='#6b4a3a';c.strokeStyle='#ffb454';c.lineWidth=3;c.beginPath();c.arc(e.x,my,e.r*.38,0,TAU);c.fill();c.stroke();c.strokeStyle='rgba(255,180,84,.6)';c.lineWidth=e.r*.25;c.beginPath();c.moveTo(e.x,my);c.lineTo(e.x,my-90);c.stroke()}break}
     case'tp':drawTapFx(c,e.x,e.y,e.lv,e.t/e.dur,e.seed);break;
    }
  }
  c.restore();c.globalAlpha=1;
  // đánh dấu choáng
  c.font='16px sans-serif';c.textAlign='center';c.textBaseline='middle';for(const u of units())if(u.stun>0){c.fillText('💫',u.x+Math.sin(t*8)*6,u.y-(u.role?46:24))}
  if(FLASH){const p=FLASH.t/FLASH.dur;c.globalAlpha=(1-p)*.45;c.fillStyle=FLASH.c;c.fillRect(-20,-20,W+40,H+40);c.globalAlpha=1}
}
// ---------- hiệu ứng chạm tay theo cấp (8 cấp: càng cao càng mạnh & đẹp) ----------
function drawTapFx(X,x,y,lv,p,seed){
  const col=TD[lv-1].c,a=1-p,n=Math.min(PF.spk,4+lv*3);X.save();X.translate(x,y);X.globalAlpha=a;X.strokeStyle=col;X.fillStyle=col;X.lineCap='round';
  const rnd=i=>{const s=Math.sin((seed||1)*12.9898+i*78.233)*43758.5453;return s-Math.floor(s)};
  if(lv>=2){X.lineWidth=3+lv*.6;X.beginPath();X.arc(0,0,14+p*(24+lv*6),0,TAU);X.stroke()}
  if(lv>=3&&lv<=4){X.lineWidth=3;for(let i=0;i<2;i++){X.beginPath();X.arc(0,0,22+p*20,-.9+i*Math.PI,-.1+i*Math.PI+p*.5);X.stroke()}}
  if(lv==4||lv==8){X.save();X.rotate(p*2);X.beginPath();for(let i=0;i<10;i++){const rr=i%2?9+p*6:20+p*18+(lv==8?10:0),a2=i/10*TAU;X.lineTo(Math.cos(a2)*rr,Math.sin(a2)*rr)}X.closePath();X.globalAlpha=a*.55;X.fill();X.restore()}
  if(lv==5){for(let i=0;i<5;i++){X.globalAlpha=a*.8;X.beginPath();X.ellipse((rnd(i)-.5)*30,-p*(18+rnd(i+9)*28),5-3*p,8-5*p,0,0,TAU);X.fill()}}
  if(lv==6){for(let i=0;i<6;i++){const a2=i/6*TAU+p*3,rr=12+p*34;X.globalAlpha=a*.85;X.beginPath();X.ellipse(Math.cos(a2)*rr,Math.sin(a2)*rr,6*(1-p*.5),3,a2,0,TAU);X.fill()}}
  if(lv>=7){X.lineWidth=2.5;for(let i=0;i<5;i++){let px=0,py=0,a2=rnd(i)*TAU;X.beginPath();X.moveTo(0,0);for(let k=0;k<4;k++){a2+=(rnd(i*4+k)-.5)*1.4;px+=Math.cos(a2)*(8+p*10);py+=Math.sin(a2)*(8+p*10);X.lineTo(px,py)}X.stroke()}}
  if(lv>=8){X.lineWidth=2;X.beginPath();X.arc(0,0,30+p*60,0,TAU);X.stroke();X.font='16px sans-serif';X.textAlign='center';X.globalAlpha=a;X.fillText('👑',0,-20-p*26)}
  for(let i=0;i<n;i++){const a2=rnd(i+30)*TAU,v=(14+rnd(i+60)*(30+lv*6))*p;X.globalAlpha=a*.9;X.beginPath();X.arc(Math.cos(a2)*v,Math.sin(a2)*v,Math.max(.6,(2+lv*.25)*(1-p)),0,TAU);X.fill()}
  X.restore();
}
function tapBoss(b,x,y){   // chạm tay vào Boss (điện thoại: chạm · máy tính: bấm chuột trái)
  if(CAMP.tapCd>0)return true;CAMP.tapCd=.25;const lv=CP.td,d=TD[lv-1].d;
  CAMP.taps++;bossHit(b,d,'tap',x,y-10,true);
  if(bfx.length<130)bfx.push({k:'tp',x,y,lv,t:0,dur:.35+lv*.04,seed:Math.random()*100});
  if(lv>=8&&Math.random()<.5)SHAKE=Math.max(SHAKE,.12);tapSfx(lv);return true;
}
