// ================= DỮ LIỆU CHẾ ĐỘ HẢI VỰC CHINH PHỤC: 6 vùng · 20 Boss · 60 ải =================
const ZONES=[
 {n:'Rạn San Hô Khởi Đầu',d:'Làm quen với biển cả',c1:'#46d6b8',c2:'#1b8f9c',ic:'🪸'},
 {n:'Vịnh Săn Mồi',d:'Vùng biển nguy hiểm',c1:'#ffb454',c2:'#d9622b',ic:'🦈'},
 {n:'Hang Tối Hoang Vu',d:'Bóng tối ngự trị',c1:'#8c7cf0',c2:'#4a3fa8',ic:'🌑'},
 {n:'Vực Sâu Huyền Bí',d:'Áp suất nghiền nát mọi thứ',c1:'#ff7ab8',c2:'#8a2f9c',ic:'🌀'},
 {n:'Lãnh Địa Chúa Biển',d:'Các lãnh chúa thức giấc',c1:'#ff6b5e',c2:'#8f1d2c',ic:'🔱'},
 {n:'Cung Điện Hải Vương',d:'Trận chiến cuối cùng',c1:'#ffd45e',c2:'#b3741a',ic:'👑'}];

// Boss: nm tên · r bán kính · hp · dmg (sát thương chạm) · spd tốc độ · atk nhịp đánh · eat giây để nuốt cá · ai c=đuổi k=giữ khoảng cách (keep px)
// c=[màu chính, màu viền, màu phát sáng] · vf giọng gầm (Hz) · sk=[[kỹ năng, hồi chiêu(s), giai đoạn tối thiểu]] · ph mốc máu đổi giai đoạn
const BD=[
 {nm:'Sứa Gai Lục',tag:'Sứa độc lơ lửng',z:0,r:52,hp:600,dmg:8,spd:42,atk:1.5,eat:5,ai:'c',c:['#8dffb0','#2e9d62','#7dffa8'],vf:210,sk:[['poison',14,0],['pulse',17,1]]},
 {nm:'Nóc Gai Phồng',tag:'Phồng người bắn gai',z:0,r:50,hp:700,dmg:9,spd:52,atk:1.4,eat:4.5,ai:'c',c:['#ffd36b','#c9822a','#ffe9a0'],vf:260,sk:[['burst',10,0],['pulse',16,1]]},
 {nm:'Cua Hoàng Đỏ',tag:'Càng búa choáng',z:0,r:58,hp:900,dmg:12,spd:38,atk:1.6,eat:5,ai:'c',c:['#ff6a5a','#a52a22','#ffb199'],vf:150,sk:[['pulse',9,0],['heal',28,1]]},
 {nm:'Mực Mặc Tối',tag:'Lao nhanh như tên',z:0,r:54,hp:800,dmg:10,spd:62,atk:1.3,eat:4,ai:'c',c:['#b38cff','#4b2a8f','#d7c2ff'],vf:320,sk:[['dash',9,0],['burst',12,1]]},
 {nm:'Mập Trắng Hung Tợn',tag:'Thợ săn tốc độ',z:1,r:66,hp:1800,dmg:16,spd:70,atk:1.2,eat:3.5,ai:'c',c:['#b8c7d9','#4a5a70','#e5f0ff'],vf:120,sk:[['dash',7,0],['heal',26,1]]},
 {nm:'Lươn Điện Tím',tag:'Tia sét tầm xa',z:1,r:58,hp:1600,dmg:14,spd:66,atk:1.3,eat:4,ai:'k',keep:290,c:['#ffe44d','#9a7a00','#fff6a8'],vf:380,sk:[['laser',8,0],['pulse',12,1]]},
 {nm:'Nhím Biển Độc',tag:'Khiên gai & độc',z:1,r:60,hp:2400,dmg:14,spd:34,atk:1.5,eat:5,ai:'c',c:['#a56bff','#35185c','#7dff6b'],vf:180,sk:[['poison',8,0],['burst',9,0],['shield',30,1]]},
 {nm:'Đuối Quỷ Bão Tố',tag:'Mưa thiên thạch',z:1,r:72,hp:2100,dmg:15,spd:58,atk:1.4,eat:4,ai:'c',c:['#5ab0ff','#1c4f99','#bfe0ff'],vf:200,sk:[['meteor',11,0],['heal',26,1],['dash',10,1]]},
 {nm:'Lồng Đèn Âm Phủ',tag:'Triệu hồi & hút máu',z:2,r:64,hp:2800,dmg:20,spd:48,atk:1.4,eat:3.5,ai:'k',keep:210,c:['#6fa8ff','#142a5c','#9ff6ff'],vf:100,sk:[['summon',12,0],['leech',15,0],['hole',20,1]]},
 {nm:'Bạch Tuộc Hư Ảnh',tag:'Phân thân đánh lừa',z:2,r:66,hp:3200,dmg:20,spd:52,atk:1.3,eat:3.5,ai:'c',c:['#d36bff','#5a1f80','#f0b3ff'],vf:230,sk:[['clone',14,0],['poison',12,0],['pulse',11,1]]},
 {nm:'Rùa Đá Cổ Đại',tag:'Giáp đá bất khuất',z:2,r:74,hp:4200,dmg:22,spd:30,atk:1.7,eat:5,ai:'c',c:['#8fa28c','#3f4d3d','#c9ffb5'],vf:90,sk:[['shield',24,0],['pulse',10,0],['heal',28,1]]},
 {nm:'Hải Mã Rồng',tag:'Hồi phục & tia lửa',z:2,r:62,hp:3000,dmg:21,spd:60,atk:1.2,eat:4,ai:'k',keep:240,c:['#ff9d5e','#a3401a','#ffd0a6'],vf:280,sk:[['burst',7,0],['heal',24,0],['laser',12,1]]},
 {nm:'Anh Vũ Hố Đen',tag:'Xoáy hút không gian',z:3,r:74,hp:4800,dmg:26,spd:38,atk:1.5,eat:4,ai:'c',c:['#ffa6d4','#7a2a66','#ff7ae0'],vf:110,sk:[['hole',14,0],['shield',26,0],['meteor',12,1]]},
 {nm:'Cưa Sắt Tử Thần',tag:'Cưa xé & lao mạnh',z:3,r:78,hp:4300,dmg:28,spd:75,atk:1.1,eat:3.2,ai:'c',c:['#9fb4c7','#3a4a5c','#ff8a4d'],vf:140,sk:[['dash',6,0],['laser',9,0],['stunall',22,1]]},
 {nm:'Sư Tử Biển Độc',tag:'Mưa gai & ảo ảnh',z:3,r:66,hp:4500,dmg:26,spd:56,atk:1.2,eat:3.5,ai:'c',c:['#ff5a4d','#7a1818','#ffd24d'],vf:240,sk:[['poison',9,0],['burst',6,0],['clone',16,1]]},
 {nm:'Thủy Quái Độc Nhãn',tag:'Mắt thần phá hủy',z:3,r:80,hp:5600,dmg:30,spd:48,atk:1.4,eat:3.5,ai:'k',keep:250,c:['#7affb0','#1a6a44','#c8ff5e'],vf:85,sk:[['laser',7,0],['stunall',18,0],['summon',14,1]]},
 {nm:'Kraken Vực Thẳm',tag:'Lãnh chúa xúc tu',z:4,r:92,hp:7500,dmg:34,spd:44,atk:1.3,eat:3,ai:'c',c:['#4fd1c5','#0e3d4a','#7affee'],vf:70,sk:[['summon',12,0],['meteor',9,0],['hole',16,1],['pulse',8,1]]},
 {nm:'Mập Ma Lưỡi Hái',tag:'Bóng ma săn mồi',z:4,r:84,hp:6800,dmg:36,spd:85,atk:1.0,eat:3,ai:'c',c:['#a8f0ff','#26606e','#e0ffff'],vf:130,sk:[['clone',12,0],['dash',6,0],['hole',15,1],['leech',12,1]]},
 {nm:'Thần Long Biển Sâu',tag:'Rồng nguyên tố',z:4,r:90,hp:8800,dmg:38,spd:60,atk:1.2,eat:3,ai:'k',keep:230,c:['#ffd45e','#0f6b7a','#7affd9'],vf:95,sk:[['heal',22,0],['shield',28,0],['laser',7,1],['stunall',16,1]]},
 {nm:'Hải Vương Tối Thượng',tag:'Chúa tể đại dương',z:5,r:112,hp:11000,dmg:45,spd:50,atk:1.2,eat:2.5,ai:'c',ph:[.75,.5,.25],c:['#ffd45e','#7a4a00','#fff3b0'],vf:60,
  sk:[['pulse',9,0],['burst',8,0],['summon',16,1],['meteor',12,1],['laser',10,1],['hole',24,2],['shield',30,2],['heal',36,2],['clone',18,2],['stunall',24,3],['poison',13,3],['dash',11,3],['leech',16,3]]}];
BD.forEach(b=>{if(!b.ph)b.ph=[.5,.25];b.rw=Math.round(b.hp/14/10)*10;b.eat=+(b.eat*1.4).toFixed(1);b.dmg=Math.max(5,Math.round(b.dmg*[.8,.6,.5,.45,.4,.4][b.z]))});   // sát thương Boss quy đổi theo máu thật của đơn vị (Chiến Binh 50→104 máu)

// Sơ đồ các đợt Boss: '|' = đợt kế tiếp (xuất hiện khi đợt trước bị hạ) · ',' = cùng xuất hiện (tối đa 5)
const WAVES=[
 '0','1','2','3','0|1','2,1','3|0','2,3','0|3|1','1|2,3',                                 // vùng 1: làm quen (1–2 Boss)
 '4','5','6','7','4|5','6,7','5|4','7,4','6|5,7','4,7|5,6',                              // vùng 2: tăng áp lực
 '8','9','10','11','8|9','10,11','9|8,11','8,10','11|9,10','8,11|9,10',                   // vùng 3: Boss có kỹ năng kết hợp
 '12','13','14','15','12,13','15,14','12,15|13','14,15|12,13','12,13,14','15|12,13,14',   // vùng 4: nhiều Boss, nhiều đợt
 '16','17','18','16|17','17,18','16,18|17','16,17|18','16,13|14','17,18|15','16,17|18,15',   // vùng 5: lãnh chúa
 '16,17','18,15|13','17|16,18','16,17|18','13,14,15|12','18,17|16,15','16,17,18|14','17,18|16,15','12,13,14,15,16','19']; // vùng 6: vây công (ải 59 = bầy 5 Boss cùng lúc) · ải 60 = Hải Vương (trận cuối)
const GA=[[1,2000],[2,3500],[3,5000],[10,12000],[20,22000],[30,34000],[40,46000],[50,58000],[60,72000]];
function goldReq(L){for(let i=1;i<GA.length;i++)if(L<=GA[i][0]){const a=GA[i-1],b=GA[i],v=a[1]+(b[1]-a[1])*(L-a[0])/(b[0]-a[0]);return Math.round(v/50)*50}return GA[GA.length-1][1]}
const hz=n=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x)};   // nhiễu ổn định theo số ải
const OBJ_K=['fast','noloss','lowhit','rich','taps','army'];

function startPack(L){   // đội hình ban đầu mỗi ải (mỗi ải bắt đầu hồ mới, không dùng vàng/đơn vị của Thủy Cung Bình Yên)
  const z=Math.floor((L-1)/10),k=(L-1)%10,p={coins:300+z*260+k*40,lv:Math.min(3,1+z),cap:10+5*z,wcap:5,scap:5,ccap:5,fish:[],sw:[],hs:[],cr:[]};
  const nf=4+z*2+Math.floor(k/3);for(let i=0;i<nf;i++)p.fish.push(z>=2||i<2*z?1:0);for(let i=0;i<Math.min(nf,z+1);i++)p.fish[i]=2;
  const ns=[1,2,4,6,9,14][z]+(k>=5?1:0);for(let i=0;i<ns;i++)p.sw.push(Math.min(4,1+Math.floor(z/1.5)));
  const nh=[0,1,1,2,3,5][z];for(let i=0;i<nh;i++)p.hs.push(Math.min(3,1+Math.floor(z/2)));
  const nc=[0,0,1,2,3,4][z];for(let i=0;i<nc;i++)p.cr.push(Math.min(3,1+Math.floor(z/2)));
  p.wcap=Math.max(5,ns+2);p.scap=Math.max(5,nh+2);p.ccap=Math.max(5,nc+2);return p;
}
// ---- Hiệu chỉnh ngưỡng sao bằng MÔ PHỎNG: bot (nuôi cá, vuốt ve, mua quân, chạm Boss, trả vàng) chơi các ải mẫu để đo
// [ải, thời gian hoàn thành(s), thời gian hạ Boss(s), số lần Boss gây sát thương, số đơn vị mất]. Các ải còn lại được nội suy
// rồi điều chỉnh theo tổng máu Boss, số đợt và độ khó của chính ải đó.
const PAR=[[1,354,29,16,0],[5,515,64,19,0],[10,613,65,34,1],[15,651,75,27,0],[20,760,97,92,4],[25,653,83,33,0],[30,756,112,121,7],[35,811,53,109,17],[40,723,121,182,6],[45,690,98,164,4],[50,835,213,390,24],[55,680,121,211,4],[57,817,173,563,34],[59,751,89,456,24],[60,764,87,336,15]];
const hpSum=(l,hpM)=>l.flat().reduce((a,b)=>a+BD[b].hp*hpM,0);
const LV=WAVES.map((s,i)=>{
  const L=i+1,z=Math.floor(i/10),wv=s.split('|').map(w=>w.split(',').map(Number)),nb=wv.flat().length,j=hz(L);
  const simul=Math.max(...wv.map(w=>w.length)),sf=simul>=4?.6:simul==3?.8:1;   // nhiều Boss cùng lúc: mỗi Boss yếu đi, độ khó đến từ SỐ LƯỢNG chứ không phải máu
  const hpM=(1+(L-1)*.02)*sf,dmgM=(1+(L-1)*.012)*(simul>=4?.75:simul==3?.9:1),cdM=Math.max(.62,1-(L-1)*.0065),spdM=1+(L-1)*.004;
  const G=goldReq(L),grace=Math.round(76+2.2*L+j*12)+(L==60?60:0),gap=28+z*3+Math.round(j*8);
  return{n:L,z,wv,nb,simul,G,grace,gap,hpM,dmgM,cdM,spdM,start:startPack(L),hp:hpSum(wv,hpM),j};
});
function parAt(L,k){let a=PAR[0],b=PAR[PAR.length-1];for(let i=1;i<PAR.length;i++)if(L<=PAR[i][0]){a=PAR[i-1];b=PAR[i];break}
  if(L<=PAR[0][0])return PAR[0][k];if(L>=b[0])return b[k];const u=(L-a[0])/(b[0]-a[0]);return a[k]+(b[k]-a[k])*u}
function parHp(L){let a=PAR[0],b=PAR[PAR.length-1];for(let i=1;i<PAR.length;i++)if(L<=PAR[i][0]){a=PAR[i-1];b=PAR[i];break}
  const ha=LV[a[0]-1].hp,hb=LV[b[0]-1].hp;if(L<=a[0])return ha;if(L>=b[0])return hb;return ha+(hb-ha)*(L-a[0])/(b[0]-a[0])}
LV.forEach(l=>{
  const L=l.n,rel=Math.max(.5,Math.min(2,l.hp/parHp(L))),fightPar=parAt(L,2)*Math.pow(rel,.9),Tpar=parAt(L,1)+(fightPar-parAt(L,2))+(l.wv.length>1?l.gap*.4*(l.wv.length-1):0);
  const hitsPar=parAt(L,3)*(fightPar/parAt(L,2))*(.93+.14*l.j),lostPar=Math.max(.5,parAt(L,4)*rel);
  l.t3=Math.round(Tpar*1.05/5)*5;l.t2=Math.round(Tpar*1.5/5)*5;l.tmax=Math.round(Tpar*2.2/5)*5;
  l.fightIdeal=Math.round(fightPar*1.15/5)*5+10;l.hitsOK=Math.round(hitsPar*.85)+4;l.hitsMax=Math.round(l.hitsOK*2.5);l.lostCap=Math.max(6,Math.round(lostPar*2)+5);
  l.th2=Math.round(52+L*.1+l.j*5);l.th3=Math.round(78+L*.08+l.j*4);
  const k=OBJ_K[(L-1)%6];l.obj={k,p:k=='fast'?Math.round((fightPar*1.1+8)/5)*5:k=='lowhit'?Math.max(3,Math.round(hitsPar*.7)):k=='taps'?10+l.nb*8+L:k=='army'?Math.max(2,2+l.z*2):k=='rich'?25:0};
  const o=l.obj;o.txt={fast:`Hạ toàn bộ Boss trong ${o.p} giây kể từ khi xuất hiện`,noloss:'Không để mất bất kỳ cá hay đơn vị chiến đấu nào',lowhit:`Boss gây sát thương không quá ${o.p} lần`,rich:`Còn lại ≥ ${Math.round(l.G*o.p/100).toLocaleString('vi')} vàng sau khi trả nhiệm vụ`,taps:`Chạm trúng Boss ít nhất ${o.p} lần`,army:`Còn ≥ ${o.p} Chiến Binh sống sót khi hoàn thành`}[k];
});
// Sát thương chạm (đồng bộ cùng sát thương Chiến Binh: tối đa 4 lần chạm/giây, tối đa ~72) · chi phí bằng 🐚 Ngọc trai (chỉ kiếm trong chế độ này)
const TD=[
 {d:5,cost:0,c:'#ffffff',n:'Chạm Khẽ'},{d:8,cost:25,c:'#7fe0ff',n:'Chạm Gió'},{d:12,cost:60,c:'#7dffa8',n:'Vuốt Lá'},{d:18,cost:115,c:'#ffe45e',n:'Tia Vàng'},
 {d:26,cost:200,c:'#ffa04d',n:'Ngọn Lửa'},{d:36,cost:330,c:'#ff6b8e',n:'Hồng Liên'},{d:48,cost:520,c:'#b78cff',n:'Sấm Tím'},{d:64,cost:800,c:'#fff2a8',n:'Thần Chạm'}];
