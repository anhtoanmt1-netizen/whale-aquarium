// ================= GIAO DIỆN HẢI VỰC CHINH PHỤC =================
(function build(){
  const d=document.createElement('div');d.innerHTML=`
<div id="chud"><div class="crow"><div class="cl"><b id="chl">Ải 1</b><span id="cht">⏱ 00:00</span></div><div class="cb" id="chb">👹 …</div><button class="cx" id="chtd" aria-label="Sức mạnh chạm">✋ 1</button><button class="cx" id="chexit" aria-label="Rời ải">🗺️</button></div>
 <div class="crow"><div class="cqb"><i id="cqf"></i><span id="cqt">🎯 🪙 0 / 0</span></div><button class="cqg" id="cqbtn" disabled>Trả nhiệm vụ</button></div></div>
<div class="ov" id="lvsel"><div class="pn lvp">
  <div class="lvh"><div class="ph"><button class="x" id="lvback" aria-label="Về Menu">‹</button><h3>🌊 Hải Vực Chinh Phục</h3><button class="pill" id="lvtd">✋ Sức mạnh</button></div>
   <div class="lvst"><span id="lvdone">✅ 0/60 ải</span><span id="lvstars">⭐ 0/180</span><span id="lvpearl"><i class="prl"></i> 0</span></div><div class="lvbar"><i id="lvbarf"></i></div><div class="lvz" id="lvz"></div><div class="lvzn" id="lvzn"></div></div>
  <div class="lvs" id="lvlist"></div></div></div>
<div class="ov" id="lvinfo"><div class="pn lvi"><div class="ph"><h3 id="lvit"></h3><button class="x" id="lviclose" aria-label="Đóng">✕</button></div><div id="lvib"></div>
  <div class="two"><button class="m g" id="lvino">Đóng</button><button class="m p" id="lvigo">▶ Vào ải</button></div></div></div>
<div class="ov" id="tdp"><div class="pn lvi"><div class="ph"><h3>✋ Sức mạnh chạm</h3><div class="pill" id="tdpearl"><i class="prl"></i> 0</div><button class="x" id="tdclose" aria-label="Đóng">✕</button></div><div id="tdb"></div></div></div>
<div class="ov" id="cres" style="z-index:11"><div class="pn lvi res" id="cresp"></div></div>`;
  while(d.firstChild)document.body.appendChild(d.firstChild);
})();
if(window.ResizeObserver)new ResizeObserver(()=>measureHud()).observe($('chud'));
const fmtT=s=>{s=Math.max(0,Math.round(s));return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')};
const nf=v=>Number(v).toLocaleString('vi');
const LONGART={3:1,4:1,5:1,13:1,17:1,18:1,7:1,16:1,19:1};
function portrait(cv,bid,locked,k){
  const X=cv.getContext('2d'),s=cv.width,d=BD[bid],r=s*(LONGART[bid]?.19:.25)*(k||1);X.clearRect(0,0,s,s);X.save();X.translate(s/2+(LONGART[bid]?s*.06:0),s/2+s*.03);
  try{ART[bid](X,r,1.2,{c:d.c,cast:0,ph:0,look:1})}catch(e){}X.restore();
  if(locked){X.globalCompositeOperation='source-atop';X.fillStyle='rgba(8,24,44,.82)';X.fillRect(0,0,s,s);X.globalCompositeOperation='source-over'}
}
const leadBoss=L=>Math.max(...LV[L-1].wv.flat());
let lvBuilt=false;
function buildLvList(){
  let h='<div class="lvg">';
  for(let L=1;L<=60;L++){const z=Math.floor((L-1)/10),Z=ZONES[z];h+=`<button class="lc${L%10==1?' zfirst':''}" data-l="${L}" data-z="${z}" style="--z1:${Z.c1};--z2:${Z.c2}"><canvas width="88" height="88"></canvas><b>${L}</b><em class="ls"></em><span class="lk">🔒</span>${L%10==1?'<s>Vùng '+(z+1)+'</s>':''}</button>`}
  $('lvlist').innerHTML=h+'</div>';
  $('lvz').innerHTML=ZONES.map((Z,z)=>`<button data-z="${z}" style="--z1:${Z.c1};--z2:${Z.c2}">${Z.ic}<small>${z+1}</small></button>`).join('');
  document.querySelectorAll('#lvlist .lc').forEach(b=>portrait(b.querySelector('canvas'),leadBoss(+b.dataset.l),false));lvBuilt=true;
}
function lvZoneNow(){const sc=$('lvlist'),cells=[...sc.querySelectorAll('.lc')],top=sc.getBoundingClientRect().top+30;let z=0;for(const b of cells){if(b.getBoundingClientRect().bottom>top){z=+b.dataset.z;break}}
  const Z=ZONES[z];$('lvzn').innerHTML=Z.ic+' <b>Vùng '+(z+1)+' · '+Z.n+'</b> — '+Z.d;$('lvzn').style.setProperty('--z1',Z.c1);$('lvzn').style.setProperty('--z2',Z.c2);
  $('lvz').querySelectorAll('button').forEach(x=>x.classList.toggle('on',+x.dataset.z==z))}
function renderLvSel(){
  if(!lvBuilt)buildLvList();const st=campStats();
  $('lvdone').textContent='✅ '+st.done+'/60 ải';$('lvstars').textContent='⭐ '+st.st+'/180';$('lvpearl').innerHTML=PRL+' '+nf(CP.pearls);$('lvbarf').style.width=(st.done/60*100)+'%';
  let cur=-1;
  document.querySelectorAll('#lvlist .lc').forEach(b=>{const L=+b.dataset.l,r=CP.rec[L-1],un=unlocked(L-1),cv=b.querySelector('canvas');
    const state=r.s>0?'done':un?'open':'lock';if(b.dataset.st!==state){b.dataset.st=state;b.className='lc '+state;portrait(cv,leadBoss(L),!un)}
    b.querySelector('.ls').textContent=r.s>0?'★'.repeat(r.s)+'☆'.repeat(3-r.s):un?'':'';if(state=='open'&&cur<0)cur=L});
  lvZoneNow();if(cur<0)cur=60;return cur;
}
function openLvSel(){const cur=renderLvSel();$('lvsel').classList.add('on');setTimeout(()=>{const b=document.querySelector('#lvlist .lc[data-l="'+cur+'"]');if(b)b.scrollIntoView({block:'center',behavior:'smooth'})},60)}
$('lvlist').addEventListener('click',e=>{const b=e.target.closest('.lc');if(!b)return;const L=+b.dataset.l;
  if(!unlocked(L-1)){b.classList.remove('shake');void b.offsetWidth;b.classList.add('shake');say('🔒 Hoàn thành Ải '+(L-1)+' trước để mở khóa Ải '+L);return}
  b.classList.remove('pick');void b.offsetWidth;b.classList.add('pick');openLvInfo(L)});
let infoL=1;
function openLvInfo(L){
  infoL=L;const lv=LV[L-1],r=CP.rec[L-1],Z=ZONES[lv.z],ids=[...new Set(lv.wv.flat())];
  $('lvit').innerHTML=Z.ic+' Ải '+L+' <small style="font-weight:600;color:#6f8aa3">'+Z.n+'</small>';
  const sides=lv.wv.map((w,wi)=>w.map((b,j)=>SIDEN[SIDES[(L+wi+j)%4]]).join(', ')).map((s,i)=>'Đợt '+(i+1)+': '+s).join(' · ');
  let h=`<div class="li-sec"><b>🎯 Điều kiện hoàn thành</b><p>① Thu thập và trả <b>🪙 ${nf(lv.G)}</b> vàng (chỉ trừ khi bạn xác nhận) &nbsp;② Hạ toàn bộ Boss (${lv.wv.length} đợt, tối đa ${Math.max(...lv.wv.map(w=>w.length))} Boss cùng lúc)</p></div>
  <div class="li-sec"><b>👹 Boss</b><div class="bl">${ids.map(i=>`<div class="bc"><canvas width="64" height="64" data-b="${i}"></canvas><span>${BD[i].nm}</span><small>❤️ ${nf(Math.round(BD[i].hp*lv.hpM))} · ${BD[i].tag}</small></div>`).join('')}</div><p class="sm">Hướng xuất hiện — ${sides}</p></div>
  <div class="li-sec"><b>⭐ Cách tính sao</b><p>⭐ Hoàn thành ải · ⭐⭐ Điểm ≥ <b>${lv.th2}</b> · ⭐⭐⭐ Điểm ≥ <b>${lv.th3}</b> (tối đa 100)<br><span class="sm">Điểm = thời gian (đầy khi ≤ ${fmtT(lv.t3)}, về 0 khi ≥ ${fmtT(lv.tmax)}) 30 + sống sót (mất ≤ ${lv.lostCap}) 25 + Boss gây sát thương ≤ ${lv.hitsOK} lần 20 + hạ Boss ≤ ${lv.fightIdeal}s 15 + mục tiêu phụ 10<br>🎖️ Mục tiêu phụ: ${lv.obj.txt}</span></p></div>`;
  if(r.c>0||r.n>0)h+=`<div class="li-sec rec"><b>🏆 Thành tích tốt nhất</b>${r.s>0?`<div class="rg"><div><small>Sao</small><b>${'★'.repeat(r.s)}${'☆'.repeat(3-r.s)}</b></div><div><small>Thời gian</small><b>${fmtT(r.t)}</b></div><div><small>Boss đã hạ</small><b>${r.k}</b></div><div><small>Bị tấn công</small><b>${r.h<0?'—':r.h+' lần'}</b></div><div><small>Vàng thu</small><b>${nf(r.g)}</b></div><div><small>Điểm</small><b>${r.sc}</b></div></div><p class="sm">Đã chơi ${r.n} lần · thắng ${r.c} lần</p>`:`<p class="sm">Chưa hoàn thành · đã thử ${r.n} lần</p>`}</div>`;
  $('lvib').innerHTML=h;$('lvib').querySelectorAll('canvas[data-b]').forEach(cv=>portrait(cv,+cv.dataset.b,false));
  $('lvigo').textContent=r.s>0?'↻ Chơi lại':'▶ Vào ải';$('lvinfo').classList.add('on');
}
$('lviclose').onclick=$('lvino').onclick=()=>$('lvinfo').classList.remove('on');
$('lvigo').onclick=()=>{$('lvinfo').classList.remove('on');beginCampLevel(infoL)};
$('lvlist').addEventListener('scroll',()=>{if(!lvBuilt)return;clearTimeout(window.__lvz);window.__lvz=setTimeout(lvZoneNow,40)});
$('lvz').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const c0=document.querySelector('#lvlist .lc[data-l="'+(+b.dataset.z*10+1)+'"]');if(c0)c0.scrollIntoView({block:'start',behavior:'smooth'})});
$('lvback').onclick=()=>{$('lvsel').classList.remove('on');if(typeof menuShow=='function')menuShow()};
$('lvtd').onclick=()=>openTdp();

// ---------- sát thương chạm ----------
let tdTimer=null;
function openTdp(){renderTdp();$('tdp').classList.add('on');if(tdTimer)clearInterval(tdTimer);
  tdTimer=setInterval(()=>{const cv=$('tdb').querySelector('canvas');if(!cv||!$('tdp').classList.contains('on')){clearInterval(tdTimer);tdTimer=null;return}
    const X=cv.getContext('2d'),w=cv.width,h=cv.height,ph=(performance.now()/1000)%1.2/1.2,k=Math.floor(performance.now()/1200);X.clearRect(0,0,w,h);
    X.save();X.globalAlpha=.55;X.translate(w/2,h/2+4);try{ART[0](X,34,performance.now()/1000,{c:BD[0].c,cast:0,ph:0,look:1})}catch(e){}X.restore();drawTapFx(X,w/2,h/2,CP.td,ph,k*7.3)},60)}
function renderTdp(){
  const lv=CP.td,cur=TD[lv-1],nx=TD[lv];$('tdpearl').innerHTML=PRL+' '+nf(CP.pearls);
  let h=`<div class="tdv" style="--c:${cur.c}"><canvas width="220" height="120"></canvas><div><b>Cấp ${lv}/${TD.length} · ${cur.n}</b><div class="tdd">💥 ${cur.d} sát thương mỗi lần chạm</div><small>Tối đa 4 lần chạm/giây · tính cùng hệ thống sát thương với Chiến Binh</small></div></div>`;
  h+='<div class="tdl">'+TD.map((t,i)=>`<div class="tdr${i+1==lv?' cur':''}${i+1<lv?' got':''}" style="--c:${t.c}"><i></i><b>Cấp ${i+1} · ${t.n}</b><span>💥 ${t.d}</span><em>${i+1<=lv?'✓':PRL+' '+nf(t.cost)}</em></div>`).join('')+'</div>';
  h+=nx?`<button class="m p" id="tdup" ${CP.pearls<nx.cost?'disabled':''}>⬆️ Nâng lên Cấp ${lv+1} · ${PRL} ${nf(nx.cost)}</button><p class="sm" style="text-align:center">${PRL} Ngọc trai nhận được khi hoàn thành ải lần đầu và khi đạt thêm sao, hoặc đổi từ vàng ở Thủy Cung Bình Yên (${nf(PEARL_RATE)} vàng = 1 ngọc trai).<br>Sát thương chạm áp dụng khi đánh Boss trong Hải Vực Chinh Phục.</p>${MODE==='peace'?`<button class="m g" id="tdbuy" ${S.coins<PEARL_RATE?'disabled':''}>🪙 Đổi ${nf(PEARL_RATE)} vàng lấy 1 ${PRL}</button>`:''}`:'<p class="sm" style="text-align:center">⭐ Đã đạt cấp tối đa!</p>';
  $('tdb').innerHTML=h;const tb=$('tdbuy');if(tb)tb.onclick=()=>{buyPearls(1);renderTdp()};const u=$('tdup');if(u)u.onclick=()=>{const n=TD[CP.td];if(n&&CP.pearls>=n.cost){CP.pearls-=n.cost;CP.td++;saveCamp();say('✋ Sức mạnh chạm lên Cấp '+CP.td+'! 💥 '+TD[CP.td-1].d);bsfx('heal');renderTdp();campHud(true)}};
}
$('tdclose').onclick=()=>$('tdp').classList.remove('on');$('chtd').onclick=()=>openTdp();

// ---------- HUD trong ải ----------
function campHud(force){
  if(MODE!=='camp'||!CAMP)return;CAMP.hudT-=1/30;if(CAMP.hudT>0&&!force)return;CAMP.hudT=.2;
  const L=LV[CAMP.lv-1],G=L.G,have=CAMP.paid?G:Math.min(S.coins,G),tx=(e,v)=>{if(e.textContent!==v)e.textContent=v};
  tx($('chl'),'Ải '+CAMP.lv);tx($('cht'),'⏱ '+fmtT(CAMP.t));tx($('chtd'),'✋ '+CP.td);
  const alive=bosses.filter(b=>!b.mini&&!b.fake&&b.state!=='dying').length,wv=Math.max(0,CAMP.wave+1);
  tx($('chb'),CAMP.bossDone?'💀 Boss đã bị hạ':CAMP.wave<0?'⏳ Boss sau '+Math.max(0,Math.ceil(CAMP.gapT))+'s':'👹 Đợt '+wv+'/'+L.wv.length+' · còn '+alive);
  $('cqf').style.width=(have/G*100)+'%';tx($('cqt'),CAMP.paid?'✅ Đã trả '+nf(G)+' 🪙':'🎯 🪙 '+nf(Math.min(S.coins,99999999))+' / '+nf(G));
  const b=$('cqbtn');b.disabled=CAMP.paid||S.coins<G;b.classList.toggle('rdy',!CAMP.paid&&S.coins>=G);tx(b,CAMP.paid?'✓ Đã trả':'Trả nhiệm vụ');
}
$('cqbtn').onclick=payQuest;
$('chexit').onclick=()=>{if(!CAMP||CAMP.over){leaveCamp();return}campConfirm('Rời Ải '+CAMP.lv+'?<br><small style="color:#6f8aa3">Tiến trình ải hiện tại sẽ mất. Thành tích đã lưu và Thủy Cung Bình Yên vẫn được giữ nguyên.</small>','Rời ải',leaveCamp)};

// ---------- tổng kết ----------
function showResult(){
  const rs=CAMP.res,p=$('cresp');
  if(!CAMP.win){p.innerHTML=`<div class="rt lose">💔 THẤT BẠI</div><p class="sm" style="text-align:center">${rs.why}</p><div class="two"><button class="m g" id="rmap">🗺️ Bản đồ</button><button class="m p" id="rretry">↻ Thử lại</button></div>`}
  else{const sr=rs.sr,L=LV[CAMP.lv-1],r=rs.rec,o=rs.old,nw=(a,b,lo)=>lo?(b>=0&&(a<0||b<a)):(b>a);
    const row=(ic,lb,v,rec)=>`<div class="rr"><span>${ic} ${lb}</span><b>${v}${rec?' <u>🏆 Kỷ lục</u>':''}</b></div>`;
    const bar=(lb,v,m)=>`<div class="pb"><span>${lb}</span><i><u style="width:${v/m*100}%"></u></i><b>${v}/${m}</b></div>`;
    p.innerHTML=`<div class="rt">🏆 CHIẾN THẮNG!</div><div class="rz">Ải ${CAMP.lv} · ${ZONES[L.z].n}</div>
    <div class="rstars">${[1,2,3].map(i=>`<span class="${i<=sr.stars?'on':''}" style="--i:${i}">★</span>`).join('')}</div>
    <div class="rsc">Điểm <b>${sr.sc}</b>/100${rs.newStars?` · <em>+${rs.newStars} sao mới</em>`:''}</div>
    <div class="rbars">${bar('⏱ Thời gian',sr.p.time,30)}${bar('🐟 Sống sót',sr.p.surv,25)}${bar('🛡️ Ít bị tấn công',sr.p.hits,20)}${bar('⚔️ Hiệu quả',sr.p.eff,15)}${bar('🎖️ Mục tiêu phụ',sr.p.obj,10)}</div>
    <div class="rrows">${row('⏱','Thời gian',fmtT(CAMP.t),!o.t||CAMP.t<o.t)}${row('💀','Boss đã hạ',CAMP.kills,CAMP.kills>o.k)}${row('💢','Bị Boss tấn công',CAMP.hits+' lần',nw(o.h,CAMP.hits,1))}${row('😢','Đã mất',CAMP.lost+' đơn vị',nw(o.l,CAMP.lost,1))}${row('🪙','Vàng thu được',nf(CAMP.gold),CAMP.gold>o.g)}</div>
    <div class="rpl">${PRL} +${rs.pearls} Ngọc trai${rs.first?' (lần đầu hoàn thành)':''}${!rs.pearls?' <small>(chỉ nhận khi đạt thêm sao)</small>':''}</div>
    <div class="rtip">🎖️ ${L.obj.txt}: <b>${objMet(L,sr.fightT)?'ĐẠT ✓':'chưa đạt'}</b></div>
    <div class="two"><button class="m g" id="rmap">🗺️ Bản đồ</button><button class="m g" id="rretry">↻ Chơi lại</button>${CAMP.lv<60?'<button class="m p" id="rnext">Ải tiếp ▶</button>':''}</div>`}
  $('cres').classList.add('on');
  $('rmap').onclick=()=>{$('cres').classList.remove('on');leaveCamp()};
  $('rretry').onclick=()=>{$('cres').classList.remove('on');beginCampLevel(CAMP.lv)};
  const nx=$('rnext');if(nx)nx.onclick=()=>{$('cres').classList.remove('on');beginCampLevel(CAMP.lv+1)};
}

// ---- đổi vàng lấy ngọc trai (chỉ ở Thủy Cung Bình Yên) · tỉ lệ cố định 5.000 vàng = 1 ngọc trai
function buyPearls(n){
  if(MODE!=='peace'){say('Chỉ đổi ngọc trai ở Thủy Cung Bình Yên');return false}
  const cost=n*PEARL_RATE;if(S.coins<cost){say('Cần '+nf(cost)+' vàng để đổi '+n+' ngọc trai');return false}
  S.coins-=cost;CP.pearls+=n;saveCamp();save();say('Đã đổi '+nf(cost)+' vàng lấy '+n+' ngọc trai! Tổng: '+nf(CP.pearls));bsfx('heal');return true}
$('pearl').onclick=()=>buyPearls(1);
$('pearl10').onclick=()=>{if(S.coins<10*PEARL_RATE){say('Cần '+nf(10*PEARL_RATE)+' vàng để đổi 10 ngọc trai');return}campConfirm('Đổi <b>'+nf(10*PEARL_RATE)+' vàng</b> lấy <b>10 '+PRL+' ngọc trai</b>?','Đổi',()=>buyPearls(10))};
$('tdbtn').onclick=()=>openTdp();
