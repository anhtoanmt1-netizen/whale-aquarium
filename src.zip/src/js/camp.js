// ================= CHẾ ĐỘ HẢI VỰC CHINH PHỤC: tiến trình · phiên ải · nhiệm vụ vàng · chấm sao · kỷ lục =================
// Thiết kế kinh tế: mỗi ải là một hồ MỚI với ví vàng và đội hình riêng (startPack) → không thể "cày" ở Thủy Cung Bình Yên rồi mang vàng sang,
// và ngược lại. Phần chung duy nhất là 🐚 Ngọc trai (chỉ kiếm trong chế độ này) dùng để nâng sát thương chạm.
const CPKEY='whale_camp',GK=['coins','lv','cap','wcap','scap','ccap','fish','warriors','supports','crabList','crabs','swords','horses'];
const newRec=()=>({s:0,t:0,k:0,h:-1,g:0,sc:0,n:0,c:0,l:-1});
function migrateCamp(o){   // nâng cấp / kiểm tra dữ liệu: thiếu → mặc định, hỏng → bỏ qua phần hỏng
  const n=(v,d,lo,hi)=>{v=Number.isFinite(+v)&&v!==null&&v!==''?+v:d;return Math.max(lo,Math.min(hi,v))};
  const cp={v:1,pearls:0,td:1,rec:[],hist:[],tot:{plays:0,clears:0,kills:0,taps:0}};
  if(o&&typeof o=='object'){
    cp.pearls=Math.floor(n(o.pearls,0,0,1e9));cp.td=Math.floor(n(o.td,1,1,TD.length));
    const r=Array.isArray(o.rec)?o.rec:[];for(let i=0;i<60;i++){const q=r[i]&&typeof r[i]=='object'?r[i]:{},x=newRec();
      x.s=Math.floor(n(q.s,0,0,3));x.t=n(q.t,0,0,1e6);x.k=Math.floor(n(q.k,0,0,1e4));x.h=Math.floor(n(q.h,-1,-1,1e6));x.g=Math.floor(n(q.g,0,0,1e9));x.sc=Math.floor(n(q.sc,0,0,100));x.n=Math.floor(n(q.n,0,0,1e6));x.c=Math.floor(n(q.c,0,0,1e6));x.l=Math.floor(n(q.l,-1,-1,1e6));
      if(x.s>0&&x.c<1)x.c=1;cp.rec.push(x)}
    if(Array.isArray(o.hist))cp.hist=o.hist.filter(h=>h&&typeof h=='object').slice(-40).map(h=>({lv:Math.floor(n(h.lv,1,1,60)),s:Math.floor(n(h.s,0,0,3)),t:n(h.t,0,0,1e6),sc:Math.floor(n(h.sc,0,0,100)),d:n(h.d,0,0,9e15)}));
    if(o.tot&&typeof o.tot=='object')for(const k in cp.tot)cp.tot[k]=Math.floor(n(o.tot[k],0,0,1e9));
  }
  if(cp.rec.length<60)for(let i=cp.rec.length;i<60;i++)cp.rec.push(newRec());
  return cp;
}
function loadCamp(){let raw=null;try{raw=JSON.parse(localStorage.getItem(CPKEY)||'null')}catch(e){raw=null}return migrateCamp(raw)}
let CP=loadCamp(),CAMP=null;
function saveCamp(){try{localStorage.setItem(CPKEY,JSON.stringify(CP))}catch(e){}}
function persistCamp(){   // đang ở ải: KHÔNG ghi đè dữ liệu Thủy Cung Bình Yên bằng dữ liệu của ải
  try{localStorage.setItem('whale1',JSON.stringify(Object.assign({},S,PEACE||{})))}catch(e){}saveCamp();
}
const unlocked=i=>i==0||CP.rec[i-1].s>=1;
const campStats=()=>{let done=0,st=0;for(const r of CP.rec){if(r.s>0)done++;st+=r.s}return{done,st}};
function earn(v){S.coins+=v;if(MODE==='camp'&&CAMP)CAMP.gold+=v}

function clearWorld(){
  fish=[];food=[];coins=[];bubbles=[];crabs=[];swords=[];horses=[];fx=[];dn.length=0;alien=null;alienT=R(35,55);
  bosses=[];bfx=[];cHeart=[];SHL=null;THREAT=null;SHAKE=0;SHKX=SHKY=0;FLASH=null;
}
function campStart(L){
  const lv=LV[L-1];if(!lv||!unlocked(L-1))return false;
  if(MODE!=='camp'){save();PEACE={};for(const k of GK)PEACE[k]=S[k]}     // chụp lại Thủy Cung Bình Yên (đã đồng bộ từ đơn vị đang sống)
  const p=lv.start;
  Object.assign(S,{coins:p.coins,lv:p.lv,cap:p.cap,wcap:p.wcap,scap:p.scap,ccap:p.ccap,fish:p.fish.map(st=>({stage:st,hunger:0})),warriors:p.sw.map(l=>({lv:l})),supports:p.hs.map(l=>({lv:l})),crabList:p.cr.map(l=>({lv:l})),crabs:p.cr.length,swords:0,horses:0});
  clearWorld();MODE='camp';loadWorld();
  CAMP={lv:L,t:0,wave:-1,gapT:lv.grace,bossT0:null,fightEnd:null,bossDone:false,paid:false,paidGold:0,over:false,win:false,gold:0,kills:0,hits:0,lost:0,dealt:0,taps:0,tapCd:0,hudT:0,res:null};
  CP.rec[L-1].n++;CP.tot.plays++;saveCamp();
  say('Ải '+L+': nộp '+lv.G.toLocaleString('vi')+' 🪙 và hạ Boss. Boss đầu tiên sẽ xuất hiện sau ~'+Math.round(lv.grace)+' giây!');
  return true;
}
function campExit(){   // trở về Thủy Cung: khôi phục đúng dữ liệu cũ
  if(MODE!=='camp')return;Object.assign(S,PEACE);PEACE=null;CAMP=null;MODE='menu';clearWorld();loadWorld();save();
}
function spawnWave(){
  const L=LV[CAMP.lv-1],w=L.wv[++CAMP.wave];if(!w)return;
  w.forEach((bid,j)=>spawnBoss(bid,L,SIDES[(CAMP.lv+CAMP.wave+j)%4],j,w.length));
  if(CAMP.bossT0==null)CAMP.bossT0=CAMP.t;CAMP.gapT=L.gap;
}
function payQuest(){
  if(!CAMP||CAMP.paid||CAMP.over)return;const G=LV[CAMP.lv-1].G;
  if(S.coins<G){say('Chưa đủ vàng để trả nhiệm vụ 🪙');return}
  campConfirm('Trả nhiệm vụ <b>🪙 '+G.toLocaleString('vi')+'</b> vàng cho Ải '+CAMP.lv+'?<br><small style="color:#6f8aa3">Vàng chỉ bị trừ khi bạn xác nhận. Bạn vẫn có thể chơi tiếp và trả sau.</small>','Trả vàng',()=>{
    if(!CAMP||CAMP.paid||S.coins<G)return;S.coins-=G;CAMP.paid=true;CAMP.paidGold=G;say('✅ Đã hoàn thành nhiệm vụ thu thập! −'+G.toLocaleString('vi')+' 🪙');bsfx('heal');FLASH={t:0,dur:.5,c:'#ffd45e'};});
}
function campConfirm(html,label,fn){$('cft').innerHTML=html;$('cfyes').textContent=label;cfAct=fn;$('confirm').classList.add('on')}
new MutationObserver(()=>{if(!$('confirm').classList.contains('on'))$('cfyes').textContent='Bán'}).observe($('confirm'),{attributes:true,attributeFilter:['class']});

function objMet(L,fightT){
  const o=L.obj;switch(o.k){case'fast':return fightT!=null&&fightT<=o.p;case'noloss':return CAMP.lost==0;case'lowhit':return CAMP.hits<=o.p;
   case'rich':return S.coins>=Math.round(L.G*o.p/100);case'taps':return CAMP.taps>=o.p;case'army':return swords.length>=o.p}return false}
function campScore(){
  const L=LV[CAMP.lv-1],T=CAMP.t,fightT=(CAMP.fightEnd!=null&&CAMP.bossT0!=null)?CAMP.fightEnd-CAMP.bossT0:null,q=(a,lo,hi)=>Math.max(0,Math.min(1,(a-lo)/(hi-lo)));
  const p={
   time:Math.round(30*q(L.tmax-T,0,L.tmax-L.t3)),                    // thời gian hoàn thành (ngưỡng riêng từng ải)
   surv:Math.round(25*(1-Math.min(1,CAMP.lost/L.lostCap))),            // cá & đơn vị chiến đấu còn sống
   hits:Math.round(20*(1-q(CAMP.hits,L.hitsOK,L.hitsMax))),            // số lần Boss gây sát thương thành công
   eff:Math.round(15*(1-q(fightT==null?L.fightIdeal*2:fightT,L.fightIdeal,L.fightIdeal*2))),   // hiệu quả chiến đấu: tốc độ hạ Boss
   obj:objMet(L,fightT)?10:0};                                          // mục tiêu phụ
  const sc=p.time+p.surv+p.hits+p.eff+p.obj,stars=1+(sc>=L.th2?1:0)+(sc>=L.th3?1:0);
  return{p,sc,stars,fightT};
}
function campWin(){
  if(CAMP.over)return;CAMP.over=true;CAMP.win=true;const L=LV[CAMP.lv-1],r=CP.rec[CAMP.lv-1],sr=campScore(),first=r.s==0;
  const old={s:r.s,t:r.t,k:r.k,h:r.h,g:r.g,sc:r.sc,l:r.l};
  r.c++;CP.tot.clears++;CP.tot.kills+=CAMP.kills;CP.tot.taps+=CAMP.taps;
  r.s=Math.max(r.s,sr.stars);if(!r.t||CAMP.t<r.t)r.t=Math.round(CAMP.t);r.k=Math.max(r.k,CAMP.kills);if(r.h<0||CAMP.hits<r.h)r.h=CAMP.hits;
  r.g=Math.max(r.g,CAMP.gold);r.sc=Math.max(r.sc,sr.sc);if(r.l<0||CAMP.lost<r.l)r.l=CAMP.lost;
  const newStars=Math.max(0,sr.stars-old.s),pearls=(first?20+2*CAMP.lv:0)+12*newStars;CP.pearls+=pearls;
  CP.hist.push({lv:CAMP.lv,s:sr.stars,t:Math.round(CAMP.t),sc:sr.sc,d:Date.now()});if(CP.hist.length>40)CP.hist.shift();
  CAMP.res={sr,old,pearls,first,newStars,rec:Object.assign({},r)};saveCamp();
  bsfx('heal');setTimeout(()=>bsfx('shield'),300);if(typeof showResult=='function')showResult();
}
function campLose(why){if(CAMP.over)return;CAMP.over=true;CAMP.win=false;CAMP.res={why};saveCamp();if(typeof showResult=='function')showResult()}
function campTick(dt){
  if(!CAMP||CAMP.over)return;const L=LV[CAMP.lv-1];CAMP.t+=dt;CAMP.tapCd-=dt;
  if(CAMP.wave<L.wv.length-1){   // đợt kế tiếp: lần đầu sau thời gian chuẩn bị · các đợt sau khi đợt trước đã bị hạ
    if(CAMP.wave<0||!bossAlive())CAMP.gapT-=dt;
    if(CAMP.gapT<=0&&(CAMP.wave<0||!bossAlive()))spawnWave();
  }else if(CAMP.wave>=L.wv.length-1&&!CAMP.bossDone&&CAMP.wave>=0&&!bossAlive()){CAMP.bossDone=true;CAMP.fightEnd=CAMP.t;say('💀 Đã hạ toàn bộ Boss!'+(CAMP.paid?'':' Hãy trả nhiệm vụ vàng để hoàn thành ải.'))}
  if(CAMP.bossDone&&CAMP.paid){campWin();return}
  if(!fish.length&&S.coins<100)campLose('Hồ cá đã trống và không đủ vàng mua cá mới');
}
