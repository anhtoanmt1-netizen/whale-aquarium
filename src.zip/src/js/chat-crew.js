// ================= TRÒ CHUYỆN CỦA CÁ CHIẾN BINH · CÁ SUPPORT · CUA (vai trò: war / sup / crab) =================
const CREW_SOLO={
 war:['Kiếm sắc, tâm tĩnh, bụng… đói','Luyện kiếm xong, flex xíu nè 💪','Quái đâu ra đây nào!','Hôm nay chưa chém ai, hơi buồn','Tui là chiến binh bơi đẹp nhất hồ','Mài kiếm xíu cho bén','Hồ này tui bảo kê!','Ai bắt nạt cá, tui đâm liền','Đỉnh của chóp là tui','Tập tạ vây nè, 1-2-3!','Kiếm tui bén lắm, đừng sờ','Chill thôi, lát có quái là xử','Tui không phải dạng vừa đâu','Ai cần bảo vệ giơ vây lên!','Đứng gác mệt ghê, đổi ca không?','Gét gô, sẵn sàng chiến đấu!','Nay trời đẹp để chém quái','Đừng lo, có tui ở đây','Bơi vòng vòng tuần tra nè'],
 sup:['Phun cơm đây, ai đói giơ vây!','Tui là shipper thức ăn của hồ','Ăn đi cho mau lớn nha','Cá đói là tui lo hết','Hồi máu 24/7, không nghỉ lễ','Tui thương cả hồ lắm','Nước ấm, lòng cũng ấm','Ai cần ôm tui hồi máu cho','Đứng sau lưng nhưng quan trọng nhất nha','Nhớ ăn đủ bữa nha cả nhà','Bơi nhẹ nhàng, sống chill','Cơm có tui, quái để chiến binh','Mỗi ngày một viên, vui vẻ yêu đời','Cho tui xin xíu năng lượng','Thấy ai đói là tui ngứa nghề'],
 crab:['Cua đây, kẹp phát là xong','Xu xu xu, xu đâu hết rồi?','Đi ngang cho nó ngầu','Tui đi ngang mà vẫn tới đích!','Càng bự, tiền lớn!','Tui là thợ săn xu số một','Nhặt xu là đam mê của tui','Kẹp kẹp, ai cần kẹp không?','Đáy hồ là sân nhà tui','Tui đỏ vì nắng… hay vì mắc cỡ?','Xu rơi là tui có mặt','Ai làm rơi xu thì báo tui','Chân nhiều mà vẫn đi ngang, kỳ ghê','Tui không cắn đâu, kẹp thôi']};
const WAR_FIGHT=['Quái kìa, xông lên!','Nhận một đâm nè!','Gét gô, chiến thôi!','Đừng hòng đụng cá của tui!','Đâm phát nào ra phát đó!','Ê quái, đấu 1-1 không?','Cháy hết mình luôn!','Không phải dạng vừa đâu nha!'],
 WAR_HURT=['Máu thấp rồi, Support ơi!','Đau quá… vẫn chiến!','Cho xin cái hồi máu!','Hơi đuối nha, cứu cứu','Xỉu up xỉu down rồi…'],
 WAR_CHEER=['Xong phim! Gét gô!','Quá là đỉnh luôn!','Hết nước chấm!','GG, dễ ẹc!','Ai khen tui đi nè 😎'],
 SUP_HEAL=['Đứng yên, hồi máu đây!','Để tui, bơi lại gần nè','Hồi máu tới liền, chờ xíu','Ai bị thương thì lại đây','Truyền máu cấp tốc nè','Chiến binh ơi giữ nhịp, tui lo!'],
 SUP_FOOD=['Có cá đói kìa, phun cơm!','Cơm nóng tới đây!','Ai đói để tui lo','Dùng bữa nào cả nhà ơi','Phun cơm, phun cơm!'],
 CRAB_COIN=['Xu kìa! Chạy thôi!','Có xu dưới đáy, của tui nha','Mùi tiền thơm quá','Nhặt, nhặt, nhặt!','Ting ting, tiền về!'],
 CRAB_DASH=['Vút! Cua phi nước đại!','Lướt tới đây, tránh ra!','Drift kiểu cua nè 😎','Tốc độ ánh sáng… của cua!','Wuss wuss!'],
 CRAB_LOVE=['Bắn tim, bắn tim 💗','Cá nào buồn, tui bắn tim!','Gửi thương, gửi nhớ 💕','Tim tới, vui lên nha','Tích tim xong rồi nè'],
 CRAB_HURT=['Càng tui đau quá!','Ui da, ai chọc cua vậy','Cho tui trốn ké cái','Cua sắp hết mai rồi…'],
 ALERT={war:WAR_FIGHT,sup:['Quái tới rồi, cẩn thận nha!','Chiến binh lo nha, tui hồi máu!','Cá ơi tụ lại đây!'],crab:['Quái kìa, cua núp xíu…','Cua sợ nhưng vẫn ngầu','Giữ xu giữ xu!']};
// đối thoại theo cặp vai trò "người nói>người nghe": [lời nói, [các câu đáp]]
const DLG={
 'war>sup':[['Support ơi, hồi máu cho tui!',['Đứng yên nha, tới liền!','Tăng ca nè, bơi lại đây']],['Máu tui còn bao nhiêu vậy?',['Còn đủ để ngầu thêm 5 phút','Đừng lo, có hậu phương này']],['Nhờ cậu mà tui chiến hăng thế',['Hậu phương vững, tiền tuyến mới vững!','Khỏi cảm ơn, mời trà sữa thôi']],['{n} ơi, đứng sau tui nha',['Ok, tui hồi máu từ xa!','Tin cậu 100%']]],
 'sup>war':[['Chiến binh ơi, bớt liều đi!',['Liều mới ngầu chứ!','Biết rồi, có cậu lo mà']],['Nè, uống hồi máu đi',['Ngon quá, cảm ơn nha!','Máu lên lại rồi, gét gô!']],['Cậu đâm đẹp lắm đó',['Thật hả? Ngại quá đi','Nhờ hậu phương cả đó']],['Đừng để quái đụng tui nha',['Yên tâm, có tui chắn!','Ok, cậu lo hậu phương nhé']]],
 'war>fish':[['Cá nhỏ đừng lo, có tui đây',['Chiến binh ngầu quá!','Tụi tui tin cậu!']],['Ê, tránh xa quái ra nha',['Dạ vâng, sợ lắm luôn!','Nhờ chiến binh bảo vệ nha!']],['Tụ lại phía sau tui đi',['Ok, núp sau lưng nha!','Có chiến binh là yên tâm']],['Cá nào đẻ xu, tui bảo kê!',['Chia tui xíu xu nha 😆','Cảm ơn, tụi tui đẻ tiếp!']]],
 'fish>war':[['Chiến binh ơi, cứu tụi tui!',['Yên tâm, có tui đây!','Chờ xíu, tui xử liền!']],['Chiến binh ngầu quá!',['Biết rồi, khen nhiều ngại','Cảm ơn, flex xíu nha 😎']],['Cho tui chạm kiếm cái được không?',['Đừng, bén lắm đó!','Chạm nhẹ thôi nha']],['Quái sợ quá, tui núp sau cậu nha',['Cứ núp, tui lo!','Ok, ai cũng an toàn']]],
 'sup>fish':[['Cá đói chưa? Tui phun cơm nè',['Đói muốn xỉu luôn!','Cảm ơn Support nha!']],['Ăn nhiều vào cho mau lớn',['Lớn rồi đẻ xu cho nè','Dạ, no căng bụng luôn']],['Có ai bị thương không?',['Không sao, cảm ơn quan tâm','Tui hơi sợ thôi à']],['Ăn từ từ thôi, đừng giành',['Hổng chịu đâu, đói mà!','Dạ, tui chia bạn nè']]],
 'fish>sup':[['Support ơi, tui đói quá!',['Đây đây, cơm nóng tới nè','Chờ xíu, phun liền!']],['Cảm ơn Support nha',['Có gì đâu, nghề của tui mà','Nhớ ăn đủ bữa nha']],['Cho tui thêm viên nữa đi',['Ham ăn quá, nhưng thôi cho nè','Mỗi người một viên thôi']]],
 'crab>fish':[['Cá ơi, đẻ xu đi nha',['Từ từ, tui đang cố nè','Đẻ xu đâu phải dễ!']],['Nhớ thả xu gần tui nha',['Ok, thả ngay trước mặt cua','Cua nhặt nhanh chút nha']],['Cá nào buồn, tui bắn tim cho',['Cảm ơn cua, vui hơn rồi','Tim cua ấm ghê']],['Xu của cậu thơm lắm',['Thơm gì, xu thì xu thôi','Cua mê tiền quá nha']]],
 'fish>crab':[['Cua ơi, nhặt xu giùm nè',['Đợi tui, lướt tới liền!','Có xu là có cua']],['Cua đi ngang buồn cười ghê',['Cá bơi lòng vòng cũng vậy','Đi ngang mà vẫn tới đích']],['Cua ơi, bắn tim cho tui đi',['Tim tới liền, đón nè 💗','Chờ xíu, tim đang tích nè']]],
 'crab>war':[['Chiến binh cho mượn kiếm với',['Mượn gì, cậu có càng rồi!','Kiếm tui bén lắm, cẩn thận']],['Tui lo xu, cậu lo quái nha',['Phân công hợp lý!','Chốt đơn luôn']],['Cậu ngầu, tui cũng ngầu: có càng!',['Hai cái ngầu gặp nhau rồi','Cua ngầu thật']]],
 'war>crab':[['Cua ơi, giữ đáy hồ giúp tui',['Đáy hồ cứ để cua lo!','Ok sếp, tui giữ xu']],['Càng cậu bự hơn kiếm tui rồi',['Càng là vũ khí quốc dân!','Bự mà không ngầu bằng cậu']],['Có xu thì nhớ chia tui nhé',['Chia sao được, của cua hết','Thôi để tui mua trà sữa cho']]],
 'crab>sup':[['Support ơi, hồi máu cua với',['Đợi xíu, tui hồi liền!','Cua yếu hả? Lại đây']],['Cho cua xin ít cơm',['Cua ăn cơm hả? Ok nè','Của cua nè, nóng hổi']]],
 'sup>crab':[['Cua ơi, nhặt xu dùm cả hồ nha',['Giao cho cua, không lo!','Xu nào thoát khỏi càng tui']],['Cậu bắn tim dễ thương ghê',['Tim là đặc sản của cua','Cảm ơn, tim còn nóng nè']]],
 'war>war':[['Điểm danh đi anh em!',['Có mặt!','Chiến binh nào cũng ngầu!']],['Hôm nay mình đâm ai trước?',['Con quái nào to nhất ấy','Chờ lệnh, tui sẵn sàng']],['{n} ơi, đấu tay đôi không?',['Thôi, để dành đâm quái','Chiến thì chiến, cho cá xem!']]],
 'sup>sup':[['Hội Support họp mặt nè',['Họp ăn trưa hả?','Cùng hồi máu nha']],['{n} phun nhiều hơn tui rồi',['Thi đua nè, 1-2-3','Hai đứa cùng phun là hồ no']]],
 'crab>crab':[['Hội cua họp nào!',['Đi ngang cùng nhau nha','Điểm danh: càng giơ lên!']],['Xu này của tui nha',['Giành gì, hồ nhiều xu mà','Tui nhanh hơn, lướt cái là xong']],['{n} ơi, nhặt được mấy xu rồi?',['Nhiều lắm, giàu rồi!','Đếm không xuể luôn']]]};
const fmtN=(s,o)=>s.replace('{n}',(o&&o.name)||'bạn');
function crewSay(o,txt,l=3){o.say={t:txt,l}}
function crewAlert(){   // quái xuất hiện: vài chiến binh / support / cua hô lên
  if(!S.chat)return;const pool=[...swords,...horses,...crabs].filter(o=>!o.say&&!o.rep).sort(()=>Math.random()-.5).slice(0,3);
  for(const o of pool)crewSay(o,pk(ALERT[o.role]),2.6)}
function crewCheer(){if(!S.chat)return;const w=swords.filter(o=>!o.say);if(w.length)crewSay(pk(w),pk(WAR_CHEER),3);const s=horses.filter(o=>!o.say);if(s.length&&Math.random()<.5)crewSay(pk(s),'Giỏi quá, hồi máu cả đội nè 💚',3)}
function crewSit(o){
  if(o.role=='war')return THREAT?(o.hp/o.max<.4?WAR_HURT:WAR_FIGHT):null;
  if(o.role=='sup'){if(swords.some(w=>w.hp<w.max*.6))return SUP_HEAL;if(fish.some(f=>f.hunger>60))return SUP_FOOD;return null}
  if(o.hp<o.max*.5)return CRAB_HURT;if(o.dashing)return CRAB_DASH;if(coins.some(k=>k.rest))return CRAB_COIN;if(o.lv>=3&&fish.some(f=>f.joy<80))return CRAB_LOVE;return null}
let crewT=3;
function chatCrew(dt){
  const crew=[...swords,...horses,...crabs];
  for(const o of crew){if(o.say){o.say.l-=dt;if(o.say.l<=0)o.say=null}if(o.rep){o.rep.d-=dt;if(o.rep.d<=0){o.say={t:o.rep.t,l:3};o.rep=null}}}
  crewT-=dt;if(crewT>0||!S.chat||!crew.length)return;
  crewT=R(2.2,4.5)*(crew.length>15?.6:1);
  if(crew.filter(o=>o.say).length>=Math.min(5,1+Math.ceil(crew.length/5)))return;
  const free=crew.filter(o=>!o.say&&!o.rep);
  // cá trong hồ hỏi chuyện đội ngũ (nhờ cứu, xin cơm, nhờ nhặt xu…)
  if(Math.random()<.22){const f=pk(fish.filter(x=>!x.say&&!x.rep));
    if(f){const nr=crew.filter(o=>!o.say&&!o.rep&&Math.hypot(o.x-f.x,o.y-f.y)<340);
      if(nr.length){const o=pk(nr),L=DLG['fish>'+o.role],p=pk(L);f.say={t:fmtN(p[0],o),l:3.2};o.rep={t:fmtN(pk(p[1]),f),d:1.8};return}}}
  if(!free.length)return;
  const o=pk(free),r=o.role,sit=crewSit(o);
  if(sit&&Math.random()<.55){crewSay(o,pk(sit));return}
  const near=[...crew,...fish].filter(q=>q!==o&&!q.say&&!q.rep&&Math.hypot(q.x-o.x,q.y-o.y)<340);
  if(near.length&&Math.random()<.55){const q=pk(near),L=DLG[r+'>'+(q.role||'fish')];
    if(L){const p=pk(L);crewSay(o,fmtN(p[0],q),3.2);q.rep={t:fmtN(pk(p[1]),o),d:1.8};return}}
  crewSay(o,pk(CREW_SOLO[r]))}
