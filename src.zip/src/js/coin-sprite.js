// ===== Đồng xu vàng / bạc: hình + hiệu ứng từ bảng xu.png (7 khung xoay mỗi loại) =====
const CN={state:'loading',img:null,cw:64,ch:64};
(function(){const i=new Image();i.onload=()=>{CN.img=i;CN.state='ready'};i.onerror=()=>{CN.state='failed'};i.src='coin-sheet.png'})();
const CN_SPIN=[0,1,2,3,4,5,6,5,4,3,2,1],CN_GLINT=[2,3,4,3];   // xoay hết một vòng; lấp lánh khi nằm yên
function cnFrame(k){
  if(k.rest)return CN_GLINT[Math.floor(t*2.2+k.ph)%4];
  const sp=Math.max(0,Math.min(1,(k.vy||0)/52)),n=Math.floor(t*(7+4*sp)+k.ph*2);   // rơi càng nhanh xoay càng nhanh
  return CN_SPIN[((n%12)+12)%12];
}
