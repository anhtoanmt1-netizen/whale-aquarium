// ---- Cua: danh sách, nâng cấp, bán
const cslotCost=()=>300+150*((S.ccap-5)/5);
function cUp(o){if(o.lv>=5)return;const cost=cUpCost(o.lv);if(S.coins<cost){say('Không đủ xu để nâng cấp 🪙');return}
  S.coins-=cost;o.spent+=cost;o.lv++;say(o.name+' lên Lv '+o.lv+'! ⭐');fx.push({x:o.x,y:o.y-30,l:.8,m:.8,e:'⭐'});sfx('hit')}
function openC(){$('clist').classList.add('on');renderC()}
function renderC(){
  let h='';
  for(const o of crabs)h+=`<div class="fc cc" data-id="${o.id}"><canvas class="fth" width="96" height="72" data-id="${o.id}"></canvas><div class="fi"><div class="fr"><input class="nm" maxlength="14" value="${esc(o.name)}" aria-label="Tên cua"><span class="stars"></span></div><div class="fa">🎂 Tuổi: <b class="ag"></b></div><div class="bar"><label>❤️ Máu</label><span class="bg"><i class="b1"></i></span><em class="v1"></em></div></div><div class="sk"><span class="skn"></span><br><span class="skx"></span></div><div class="wb"><button class="upb" data-cup="${o.id}"></button><button class="sell" data-csell="${o.id}"></button></div></div>`;
  $('ccards').innerHTML=h||'<p class="ds" style="text-align:center;padding:14px">Chưa có chú cua nào. Hãy mua ở 🛒 Cửa hàng!</p>';updC(true);
}
function updC(skip){
  if(!$('clist').classList.contains('on'))return;
  const cards=[...$('ccards').querySelectorAll('.cc')];
  if(!skip&&(cards.length!==crabs.length||cards.some(x=>!crabs.find(o=>o.id==x.dataset.id)))){const a=document.activeElement;if(!(a&&a.classList&&a.classList.contains('nm')))renderC();return}
  $('clc').textContent='🦀 '+crabs.length+'/'+S.ccap;$('cslotp').textContent=S.ccap>=MAXF?'Tối đa':'🪙 '+cslotCost();$('cslotb').disabled=S.ccap>=MAXF||S.coins<cslotCost();
  for(const x of cards){const o=crabs.find(z=>z.id==x.dataset.id),q=k=>x.querySelector(k);if(!o)continue;
    const pct=Math.max(0,Math.min(100,o.hp/o.max*100));
    q('.stars').textContent='★'.repeat(o.lv)+'☆'.repeat(5-o.lv);q('.ag').textContent=ageTxt(o.born);
    q('.b1').style.width=pct+'%';q('.b1').style.background=pct<35?'#ef7a6a':'#5fc79a';q('.v1').textContent=Math.ceil(o.hp)+'/'+o.max;
    q('.skn').textContent='Kỹ năng: '+CKT[o.lv];q('.skx').textContent=o.lv<5?'Lv'+(o.lv+1)+': '+CKT[o.lv+1]:'(Level tối đa)';
    const u=q('.upb');if(o.lv>=5){u.innerHTML='⭐ Level<br>tối đa';u.disabled=true}else{const cst=cUpCost(o.lv);u.innerHTML='⬆️ Nâng cấp<br>🪙 '+cst;u.disabled=S.coins<cst}
    q('.sell').innerHTML='💰 Bán<br>🪙 '+Math.round(o.spent*.8);
  }
}
setInterval(updC,500);
function drawCThumbs(){
  if(!$('clist').classList.contains('on'))return;const im=img('crab');if(!im||!im.naturalWidth)return;
  for(const cvs of document.querySelectorAll('#ccards .fth')){
    const o=crabs.find(z=>z.id==cvs.dataset.id);if(!o)continue;const x=cvs.getContext('2d'),cw=cvs.width,ch=cvs.height;x.clearRect(0,0,cw,ch);
    const ww=58,hh=ww*im.naturalHeight/im.naturalWidth,sx=Math.sin(t*.9+o.ph),moving=Math.cos(t*.9+o.ph)>.3;
    x.save();x.translate(cw/2+sx*12,ch/2+hh/2-6-(moving?Math.abs(Math.sin(t*10))*2:0));x.scale(Math.cos(t*.9+o.ph)>=0?1:-1,1);x.drawImage(im,-ww/2,-hh,ww,hh);x.restore();
    if(o.lv>=3){const k=(t*(o.lv>=5?1.6:.8)+o.ph)%1,r=2.5+k*6;x.save();x.translate(cw/2+sx*12+(Math.cos(t*.9+o.ph)>=0?-1:1)*19,ch/2-hh/2+8);x.scale(r/10,r/10);x.fillStyle='#ff6b9a';x.strokeStyle='#fff';x.lineWidth=2;x.beginPath();x.moveTo(0,8);x.bezierCurveTo(-14,-2,-8,-12,0,-5);x.bezierCurveTo(8,-12,14,-2,0,8);x.closePath();x.fill();x.stroke();x.restore()}
  }
}
setInterval(drawCThumbs,100);
$('ccards').addEventListener('click',e=>{
  const u=e.target.closest('[data-cup]');if(u){const o=crabs.find(z=>z.id==u.dataset.cup);if(o)cUp(o);updC(true);return}
  const b=e.target.closest('[data-csell]');if(!b)return;const o=crabs.find(z=>z.id==b.dataset.csell);if(!o)return;
  const v=Math.round(o.spent*.8),id=o.id;
  cfAct=()=>{const i=crabs.findIndex(z=>z.id==id);if(i>=0){S.coins+=v;say('Đã bán '+crabs[i].name+' 👋 +'+v+' 🪙');crabs.splice(i,1);save()}renderC()};
  $('cft').innerHTML=`Bán <b>${esc(o.name)}</b> (Lv ${o.lv}) và nhận lại <b>🪙 ${v}</b> (80% tổng giá trị)?<br><small style="color:#6f8aa3">Bạn sẽ không lấy lại được chú cua này.</small>`;$('confirm').classList.add('on')});
$('ccards').addEventListener('change',e=>{const i=e.target.closest('.nm');if(!i)return;const o=crabs.find(z=>z.id==i.closest('.cc').dataset.id);if(!o)return;const v=i.value.trim().slice(0,14);if(v)o.name=v;else i.value=o.name;save()});
$('ccards').addEventListener('keydown',e=>{if(e.key=='Enter'&&e.target.classList.contains('nm'))e.target.blur()});
$('cslotb').onclick=()=>$('cslot').onclick();
$('cntc').onclick=openC;$('c_crab').onclick=e=>{e.stopPropagation();openC()};
$('clclose').onclick=()=>$('clist').classList.remove('on');
$('clist').addEventListener('pointerdown',e=>{if(e.target==$('clist'))$('clist').classList.remove('on')});
