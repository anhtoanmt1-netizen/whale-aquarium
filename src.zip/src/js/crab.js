// ================= CUA: kỹ năng, tim bắn, âm thanh, hình vẽ =================
// Lv1 nhặt xu · Lv2 + lướt nhanh tới xu đã chạm đáy · Lv3-5 + bắn tim tăng Vui cho cá dưới 80% (hồi chiêu 5s / 1s / 0,5s; Lv5 bắn bằng cả 2 càng)
const CCD=[0,0,0,5,1,.5],CHEART=7,CKT=[null,
  '🦀 Nhặt xu ở đáy hồ',
  '🦀 Nhặt xu · 💨 Lướt nhanh tới xu đã chạm đáy',
  '🦀💨 Lv1-2 · 💗 Bắn tim cho cá Vui dưới 80% (hồi chiêu 5 giây)',
  '🦀💨 Lv1-2 · 💗 Bắn tim cho cá Vui dưới 80% (hồi chiêu 1 giây)',
  '🦀💨 Lv1-2 · 💗💗 Bắn tim bằng cả 2 càng (hồi chiêu 0,5 giây)'];
let cHeart=[];   // các trái tim đang bay

// ---- âm thanh nhỏ nhẹ (dùng chung bộ WebAudio; tắt khi chọn Tắt âm thanh)
const sfxT={};
function sfx(k){
  if(!AC||S.snd=='off')return;const n=performance.now();if(n-(sfxT[k]||0)<(k=='hit'?70:130))return;sfxT[k]=n;
  const t0=AC.currentTime,g=AC.createGain();g.connect(MG);
  if(k=='dash'){   // vút: tiếng gió ngắn
    const b=AC.createBuffer(1,Math.floor(AC.sampleRate*.2),AC.sampleRate),d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=(Math.random()*2-1)*(1-i/d.length);
    const s=AC.createBufferSource(),f=AC.createBiquadFilter();s.buffer=b;f.type='bandpass';f.Q.value=2;f.frequency.setValueAtTime(1800,t0);f.frequency.exponentialRampToValueAtTime(450,t0+.18);
    g.gain.setValueAtTime(.05,t0);g.gain.exponentialRampToValueAtTime(.001,t0+.2);s.connect(f);f.connect(g);s.start(t0);return}
  const o=AC.createOscillator();o.connect(g);
  if(k=='shoot'){o.type='sine';o.frequency.setValueAtTime(620,t0);o.frequency.exponentialRampToValueAtTime(1050,t0+.1);g.gain.setValueAtTime(.045,t0);g.gain.exponentialRampToValueAtTime(.001,t0+.14);o.start(t0);o.stop(t0+.15)}
  else{o.type='triangle';o.frequency.setValueAtTime(1175,t0);o.frequency.setValueAtTime(1568,t0+.06);g.gain.setValueAtTime(.04,t0);g.gain.exponentialRampToValueAtTime(.001,t0+.22);o.start(t0);o.stop(t0+.24)}   // hit / lên cấp
}

// ---- hình học của cua trên màn hình (vị trí hai càng: càng lớn bên trái ảnh, càng nhỏ bên phải)
function crabGeo(){
  const im=img('crab');if(!im||!im.naturalWidth)return null;const r=im.naturalHeight/im.naturalWidth,K=SZK.crab;let w=83*K,h=w*r;if(h>94*K){h=94*K;w=h/r}
  return{im,w,h,big:{x:-.33*w,y:-.9*h},small:{x:.33*w,y:-.83*h}};
}
function needyFish(){let b=null,bj=1e9;for(const f of fish){const j=f.joy+(f._inc||0)*CHEART;if(j<80&&j<bj){bj=j;b=f}}return b}
function fireHearts(cr){
  const g=crabGeo();if(!g)return;const shots=cr.lv>=5?2:1;
  for(let s=0;s<shots;s++){const f=needyFish();if(!f)break;const cl0=s?g.small:g.big,x=cr.x+cr.dir*cl0.x,y=H-8+cl0.y;
    cHeart.push({x,y,f,r:s?8:11,t:0,tr:0,ph:R(0,6)});f._inc=(f._inc||0)+1;fx.push({x,y,l:.35,m:.25,e:'✨'});sfx('shoot')}
  if(S.chat&&!cr.say&&Math.random()<.25)crewSay(cr,pk(CRAB_LOVE));
}

function updCrabs(dt){
  const gy=H-45;
  for(const cr of crabs){cr.y=gy;cr.hurt-=dt;if(!THREAT)cr.hp=Math.min(cr.max,cr.hp+dt*.8)}
  crabs=crabs.filter(c=>!c.dead);
  if(crabs.length){
    // mỗi con nhắm một đồng xu RIÊNG và tản ra, không đứng chồng lên nhau
    const prs=[];for(let i=0;i<crabs.length;i++)for(const k of coins){if(!k.dead)prs.push([Math.abs(k.x-crabs[i].x)+(k.y<H-100?200:0),i,k])}
    prs.sort((p,q)=>p[0]-q[0]);const usedC=new Set(),usedK=new Set(),asg=[];
    for(const pr of prs){if(usedC.has(pr[1])||usedK.has(pr[2]))continue;usedC.add(pr[1]);usedK.add(pr[2]);asg[pr[1]]=pr[2]}
    crabs.forEach((cr,i)=>{
      if(cr.stun>0){cr.stun-=dt;cr.vx=0;return}
      const tg=asg[i]||null;
      if(tg)cr.tx=tg.x;
      else if(cr._tg||Math.abs(cr.tx-cr.x)<10||Math.random()<dt*.15){
        let best=R(40,W-40),bd=-1;for(let q=0;q<5;q++){const c0=R(40,W-40);let md=1e9;for(const o of crabs)if(o!==cr)md=Math.min(md,Math.abs(o.x-c0));if(md>bd){bd=md;best=c0}}cr.tx=best}
      cr._tg=!!tg;cr.tx=cl(cr.tx,30,W-30);
      const dx=cr.tx-cr.x;
      // Lv2+: lướt ngang nhanh tới xu đã nằm dưới đáy
      if(cr.lv>=2&&tg&&tg.rest&&Math.abs(dx)>70){if(!cr.dashing){cr.dashing=true;sfx('dash');if(S.chat&&!cr.say&&Math.random()<.3)crewSay(cr,pk(CRAB_DASH))}}
      else if(!(cr.lv>=2&&tg&&tg.rest&&Math.abs(dx)>=18))cr.dashing=false;
      cr.fxT-=dt;if(cr.dashing&&cr.fxT<=0){cr.fxT=.07;fx.push({x:cr.x-cr.dir*26,y:H-20,l:.4,m:.3,e:'💨'})}
      const spd=cr.dashing?470:(tg?130:45);
      cr.vx+=((Math.abs(dx)>6?Math.sign(dx)*spd:0)-cr.vx)*dt*(cr.dashing?9:4);cr.x=cl(cr.x+cr.vx*dt,30,W-30);if(Math.abs(cr.vx)>8)cr.dir=cr.vx>0?1:-1;
      crabs.forEach((o,j)=>{if(o===cr)return;const dd=cr.x-o.x,ad=Math.abs(dd),mn=72*Math.max(.8,SZK.crab);
        if(ad<mn)cr.x=cl(cr.x+(dd>0?1:dd<0?-1:(i<j?-1:1))*Math.min((mn-ad)*Math.min(1,dt*10)*.5,90*dt),30,W-30)});
      for(const k of coins)if(!k.dead&&Math.abs(k.x-cr.x)<36&&k.y>H-90){earn(k.v);k.dead=true;fx.push({x:k.x,y:k.y-8,l:.5,m:.5,e:'✨'});if(tingT<=0){ting();tingT=.25}}
      // Lv3+: tích tụ trái tim ở càng rồi bắn vào cá có Vui dưới 80%
      if(cr.lv>=3){
        if(needyFish()){cr.charge=Math.min(1,cr.charge+dt/CCD[cr.lv]);if(cr.charge>=1){fireHearts(cr);cr.charge=0}}
        else cr.charge=Math.max(0,cr.charge-dt*.8);
      }
    });
  }
  // tim đang bay: bám theo cá, càng gần càng nhanh
  for(let i=cHeart.length-1;i>=0;i--){
    const p=cHeart[i],f=p.f;if(!fish.includes(f)){cHeart.splice(i,1);continue}
    p.t+=dt;const dx=f.x-p.x,dy=f.y-p.y,d=Math.hypot(dx,dy)||1,st=Math.min(d,(260+p.t*320)*dt);p.x+=dx/d*st;p.y+=dy/d*st;
    p.tr-=dt;if(p.tr<=0){p.tr=.07;fx.push({x:p.x,y:p.y,l:.35,m:.25,e:'✨'})}
    if(d<sz(f)*.8+6||p.t>4){f.joy=Math.min(100,f.joy+CHEART);f._inc=Math.max(0,(f._inc||1)-1);f.freeze=.3;
      for(let q=0;q<3;q++)hearts(f.x,f.y-sz(f)*.8);fx.push({x:f.x,y:f.y-sz(f)*.5,l:.6,m:.6,e:'💞'});sfx('hit');
      if(S.chat&&!f.say&&Math.random()<.4)f.say={t:pk(PETS),l:2};cHeart.splice(i,1)}
  }
}

// ---- vẽ
function drawHeartShape(x,y,r,a){
  c.save();c.globalAlpha=a;c.translate(x,y);c.scale(r/10,r/10);c.lineJoin='round';
  c.fillStyle='#ff6b9a';c.strokeStyle='#fff';c.lineWidth=1.8;c.beginPath();c.moveTo(0,8);c.bezierCurveTo(-14,-2,-8,-12,0,-5);c.bezierCurveTo(8,-12,14,-2,0,8);c.closePath();c.fill();c.stroke();
  c.fillStyle='#ffffffb0';c.beginPath();c.ellipse(-4.2,-5,2.4,1.5,-.6,0,7);c.fill();c.restore();
}
function drawCHearts(){for(const p of cHeart)drawHeartShape(p.x,p.y,p.r*(1+.1*Math.sin(t*16+p.ph)),1)}
function drawCrab(cr){
  const g=crabGeo();if(!g)return;const{im,w,h}=g,K=SZK.crab,moving=Math.abs(cr.vx)>10;
  const bob=Math.abs(Math.sin(t*(cr.dashing?22:10)+cr.ph))*(moving?(cr.dashing?2:4):0);cr._top=H-8-h;
  if(cr.dashing){for(let i=3;i>=1;i--){c.save();c.globalAlpha=.13*(4-i);c.translate(cr.x-cr.dir*i*17,H-8);c.scale(cr.dir,1);c.drawImage(im,-w/2,-h,w,h);c.restore()}}
  c.save();c.translate(cr.x+(cr.hurt>0?R(-3,3):0),H-8-bob);c.scale(cr.dir*(cr.dashing?1.08:1),cr.dashing?.94:1);if(cr.hurt>0)c.globalAlpha=.7;c.drawImage(im,-w/2,-h,w,h);c.restore();
  if(cr.lv>=3&&cr.charge>0){   // trái tim nhỏ lớn dần ở càng; Lv5: cả càng lớn và càng nhỏ
    const p=cr.charge,e=1-Math.pow(1-p,2),pu=1+.08*Math.sin(t*14+cr.ph),y0=H-8-bob;
    drawHeartShape(cr.x+cr.dir*g.big.x,y0+g.big.y-4*e,(3+9*e)*pu,.55+.45*p);
    if(cr.lv>=5)drawHeartShape(cr.x+cr.dir*g.small.x,y0+g.small.y-3*e,(2.5+6.5*e)*pu,.55+.45*p);
    if(p>.85){c.globalAlpha=.5;c.fillStyle='#fff';c.beginPath();c.arc(cr.x+cr.dir*g.big.x,y0+g.big.y-4*e,(3+9*e)*1.5,0,7);c.fill();c.globalAlpha=1}
  }
  const bw=44,by=H-8-h-12,shp=S.showHp!==false;
  if(shp){c.fillStyle='#0006';c.fillRect(cr.x-bw/2,by,bw,5);c.fillStyle=cr.hp/cr.max<.35?'#ef5350':'#5fc79a';c.fillRect(cr.x-bw/2,by,bw*Math.max(0,cr.hp/cr.max),5)}
  if(S.showStars!==false){c.font='800 10px Montserrat,sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillStyle='#f5b400';c.fillText('★'.repeat(cr.lv),cr.x,shp?by-7:by+3)}
}
