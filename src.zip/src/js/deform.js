// ================= BIẾN DẠNG ẢNH (Image Deformation) cho Cá Chiến Binh & Cá Support =================
// Ảnh gốc được phủ một lưới nhỏ; mỗi đỉnh lưới bị DỊCH CHUYỂN theo "trường biến dạng" riêng của từng loài
// (thân uốn sóng, vây vỗ / đung đưa đúng vị trí gắn) → ảnh được kéo giãn mềm mại, KHÔNG cắt rời thành nhiều mảnh.
// Các khung biến dạng được dựng sẵn một lần (cache) nên khi chơi mỗi con chỉ tốn 1 lệnh vẽ → nhẹ cho điện thoại.
const dfSm=(a,b,x)=>{x=Math.max(0,Math.min(1,(x-a)/(b-a)));return x*x*(3-2*x)};
const dfGs=(x,y,cx,cy,rx,ry)=>Math.exp(-(((x-cx)/rx)*((x-cx)/rx)+((y-cy)/ry)*((y-cy)/ry)));
// Mọi hàm thời gian phải là bội nguyên của pha p (p, 2p, 3p) để vòng lặp khớp khít.
const DFM={
  sword:{key:'sword',dw:'w',base:120,W:384,H:229,pad:26,cell:10,fr:{},s:0,im:null,mask:null,
    // Cá kiếm (nhìn sang TRÁI: mũi bên trái, đuôi bên phải). Tọa độ theo ảnh 384×229.
    field(x,y,p,A){
      const u=Math.max(0,Math.min(1,(x-135)/249));
      let dx=0,dy=19*A*Math.pow(u,1.6)*Math.sin(p-2.2*u);                        // thân: đầu cố định, đuôi lắc mạnh dần
      const wD=dfSm(150,185,x)*(1-dfSm(318,345,x))*(1-dfSm(12,112,y));           // vây lưng dạng buồm: ngọn trôi ra sau, phập phồng trễ pha
      dx+=A*9*wD*Math.sin(p-1.1-2.2*(1-y/112))+wD*2.5;dy+=wD*2.5*Math.sin(p-1.7);
      const wP=dfGs(x,y,232,162,36,22),fl=Math.sin(2*p+.6)*(.5+.5*A);           // vây ngực: gốc ở thân (x≈203), càng xa gốc càng vỗ mạnh
      dy+=wP*fl*Math.max(0,x-203)*.30;dx-=wP*Math.abs(fl)*2.2;
      const w1=dfGs(x,y,168,214,18,16),w2=dfGs(x,y,284,206,18,16);                // hai vây bụng: đung đưa nhẹ
      dx+=A*4*(w1*Math.sin(p+1)+w2*Math.sin(p+2.2));dy+=2.5*(w1*Math.sin(2*p)+w2*Math.sin(2*p+1));
      const wT=dfSm(332,376,x);dy+=A*5*wT*Math.sin(p-2.9-(y-190)*.025);          // đuôi chẻ: hai thùy vẫy lệch pha
      return[dx,dy]}},
  horse:{key:'horse',dw:'h',base:96,W:200,H:320,pad:22,cell:10,fr:{},s:0,im:null,mask:null,
    // Hải mã (nhìn sang TRÁI, dựng đứng). Tọa độ theo ảnh 200×320.
    field(x,y,p,A){
      const v=Math.max(0,Math.min(1,(y-120)/200));
      let dx=14*A*Math.pow(v,1.25)*Math.sin(p-1.9*v),dy=0;                      // thân dập dờn, đuôi vung xa nhất
      const wH=dfGs(x,y,70,92,58,52);dx-=1.6*Math.sin(p-.9)*wH;dy+=1.8*A*Math.sin(2*p)*wH;   // đầu gật nhẹ ngược pha
      const wF=dfGs(x,y,180,186,22,34),ed=Math.max(0,(x-150)/45);                // vây quạt lưng: động cơ chính, gợn sóng nhanh dọc theo vây
      dx+=wF*ed*(5+3*A)*Math.sin(3*p+(y-150)*.14);dy+=wF*1.2*Math.sin(3*p+1.3);
      const wC=dfGs(x,y,148,52,48,46);dx+=wC*2.6*Math.sin(p+y*.09);dy+=wC*1.2*Math.sin(p+x*.08);   // mào gai gợn sóng
      const wT=dfSm(232,300,y);dx+=A*wT*Math.sin(p-2.4)*(y-238)*.11;             // đuôi cuộn vung quanh điểm (118,238)
      return[dx,dy]}}
};
// Ảnh do người chơi tải lên có kích thước khác ảnh gốc → dùng trường biến dạng chung (thân uốn sóng dọc theo chiều dài)
function dfGeneric(horizontal){return function(x,y,p,A){const W=this.W,H=this.H;
  if(horizontal){const u=Math.max(0,Math.min(1,(x-W*.35)/(W*.65)));return[0,W*.04*A*Math.pow(u,1.6)*Math.sin(p-2.2*u)]}
  const v=Math.max(0,Math.min(1,(y-H*.4)/(H*.6)));return[W*.05*A*Math.pow(v,1.25)*Math.sin(p-1.9*v),0]}}
const DFM_NP=16;
function dfmReset(){for(const k in DFM){DFM[k].fr={};DFM[k].s=0}}
function dfmBind(sp,im){   // gắn ảnh hiện tại (có thể là ảnh tùy chỉnh) vào loài
  if(sp.im===im&&sp.s)return true;
  const W=im.naturalWidth,H=im.naturalHeight;sp.im=im;sp.fr={};
  const std=sp.key=='sword'?(W==384&&H==229):(W==200&&H==320);
  if(!std){sp.W=W;sp.H=H;sp.fieldUse=dfGeneric(sp.key=='sword')}else{sp.W=sp.key=='sword'?384:200;sp.H=sp.key=='sword'?229:320;sp.fieldUse=null}
  sp.pad=Math.round(Math.max(sp.W,sp.H)*.07);
  const draw=sp.key=='sword'?sp.base*(SZK.sword||1):sp.base*(SZK.horse||1),dim=sp.key=='sword'?sp.W:sp.H;
  sp.s=Math.max(.25,Math.min(.8,draw*Math.max(1,DPR)*1.08/dim));   // độ phân giải khung cache: vừa đủ nét theo kích thước vẽ thực
  sp.nx=Math.ceil(sp.W/sp.cell);sp.ny=Math.ceil(sp.H/sp.cell);sp.mask=null;
  try{const m=document.createElement('canvas');m.width=sp.W;m.height=sp.H;const X=m.getContext('2d');X.drawImage(im,0,0,sp.W,sp.H);const d=X.getImageData(0,0,sp.W,sp.H).data;
    sp.mask=new Uint8Array(sp.nx*sp.ny);for(let j=0;j<sp.ny;j++)for(let i=0;i<sp.nx;i++){let ok=0;const x1=Math.min(sp.W,(i+1)*sp.cell),y1=Math.min(sp.H,(j+1)*sp.cell);
      outer:for(let y=j*sp.cell;y<y1;y+=2)for(let x=i*sp.cell;x<x1;x+=2)if(d[(y*sp.W+x)*4+3]>6){ok=1;break outer}sp.mask[j*sp.nx+i]=ok}}
  catch(e){sp.mask=null}   // (mở bằng file:// có thể bị chặn đọc điểm ảnh → vẽ mọi ô, vẫn đúng)
  return true;
}
function dfmFrame(sp,lv,k,np){
  const key=np*1000+lv*100+k;let fr=sp.fr[key];if(fr)return fr;
  const im=sp.im;if(!im)return null;
  const s=sp.s,pad=sp.pad,cw=Math.ceil((sp.W+2*pad)*s),ch=Math.ceil((sp.H+2*pad)*s),cv2=document.createElement('canvas');cv2.width=cw;cv2.height=ch;
  const X=cv2.getContext('2d'),nx=sp.nx,ny=sp.ny,cs=sp.cell,p=k/np*TAU,A=lv?1:.38,vx=new Float32Array((nx+1)*(ny+1)),vy=new Float32Array((nx+1)*(ny+1)),F=sp.fieldUse||sp.field;
  for(let j=0;j<=ny;j++)for(let i=0;i<=nx;i++){const x=Math.min(sp.W,i*cs),y=Math.min(sp.H,j*cs),d=F.call(sp,x,y,p,A),q=j*(nx+1)+i;vx[q]=x+d[0];vy[q]=y+d[1]}
  for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){
    if(sp.mask&&!sp.mask[j*nx+i])continue;
    const x0=i*cs,y0=j*cs,w=Math.min(cs,sp.W-x0),h=Math.min(cs,sp.H-y0),a=j*(nx+1)+i,b=a+1,c0=a+nx+1;
    X.setTransform(s*(vx[b]-vx[a])/w,s*(vy[b]-vy[a])/w,s*(vx[c0]-vx[a])/h,s*(vy[c0]-vy[a])/h,s*(vx[a]+pad),s*(vy[a]+pad));
    const m=.7,sx=Math.max(0,x0-m),sy=Math.max(0,y0-m),ex=Math.min(sp.W,x0+w+m),ey=Math.min(sp.H,y0+h+m);
    X.drawImage(im,sx,sy,ex-sx,ey-sy,sx-x0,sy-y0,ex-sx,ey-sy);   // mở rộng mép đọc 0,7 px mọi phía: không hở khe giữa các ô
  }
  try{c.save();c.globalAlpha=.01;c.drawImage(cv2,0,0,2,2);c.restore()}catch(e){}   // vẽ thử 1 lần (gần như trong suốt) để khung được tải lên GPU ngay → không giật ở lần vẽ đầu
  return sp.fr[key]={cv:cv2};
}
function dfmNP(){return QL>=2?8:DFM_NP}
let dfmQ=0;
function dfmWarm(){   // dựng dần các khung còn thiếu: tối đa 1 khung mỗi lần gọi → không giật
  const np=dfmNP(),names=['sword','horse'];
  for(let n=0;n<2;n++){const sp=DFM[names[(dfmQ+n)%2]],im=img(sp.key);if(!im||!im.naturalWidth)continue;dfmBind(sp,im);
    for(let lv=0;lv<2;lv++)for(let k=0;k<np;k++)if(!sp.fr[np*1000+lv*100+k]){dfmFrame(sp,lv,k,np);dfmQ++;return}}
}
// Vẽ cá ở gốc tọa độ hiện tại: ww×hh là kích thước hiển thị của ảnh gốc, ph∈[0,1) là pha vòng bơi, lv: 0 lơ lửng · 1 bơi
function dfmDraw(name,im,lv,ph,ww,hh){
  const sp=DFM[name];dfmBind(sp,im);const np=dfmNP();let k=Math.floor((((ph%1)+1)%1)*np)%np,fr=sp.fr[np*1000+lv*100+k];
  if(!fr){for(let d=1;d<np&&!fr;d++){fr=sp.fr[np*1000+lv*100+(k+d)%np]||sp.fr[np*1000+lv*100+(k-d+np)%np]}
    if(!fr&&lv==1)fr=sp.fr[np*1000+k]; }
  if(!fr){c.drawImage(im,-ww/2,-hh/2,ww,hh);return}   // khung chưa dựng kịp → hình tĩnh (chỉ trong ~1 giây đầu)
  const kx=ww/sp.W,ky=hh/sp.H,pw=sp.pad*kx,ph2=sp.pad*ky;
  c.drawImage(fr.cv,-ww/2-pw,-hh/2-ph2,ww+2*pw,hh+2*ph2);
}
// ---- Tư thế bơi tự nhiên: hướng nhìn theo chiều ngang (mượt, không đổi đột ngột), chúi/ngóc tối đa ±29° (±54° khi lao đâm), không bao giờ cắm đầu
function swimPose(o,dt,upright){
  const sp=Math.hypot(o.vx,o.vy),e=Math.min(1,dt*9);
  if(Math.abs(o.vx)>14)o.fd=o.vx>0?1:-1;else if(o.fd==null)o.fd=o.face||1;
  o.fs=(o.fs==null?o.fd:o.fs)+(o.fd-(o.fs==null?o.fd:o.fs))*e;
  if(!upright){const lim=o.lunge>0?.95:.5,tg=sp>22?Math.max(-lim,Math.min(lim,Math.atan2(o.vy,Math.abs(o.vx)+(o.lunge>0?12:55)))):0;o.pitch=(o.pitch||0)+(tg-(o.pitch||0))*Math.min(1,dt*(o.lunge>0?14:5))}
  else{const tg=Math.max(-.16,Math.min(.16,o.vx*.0022));o.pitch=(o.pitch||0)+(tg-(o.pitch||0))*Math.min(1,dt*4)}   // hải mã: nghiêng nhẹ theo hướng bơi
  o.sw=(o.sw==null?0:o.sw)+(Math.min(1,sp/(upright?70:110))-(o.sw==null?0:o.sw))*Math.min(1,dt*4);
  o.al=o.al?(o.sw>.2?1:0):(o.sw>.32?1:0);
  if(o.af==null)o.af=(o.ph||0)/TAU;o.af=(o.af+dt*(upright?.8+1.2*o.sw:.55+1.0*o.sw))%1000;
}
// ---- Giữ trong khung + chống kẹt: mục tiêu luôn nằm trong khung hiện tại, đẩy mềm khỏi mép, phát hiện kẹt tường → chọn đích mới ở giữa hồ
function keepInside(o,dt,x0,x1,y0,y1,free){
  if(x1<x0){const m=(x0+x1)/2;x0=x1=m}if(y1<y0){const m=(y0+y1)/2;y0=y1=m}
  if(o.tx!=null){o.tx=cl(o.tx,x0+18,x1-18);o.ty=cl(o.ty,y0+18,y1-18)}
  if(free){const m=70,kx0=Math.max(0,1-(o.x-x0)/m),kx1=Math.max(0,1-(x1-o.x)/m),ky0=Math.max(0,1-(o.y-y0)/m),ky1=Math.max(0,1-(y1-o.y)/m);   // lực đẩy mềm khỏi mép (chỉ khi bơi tự do)
    o.vx+=(kx0-kx1)*170*dt;o.vy+=(ky0-ky1)*170*dt}
  o.x+=o.vx*dt;o.y+=o.vy*dt;
  const nx=cl(o.x,x0,x1),ny=cl(o.y,y0,y1),hit=nx!=o.x||ny!=o.y;
  if(nx!=o.x)o.vx*=-.35;if(ny!=o.y)o.vy*=-.35;o.x=nx;o.y=ny;
  o.stuck=hit?(o.stuck||0)+dt:Math.max(0,(o.stuck||0)-dt*2);
  if(free&&o.stuck>.7){o.stuck=0;o.tx=R(x0+(x1-x0)*.2,x1-(x1-x0)*.2);o.ty=R(y0+(y1-y0)*.25,y1-(y1-y0)*.25);   // kẹt tường quá lâu → bơi vào giữa hồ
    const dx=o.tx-o.x,dy=o.ty-o.y,d=Math.hypot(dx,dy)||1;o.vx=dx/d*60;o.vy=dy/d*40}
}
