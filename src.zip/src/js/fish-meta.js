// Thông số bảng hình cá hề (tự sinh từ công cụ dựng atlas)
const CF_META={cw:276,ch:275,len:238.5};
