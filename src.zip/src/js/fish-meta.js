// Thông số bảng hình cá hề (tự sinh từ công cụ dựng atlas)
const CF_META={cw:276,ch:275,len:238.5,
  // khung nền cứng cho từng hướng bơi + vùng đuôi được uốn (toạ độ so với tâm ô, đơn vị điểm ảnh của atlas)
  side:{row:1,col:2,xs:-50,xe:-134},
  up:{row:2,col:3,ys:35,ye:126},
  down:{row:2,col:9,ys:-30,ye:-131}};
