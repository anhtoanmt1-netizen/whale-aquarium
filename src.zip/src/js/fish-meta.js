// Thông số bảng hình cá hề (tự sinh từ công cụ dựng atlas; toạ độ so với tâm ô, đơn vị điểm ảnh atlas)
// Ô: 0 nhìn phải · 1 nhìn trái · 2 thân bơi ngang (đã bỏ vây) · 3 vây ngực · 4 vây lưng · 5 vây bụng
//    6 thân bơi lên · 7/8 cánh vây trái/phải (lên) · 9 thân bơi xuống · 10/11 cánh vây trái/phải (xuống) · 12 hàm dưới
const CF_META={cw:276,ch:275,len:238.5,
  cell:{lookR:0,lookL:1,side:2,P:3,D:4,V:5,up:6,upL:7,upR:8,down:9,downL:10,downR:11,jaw:12},
  side:{xs:-50,xe:-134},up:{ys:35,ye:126},down:{ys:-30,ye:-131},
  fin:{P:{bb:[-14,2,50,58],pv:[-3,28]},D:{bb:[-24,-88,62,-43],pv:[20,-47]},V:{bb:[-6,54,46,87],pv:[18,57]},J:{bb:[86,22,119,47],pv:[97,26]}},
  wing:{L:{bb:[-97,-41,-37,41],pv:[-42,0]},R:{bb:[37,-41,97,41],pv:[42,0]}},
  mouth:{a:[98,25],b:[113,28.5]}};
