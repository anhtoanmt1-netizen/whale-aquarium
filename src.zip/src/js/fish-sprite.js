// ===== Cá hề (nhân vật chính): hoạt hình từ các mảnh hình gốc =====
// Thân giữ nguyên hình gốc; đuôi uốn theo sóng; vây ngực / vây bụng / vây lưng (và hai cánh vây khi bơi dọc) chuyển động riêng;
// miệng hé khi đớp mồi và khi thở bong bóng; quay đầu / lật mình được chuyển từ từ bằng cách xoay-ép hình (không đổi khung đột ngột).
const CF={state:'loading',img:null,tint:{}};
(function(){const i=new Image();i.onload=()=>{CF.img=i;CF.state='ready'};i.onerror=()=>{CF.state='failed'};i.src='fish-sheet.png'})();
const cfSS=(a,b,x)=>{x=Math.max(0,Math.min(1,(x-a)/(b-a)));return x*x*(3-2*x)};
function cfAtlas(k){   // bản tô màu (đói = xanh nhợt, giận = đỏ) tạo 1 lần khi cần
  if(k=='n')return CF.img;let c2=CF.tint[k];if(c2)return c2;
  c2=document.createElement('canvas');c2.width=CF.img.width;c2.height=CF.img.height;const x=c2.getContext('2d');x.drawImage(CF.img,0,0);
  x.globalCompositeOperation='source-atop';x.fillStyle=k=='h'?'rgba(110,190,130,.42)':'rgba(235,70,80,.36)';x.fillRect(0,0,c2.width,c2.height);
  return CF.tint[k]=c2}
// ---- Trạng thái hoạt hình (làm mượt theo thời gian)
function cfStep(s,dt,vx,vy,dir,look,size){
  if(s._ds===undefined){s._ds=dir;s._wv=0;s._sw=0;s._ph=(s.ph||0)/6.283;s._fp=s.ph||0;s._pi=0;s._lk=0;s._sc=size;s._vd=1;s._rl=0;s._vm=false;s._mo=0}
  const e=k=>1-Math.exp(-dt*k),sp=Math.hypot(vx,vy),tn=typeof t!=='undefined'?t:0;
  s._ds+=(dir-s._ds)*e(7);                                              // quay đầu: xoay-ép mềm, không đổi hướng đột ngột
  const ratio=Math.abs(vy)/(Math.abs(vx)+6);
  s._wv+=((sp>24?cfSS(1.9,3.0,ratio):0)-s._wv)*e(12);
  if(Math.abs(vy)>8)s._vd=vy<0?-1:1;
  s._sw+=(Math.min(1,sp/70)-s._sw)*e(5);                               // mức độ bơi (0 đứng → 1 lao nhanh)
  s._ph=(s._ph+dt*(.45+s._sw*1.0))%1000;                                // nhịp vẫy đuôi chậm
  s._fp+=dt*(5.6+5*s._sw);                                              // nhịp vẫy vây ngực (~0.9 → 1.8 Hz)
  s._pi+=((sp>10?Math.max(-1.4,Math.min(1.4,Math.atan2(vy,Math.abs(vx)+14))):0)-s._pi)*e(4);   // ngóc lên / chúi xuống
  s._lk+=(look-s._lk)*e(6);
  if(!s._vm&&s._wv>.6)s._vm=true;else if(s._vm&&s._wv<.35)s._vm=false;
  s._rl+=((s._vm?1:0)-s._rl)*e(9);                                      // lật mình: ngang ↔ nhìn từ trên (xoay quanh trục thân)
  s._sc+=(size-s._sc)*e(4);                                             // lớn lên từ từ khi lên cấp
  // miệng: há nhanh rồi ngậm khi đớp mồi; hé nhẹ khi thở bong bóng
  if(s._exNext===undefined)s._exNext=tn+1+Math.random()*3;
  if(tn>=s._exNext){s._exAt=tn;s._exNext=tn+2.5+Math.random()*4.5;s._exPend=true}
  let mt=0;
  if(s._eatAt!==undefined&&tn-s._eatAt<.36)mt=Math.pow(Math.sin(Math.PI*(tn-s._eatAt)/.36),.6);
  if(s._exAt!==undefined&&tn-s._exAt<.5)mt=Math.max(mt,.5*Math.sin(Math.PI*(tn-s._exAt)/.5));
  s._mo+=(mt-s._mo)*e(22);
}
// ---- Vẽ từng phần
function cfRegion(X,A,idx,bb){const cw=CF_META.cw,ch=CF_META.ch,r=Math.floor(idx/6),c=idx%6;
  X.drawImage(A,c*cw+cw/2+bb[0],r*ch+ch/2+bb[1],bb[2]-bb[0],bb[3]-bb[1],bb[0],bb[1],bb[2]-bb[0],bb[3]-bb[1])}
function cfPart(X,A,idx,o,ang){    // vẽ một mảnh (vây) xoay quanh điểm gốc của nó
  if(!ang){cfRegion(X,A,idx,o.bb);return}
  X.save();X.translate(o.pv[0],o.pv[1]);X.rotate(ang);X.translate(-o.pv[0],-o.pv[1]);cfRegion(X,A,idx,o.bb);X.restore()}
function cfFull(X,A,idx){const cw=CF_META.cw,ch=CF_META.ch,r=Math.floor(idx/6),c=idx%6;X.drawImage(A,c*cw,r*ch,cw,ch,-cw/2,-ch/2,cw,ch)}
// ---- Vây: gốc vây gắn thân luôn đứng yên, phần ngoài uốn theo sóng (cùng cách xử lý như đuôi).
// Mỗi tư thế (pha × mức bơi × màu) chỉ dựng 1 lần rồi dán lại → vẽ nhanh.
const CF_NP=20,CFP={};
const CF_FIN={
  P:{cell:'P',bb:[-14,2,50,58],axis:'x',xr:-4,xt:50,amp:[6,10,14],lag:.8,pw:1.2,N:4},       // vây ngực: gốc ở mép trái, mút vỗ lên xuống
  V:{cell:'V',bb:[-6,54,46,87],axis:'y',xr:57,xt:87,amp:[5,8,11],lag:1.2,pw:1.3,N:3},       // vây bụng: gốc ở sát bụng, mút đung đưa
  D:{cell:'D',bb:[-24,-88,62,-43],axis:'y',xr:-46,xt:-88,amp:[3,5,7],lag:1.4,pw:1.3,N:3},   // vây lưng: gốc ở sát lưng
  WLu:{cell:'upL',bb:[-97,-41,-37,41],axis:'x',xr:-42,xt:-97,amp:[5,8,11],lag:.8,pw:1.2,N:4},  // hai cánh vây khi bơi dọc (nhìn từ trên)
  WRu:{cell:'upR',bb:[37,-41,97,41],axis:'x',xr:42,xt:97,amp:[5,8,11],lag:.8,pw:1.2,N:4},
  WLd:{cell:'downL',bb:[-97,-41,-37,41],axis:'x',xr:-42,xt:-97,amp:[5,8,11],lag:.8,pw:1.2,N:4},
  WRd:{cell:'downR',bb:[37,-41,97,41],axis:'x',xr:42,xt:97,amp:[5,8,11],lag:.8,pw:1.2,N:4}};
function cfPose(tint,key,pi,lv){
  const id=tint+key+pi+'_'+lv;let p=CFP[id];if(p)return p;
  const d=CF_FIN[key],A=cfAtlas(tint),amp=d.amp[lv],ph=pi/CF_NP*Math.PI*2,bb=d.bb,m=Math.ceil(amp*1.15)+3,bw=bb[2]-bb[0],bh=bb[3]-bb[1];
  const cv=document.createElement('canvas');cv.width=bw+2*m;cv.height=bh+2*m;const X=cv.getContext('2d');X.translate(m-bb[0],m-bb[1]);
  const cw=CF_META.cw,ch=CF_META.ch,idx=CF_META.cell[d.cell],ox=(idx%6)*cw+cw/2,oy=Math.floor(idx/6)*ch+ch/2,N=d.N;
  const ax=d.axis=='x',r0=d.xr,r1=d.xt,L=r1-r0,dir=Math.sign(L),al=Math.abs(L);
  const disp=u=>amp*Math.pow(u,d.pw)*Math.sin(ph-d.lag*u);
  // phần sát gốc: đứng yên
  const rootEdge=ax?(dir>0?bb[0]:bb[2]):(dir>0?bb[1]:bb[3]);
  const flo=Math.min(rootEdge,r0),fhi=Math.max(rootEdge,r0);
  if(fhi-flo>0){if(ax)X.drawImage(A,ox+flo,oy+bb[1],fhi-flo,bh,flo,bb[1],fhi-flo,bh);else X.drawImage(A,ox+bb[0],oy+flo,bw,fhi-flo,bb[0],flo,bw,fhi-flo)}
  for(let i=0;i<N;i++){
    const pa=r0+dir*al*i/N,pb=r0+dir*al*(i+1)/N,da=disp(i/N),db=disp((i+1)/N),sl=(db-da)/(pb-pa),lo=dir>0?pa:pb-.9,wd=Math.abs(pb-pa)+.9;   // phần chồng mép nằm về phía mút vây, không lấn vào gốc
    X.save();
    if(ax){X.transform(1,sl,0,1,0,da-sl*pa);X.drawImage(A,ox+lo,oy+bb[1],wd,bh,lo,bb[1],wd,bh)}
    else{X.transform(1,0,sl,1,da-sl*pa,0);X.drawImage(A,ox+bb[0],oy+lo,bw,wd,bb[0],lo,bw,wd)}
    X.restore();
  }
  return CFP[id]={cv,ox:bb[0]-m,oy:bb[1]-m};
}
function cfFinDraw(X,tint,key,phase,lv){   // phase: góc pha (rad); lv: mức bơi 0..2
  const pi=Math.floor((((phase/(2*Math.PI))%1)+1)%1*CF_NP)%CF_NP,p=cfPose(tint,key,pi,lv);X.drawImage(p.cv,p.ox,p.oy)}
const cfBendAmp=(u,amp,tt)=>amp*Math.pow(u,1.6)*Math.sin(tt-2.2*u);
function cfBendSide(X,A,tt,amp,N){            // thân cứng + đuôi uốn sóng (cá ngang)
  const cw=CF_META.cw,ch=CF_META.ch,b=CF_META.side,idx=CF_META.cell.side,x0=(idx%6)*cw,y0=Math.floor(idx/6)*ch,hx=cw/2,xs=b.xs,Lb=xs-b.xe;
  X.drawImage(A,x0+hx+xs,y0,hx-xs,ch,xs,-ch/2,hx-xs,ch);
  for(let i=0;i<N;i++){
    const xa=xs-i*Lb/N,xb=xs-(i+1)*Lb/N,ya=cfBendAmp(i/N,amp,tt),yb=cfBendAmp((i+1)/N,amp,tt),sl=(yb-ya)/(xb-xa);
    X.save();X.transform(1,sl,0,1,0,ya-sl*xa);X.drawImage(A,x0+hx+xb,y0,xa-xb+.9,ch,xb,-ch/2,xa-xb+.9,ch);X.restore();
  }
}
function cfBendV(X,A,tt,amp,N,up){            // thân cứng + đuôi uốn sóng (cá bơi dọc, nhìn từ trên)
  const cw=CF_META.cw,ch=CF_META.ch,b=up?CF_META.up:CF_META.down,idx=up?CF_META.cell.up:CF_META.cell.down,x0=(idx%6)*cw,y0=Math.floor(idx/6)*ch,hx=cw/2,hy=ch/2,ys=b.ys,Lb=Math.abs(b.ye-b.ys),dir=up?1:-1;
  if(up)X.drawImage(A,x0,y0,cw,hy+ys,-hx,-hy,cw,hy+ys);else X.drawImage(A,x0,y0+hy+ys,cw,hy-ys,-hx,ys,cw,hy-ys);
  for(let i=0;i<N;i++){
    const ya=ys+dir*i*Lb/N,yb=ys+dir*(i+1)*Lb/N,da=cfBendAmp(i/N,amp,tt),db=cfBendAmp((i+1)/N,amp,tt),sl=(db-da)/(yb-ya),top=Math.min(ya,yb),h=Math.abs(yb-ya)+.9;
    X.save();X.transform(1,0,sl,1,da-sl*ya,0);X.drawImage(A,x0,y0+hy+top,cw,h,-hx,top,cw,h);X.restore();
  }
}
// ---- Nướng sẵn khung bơi cá hề (góc nhìn ngang): thân + đuôi + hàm + 3 vây gộp thành 1 ảnh → mỗi con chỉ 1 lệnh vẽ.
// Dùng khi chất lượng thấp (QL≥1) hoặc hồ đông (≥25 cá). Trạng thái đặc biệt (đói/giận/mở miệng/quay đầu/bơi dọc) vẫn dùng đường vẽ đầy đủ.
const CFB={},CFB_NP=12;let cfbN=0;
function cfBaked(k,tt,sw){
  const kb=Math.max(.06,Math.round(k*28)/28),pi=Math.floor((((tt/(Math.PI*2))%1)+1)%1*CFB_NP)%CFB_NP,lv=sw<.25?0:sw<.7?1:2,key=kb+'_'+SQ+'_'+pi+'_'+lv;let fr=CFB[key];if(fr)return fr;
  if(cfbN>600){for(const q in CFB)delete CFB[q];cfbN=0}
  const cw=CF_META.cw,ch=CF_META.ch,pr=kb*SQ,w=Math.ceil(cw*pr),h=Math.ceil(ch*pr),cv2=document.createElement('canvas');cv2.width=w;cv2.height=h;
  const X=cv2.getContext('2d'),A=cfAtlas('n'),ph=pi/CFB_NP*Math.PI*2,swv=[.1,.45,.9][lv];
  X.setTransform(pr,0,0,pr,w/2,h/2);
  cfFinDraw(X,'n','D',ph-1.2,lv);cfBendSide(X,A,ph,CF_META.len*(.026+.072*swv),7);cfPart(X,A,CF_META.cell.jaw,CF_META.fin.J,0);cfFinDraw(X,'n','V',2*ph+2.4,lv);cfFinDraw(X,'n','P',2*ph,lv);
  cfbN++;return CFB[key]={cv:cv2};
}
function cfRender(X,s,x,y,size,tint,rx){
  if(CF.state!=='ready')return;
  const A=cfAtlas(tint),k=s._sc*2.85/CF_META.len,L=s._sc*2.85,rk=rx&&rx.k,tt=s._ph*Math.PI*2,fp=s._fp,sw=s._sw,rl=s._rl;
  const N=typeof PF==='undefined'?7:Math.max(3,(PF.fps>=60?9:PF.fps>30?7:5)-[0,2,3,4][QL]),tn=typeof t!=='undefined'?t:0;
  const shake=rk=='angry'?Math.sin(tn*50)*2.5:0,bob=Math.sin(tn*.7+(s.ph||0))*.008*L+shake;
  X.save();X.translate(x+shake,y+bob);
  if(rk=='love')X.rotate(Math.sin(tn*14)*.22);
  if(rk=='shy')X.scale(.85,.85);
  const sg=Math.sign(s._ds||1),a=Math.abs(s._ds);
  // độ ép ngang khi quay đầu / quay mặt: không bao giờ mỏng như tờ giấy (tối thiểu 35%), đổi sang khung 3/4 khi đã ép còn 62%
  const lk=s._lk,sqL=lk<.5?1-.38*(lk*2):.62+.38*(lk*2-1),sqT=Math.max(.35,a);
  const sq=Math.min(sqL,sqT),useLook=(lk>=.5)||(a<.62);
  if(rl>=.5){            // ---- nhìn từ trên (bơi dọc): hai cánh vây chuyển động xen kẽ
    const w=.4+.6*(rl*2-1),up=s._vd<0,amp=CF_META.len*(.018+.058*sw),ang=.15+.1*sw;
    X.scale(k*w,k);cfBendV(X,A,tt,amp,N,up);
    const ci=up?[CF_META.cell.upL,CF_META.cell.upR]:[CF_META.cell.downL,CF_META.cell.downR];
    const lv=sw<.25?0:sw<.7?1:2;cfFinDraw(X,tint,up?'WLu':'WLd',fp,lv);cfFinDraw(X,tint,up?'WRu':'WRd',fp+2.1,lv);   // hai cánh vây lệch pha: bên lên bên xuống
  }else if(rl<.02&&useLook){   // ---- khung 3/4 nhìn về phía người chơi (khi quay đầu / nói chuyện / ngại)
    X.scale(sq*k,k);cfFull(X,A,sg>0?CF_META.cell.lookR:CF_META.cell.lookL);
  }else{                 // ---- nhìn ngang (đứng bơi / bơi)
    const ph=s._pi,rot=ph+(rl>0?(Math.PI/2*Math.sign(ph||s._vd)-ph)*(rl*2):0),sqY=1-.6*(rl*2);
    X.rotate(rot*sg*a+Math.sin(tt-.9)*.01*sw);X.scale(sg*sq*k,k*sqY);
    const lv=sw<.25?0:sw<.7?1:2;
    if((QL>=1||fish.length>=25)&&tint==='n'&&!rk&&!(s._mo>.04)&&X===c){const fr=cfBaked(k,tt,sw),cw=CF_META.cw,ch=CF_META.ch;X.drawImage(fr.cv,-cw/2,-ch/2,cw,ch);X.restore();X.globalAlpha=1;return}   // đường nhanh: 1 lệnh vẽ
    cfFinDraw(X,tint,'D',tt-1.2,lv);                                     // vây lưng đung đưa theo sóng đuôi
    cfBendSide(X,A,tt,CF_META.len*(.026+.072*sw),N);                    // thân + đuôi
    cfPart(X,A,CF_META.cell.jaw,CF_META.fin.J,s._mo*.62);               // hàm dưới hạ xuống: miệng hé
    cfFinDraw(X,tint,'V',fp+2.4,lv);                                     // vây bụng (gốc cố định)
    cfFinDraw(X,tint,'P',fp,lv);                                         // vây ngực vỗ lên xuống, gốc gắn thân đứng yên
  }
  X.restore();X.globalAlpha=1;
}
// ---- Bong bóng từ miệng (cỡ bong bóng theo cỡ cá)
function cfMouthWorld(s){
  const k=s._sc*2.85/CF_META.len,sg=Math.sign(s._ds||1),m=CF_META.mouth.b,th=s._pi*sg*Math.abs(s._ds),X0=sg*k*m[0],Y0=k*m[1];
  return [s.x+X0*Math.cos(th)-Y0*Math.sin(th),s.y+X0*Math.sin(th)+Y0*Math.cos(th)]}
function cfBubble(f,n){
  if(typeof bubbles==='undefined'||bubbles.length>=PF.fb+8)return;const L=f._sc*2.85,p=f._rl>.5?[f.x,f.y]:cfMouthWorld(f);
  for(let i=0;i<n;i++)bubbles.push({x:p[0]+R(-1.5,1.5),y:p[1]+R(-1,1),r:Math.max(1.6,L*(.028+Math.random()*.02)),ph:R(0,6)})}
// ---- Cá trong hồ
function cfGame(f){
  const dt=f._lt===undefined?0:Math.min(.1,t-f._lt);f._lt=t;
  const sp=Math.hypot(f.vx,f.vy),rk=f.rx&&f.rx.k,size=sz(f);
  const look=(f.say||rk=='love'||rk=='shy')&&sp<14?1:0;
  cfStep(f,dt,f.vx,f.vy,f.dir,look,size);
  if(f._exPend&&t-f._exAt>.2&&f._rl<.5){f._exPend=false;cfBubble(f,1)}                 // hé miệng thở ra bong bóng nhỏ
  if(f._eatAt!==undefined&&f._eatAt!==f._eatSeen){f._eatSeen=f._eatAt;f._eatB=f._eatAt+.14}
  if(f._eatB&&t>=f._eatB){f._eatB=0;if(f._rl<.5)cfBubble(f,1+(Math.random()<.5?1:0))}   // đớp mồi: nhả vài bong bóng li ti
  cfRender(c,f,f.x,f.y,size,rk=='angry'?'a':f.hunger>70?'h':'n',f.rx);
}
// ---- Hình cá hề nhỏ trong danh sách cá
const CF_TH={};
function cfThumb(X,f,cx,cy){
  let s=CF_TH[f.id];if(!s){s=CF_TH[f.id]={ph:f.ph,_lt:t}}
  const dt=Math.min(.1,t-s._lt);s._lt=t;const vx=Math.cos(t*.8+f.ph)*34,vy=Math.cos(t*1.6+f.ph)*6;
  s._eatAt=undefined;cfStep(s,dt,vx,vy,vx>=0?1:-1,0,24);cfRender(X,s,cx,cy,24,f.hunger>70?'h':'n',null);
}
