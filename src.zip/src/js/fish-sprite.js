// ===== Cá hề (nhân vật chính): hoạt hình từ bảng hình (atlas) =====
// Bảng hình (12 cột): hàng 0 = đứng bơi (12 khung), hàng 1 = bơi ngang (12 khung),
//   hàng 2 = bơi lên (cột 0-5) + bơi xuống (cột 6-11), hàng 3 = nhìn phải / trái / lên / xuống.
// 12 khung = 6 khung gốc + 6 khung trung gian nội suy từ chính các khung gốc (cùng nét vẽ, cùng hình dáng).
const CF={state:'loading',img:null,tint:{}};
(function(){const i=new Image();i.onload=()=>{CF.img=i;CF.state='ready'};i.onerror=()=>{CF.state='failed'};i.src='fish-sheet.png'})();
const cfSS=(a,b,x)=>{x=Math.max(0,Math.min(1,(x-a)/(b-a)));return x*x*(3-2*x)};
// Bản tô màu (đói = xanh nhợt, giận = đỏ) tạo 1 lần khi cần
function cfAtlas(k){
  if(k=='n')return CF.img;let c2=CF.tint[k];if(c2)return c2;
  c2=document.createElement('canvas');c2.width=CF.img.width;c2.height=CF.img.height;const x=c2.getContext('2d');x.drawImage(CF.img,0,0);
  x.globalCompositeOperation='source-atop';x.fillStyle=k=='h'?'rgba(110,190,130,.42)':'rgba(235,70,80,.36)';x.fillRect(0,0,c2.width,c2.height);
  return CF.tint[k]=c2}
// Cập nhật trạng thái hoạt hình mượt (lọc theo thời gian, không nhảy khung)
function cfStep(s,dt,vx,vy,dir,look,size){
  if(s._ds===undefined){s._ds=dir;s._wv=0;s._sw=0;s._ph=(s.ph||0)/6.283;s._pi=0;s._lk=0;s._sc=size;s._vd=1;s._fl=0}
  const e=k=>1-Math.exp(-dt*k),sp=Math.hypot(vx,vy);
  s._ds+=(dir-s._ds)*e(8);                                              // quay đầu: lật mềm, không đổi hướng đột ngột
  const ratio=Math.abs(vy)/(Math.abs(vx)+6);
  s._wv+=((sp>24?cfSS(1.9,3.0,ratio):0)-s._wv)*e(12);                  // bơi dọc → chuyển sang khung nhìn từ trên
  if(Math.abs(vy)>8)s._vd=vy<0?-1:1;
  s._sw+=(Math.min(1,sp/70)-s._sw)*e(5);                               // mức độ bơi (0 đứng → 1 lao nhanh)
  s._ph=(s._ph+dt*(.45+s._sw*1.0))%1000;                                // nhịp vẫy đuôi chậm: ~0.45 Hz khi đứng, ~1.1 Hz khi bơi thường, ~1.45 Hz khi lao tới mồi
  s._pi+=((sp>10?Math.max(-.5,Math.min(.5,Math.atan2(vy,Math.abs(vx)+14))):0)-s._pi)*e(4);   // ngóc lên / chúi xuống
  s._lk+=(look-s._lk)*e(6);
  if(!s._vm&&s._wv>.6)s._vm=true;else if(s._vm&&s._wv<.35)s._vm=false;      // chế độ bơi dọc (nhìn từ trên), có độ trễ chống nhấp nháy
  if(!s._sm&&s._sw>.5)s._sm=true;else if(s._sm&&s._sw<.22)s._sm=false;      // chế độ bơi (thay vì đứng bơi)
  const md=(s._lk>.5||Math.abs(s._ds)<.34)?2:s._vm?1:0;                      // 0 = nhìn ngang, 1 = nhìn từ trên (bơi dọc), 2 = quay mặt 3/4
  if(s._md!==undefined&&md!==s._md)s._tp=1;s._md=md;s._tp=Math.max(0,(s._tp||0)-dt*8);
  s._sc+=(size-s._sc)*e(4);                                             // lớn lên từ từ khi lên cấp
}
// Vẽ một khung (hàng r, cột c) tại gốc toạ độ hiện tại
function cfCell(X,A,r,c,k,alpha,sx){
  const cw=CF_META.cw,ch=CF_META.ch;X.globalAlpha=alpha;
  if(sx!==1){X.save();X.scale(sx,1)}
  X.drawImage(A,c*cw,r*ch,cw,ch,-cw*k/2,-ch*k/2,cw*k,ch*k);
  if(sx!==1)X.restore();
}
// Thân + đầu giữ NGUYÊN khung nền (không lắc); chỉ phần đuôi được chia lát và uốn theo sóng lan từ gốc đuôi ra mút đuôi
const cfBendAmp=(u,amp,tt)=>amp*Math.pow(u,1.6)*Math.sin(tt-2.2*u);
function cfBendSide(X,A,tt,amp,N){            // cá bơi ngang: đuôi ở bên trái ô
  const cw=CF_META.cw,ch=CF_META.ch,b=CF_META.side,x0=b.col*cw,y0=b.row*ch,hx=cw/2,xs=b.xs,Lb=xs-b.xe;
  X.globalAlpha=1;X.drawImage(A,x0+hx+xs,y0,hx-xs,ch,xs,-ch/2,hx-xs,ch);
  for(let i=0;i<N;i++){
    const xa=xs-i*Lb/N,xb=xs-(i+1)*Lb/N,ya=cfBendAmp(i/N,amp,tt),yb=cfBendAmp((i+1)/N,amp,tt),sl=(yb-ya)/(xb-xa);
    X.save();X.transform(1,sl,0,1,0,ya-sl*xa);X.drawImage(A,x0+hx+xb,y0,xa-xb+.9,ch,xb,-ch/2,xa-xb+.9,ch);X.restore();
  }
}
function cfBendV(X,A,tt,amp,N,up){            // cá bơi dọc (nhìn từ trên): đuôi ở dưới (lên) hoặc ở trên (xuống)
  const cw=CF_META.cw,ch=CF_META.ch,b=up?CF_META.up:CF_META.down,x0=b.col*cw,y0=b.row*ch,hx=cw/2,hy=ch/2,ys=b.ys,Lb=Math.abs(b.ye-b.ys),dir=up?1:-1;
  if(up)X.drawImage(A,x0,y0,cw,hy+ys,-hx,-hy,cw,hy+ys);else X.drawImage(A,x0,y0+hy+ys,cw,hy-ys,-hx,ys,cw,hy-ys);
  for(let i=0;i<N;i++){
    const ya=ys+dir*i*Lb/N,yb=ys+dir*(i+1)*Lb/N,da=cfBendAmp(i/N,amp,tt),db=cfBendAmp((i+1)/N,amp,tt),sl=(db-da)/(yb-ya);
    const top=Math.min(ya,yb),h=Math.abs(yb-ya)+.9;
    X.save();X.transform(1,0,sl,1,da-sl*ya,0);X.drawImage(A,x0,y0+hy+top,cw,h,-hx,top,cw,h);X.restore();
  }
}
function cfRender(X,s,x,y,size,tint,rx){
  if(CF.state!=='ready')return;
  const A=cfAtlas(tint),k=s._sc*2.85/CF_META.len,L=s._sc*2.85,rk=rx&&rx.k,tt=s._ph*Math.PI*2,N=(typeof PF!=='undefined'&&PF.fps>30)?9:7;
  const bob=Math.sin(t*.7+(s.ph||0))*.008*L+(rk=='angry'?Math.sin(t*50)*2.5:0);   // chỉ nhấp nhô rất chậm như đang lơ lửng (không theo nhịp đuôi)
  X.save();X.translate(x+(rk=='angry'?Math.sin(t*50)*2.5:0),y+bob);
  if(rk=='love')X.rotate(Math.sin(t*14)*.22);
  const sh=rk=='shy'?.85:1,pulse=sh*(1-.08*Math.sin(Math.PI*(1-(s._tp||0))));X.scale(pulse,pulse);
  const sx=Math.sign(s._ds||1)*Math.pow(Math.abs(s._ds),.75);
  // Mỗi lần chỉ vẽ MỘT kiểu (không chồng mờ) → hình luôn đặc, sắc nét
  if(s._md===2){cfCell(X,A,3,s._ds>=0?0:1,k,1,1)}                             // khi quay đầu / nói chuyện / làm nũng / ngại: quay mặt về phía người chơi
  else if(s._md===1){X.scale(k,k);cfBendV(X,A,tt,CF_META.len*(.018+.058*s._sw),N,s._vd<0)}
  else{X.rotate(s._pi*Math.sign(s._ds||1)*Math.abs(s._ds)+Math.sin(tt-.9)*.01*s._sw);X.scale(sx*k,k);cfBendSide(X,A,tt,CF_META.len*(.026+.072*s._sw),N)}
  X.restore();X.globalAlpha=1;
}
// Cá trong hồ
function cfGame(f){
  const dt=f._lt===undefined?0:Math.min(.1,t-f._lt);f._lt=t;
  const sp=Math.hypot(f.vx,f.vy),rk=f.rx&&f.rx.k,size=sz(f);
  const look=(f.say||rk=='love'||rk=='shy')&&sp<14?1:0;
  cfStep(f,dt,f.vx,f.vy,f.dir,look,size);
  cfRender(c,f,f.x,f.y,size,rk=='angry'?'a':f.hunger>70?'h':'n',f.rx);
}
// Hình cá hề nhỏ trong danh sách cá
const CF_TH={};
function cfThumb(X,f,cx,cy){
  let s=CF_TH[f.id];if(!s){s=CF_TH[f.id]={ph:f.ph,_lt:t}}
  const dt=Math.min(.1,t-s._lt);s._lt=t;const vx=Math.cos(t*.8+f.ph)*34,vy=Math.cos(t*1.6+f.ph)*6;
  cfStep(s,dt,vx,vy,vx>=0?1:-1,0,24);cfRender(X,s,cx,cy,24,f.hunger>70?'h':'n',null);
}
