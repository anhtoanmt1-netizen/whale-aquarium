// ---- Tập tính: khi có quái vật, cá tụ thành đàn ở nơi xa quái nhất, run rẩy bơi sát nhau (lo lắng → hoảng sợ)
let SHL=null;   // điểm tụ đàn
function shoalUpdate(){
  const a=THREAT;if(!a){SHL=null;return}
  if(SHL){const dd=Math.hypot(SHL.x-a.x,SHL.y-a.y);if(dd>Math.min(W,H)*.52||(t-SHL.t0<3.5&&dd>100))return}   // còn đủ xa, hoặc vừa mới chọn (chưa kịp bơi tới) thì giữ nguyên, tránh lưỡng lự
  let cx=0,cy=0;for(const f of fish){cx+=f.x;cy+=f.y}const n=fish.length||1;cx/=n;cy/=n;
  // quái đang lao về phía đàn: dự đoán nó sẽ ở gần đàn hơn ~130px rồi mới chấm điểm các chỗ trú
  const pd=Math.hypot(cx-a.x,cy-a.y)||1,pa={x:a.x+(cx-a.x)/pd*Math.min(130,pd),y:a.y+(cy-a.y)/pd*Math.min(130,pd)};
  let best=null,bs=-1e9;
  for(const p of [[.15,.78],[.85,.78],[.5,.86],[.15,.36],[.85,.36],[.5,.3]]){
    const x=W*p[0],y=Math.min(H-90,TOP+(H-TOP)*p[1]);
    // khoảng cách từ quái tới đường bơi (đàn → chỗ trú): đường đi sát quái thì bị trừ điểm nặng
    const vx=x-cx,vy=y-cy,L2=vx*vx+vy*vy||1,u=Math.max(0,Math.min(1,((pa.x-cx)*vx+(pa.y-cy)*vy)/L2)),sd=Math.hypot(cx+vx*u-pa.x,cy+vy*u-pa.y);
    const sc=Math.hypot(x-pa.x,y-pa.y)+2*Math.min(sd,230)-.3*Math.hypot(x-cx,y-cy);
    if(sc>bs){bs=sc;best={x,y,t0:t}}}
  SHL=best;
}
function shoalSlot(f){   // mỗi cá một vị trí riêng trong đàn, cả đàn xoay rất chậm và run nhẹ
  const n=fish.length,rr=(16+Math.sqrt(n)*15)*(.4+.6*((f.ph*3.17)%1)),a=f.ph*2.1+t*.15;
  return{x:SHL.x+Math.cos(a)*rr*1.35+Math.sin(t*3+f.ph*5)*5,y:SHL.y+Math.sin(a)*rr*.7+Math.cos(t*2.6+f.ph*4)*4};
}
