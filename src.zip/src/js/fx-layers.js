// Nền: ảnh nền + MỘT lớp tia nắng vẽ sẵn (chỉ dịch chuyển, chạy trên GPU) · đốm sáng & bong bóng nước vẽ trên canvas.
// Trước đây ~60 phần tử CSS động làm máy yếu rớt còn 1–10 FPS; giờ chỉ còn tối đa 1 lớp ghép.
function setBg(d){const b=$('bgL');b.style.backgroundImage=d?'url('+d+')':'';document.body.classList.toggle('cbg',!!d)}
let SPK=[],ambBub=[],spkSpr=null;
function buildFx(){
  const rays=$('rays');rays.innerHTML='';$('spk').innerHTML='';$('bubs').innerHTML='';
  if(QL<2&&PF.ray>0){   // tia nắng: vẽ 1 lần vào ảnh, rồi chỉ trượt nhẹ (QL≥1: đứng yên, QL≥2: tắt)
    const cv2=document.createElement('canvas');cv2.width=192;cv2.height=384;const X=cv2.getContext('2d');
    for(let i=0;i<PF.ray;i++){const x0=(i+.5)/PF.ray*192,wd=10+(i%2)*8,g=X.createLinearGradient(0,0,0,384*.9);g.addColorStop(0,'rgba(255,255,225,.30)');g.addColorStop(1,'rgba(255,255,225,0)');X.fillStyle=g;X.beginPath();X.moveTo(x0-wd,0);X.lineTo(x0+wd,0);X.lineTo(x0+wd+60,384);X.lineTo(x0-wd+60,384);X.closePath();X.fill()}
    const d=document.createElement('div');d.className='rays1'+(QL>=1?' still':'');d.style.backgroundImage='url('+cv2.toDataURL()+')';rays.appendChild(d);rays.style.display='';
  }else rays.style.display='none';
  SPK=Array.from({length:Math.round(PF.spk*[1,.5,0,0][QL])},()=>({x:R(.02,.96),y:R(.04,.82),z:R(7,15),ph:R(0,6),sp:R(.7,1.5)}));
  const nb=Math.round(PF.bub*[1,.6,.3,0][QL]);ambBub=Array.from({length:nb},()=>({x:R(0,W||innerWidth),y:R(0,H||innerHeight),r:R(2,9),ph:R(0,6),vy:R(16,40)}));
}
function updAmb(dt){for(const b of ambBub){b.y-=b.vy*dt;b.x+=Math.sin(t*1.3+b.ph)*10*dt;if(b.y<-12){b.y=H+12;b.x=R(0,W);b.r=R(2,9)}}}
function drawAmb(){   // bong bóng nước nổi + đốm sáng lấp lánh (sprite có sẵn, rất nhẹ)
  for(const b of ambBub){const sp=bubSpr(b.r),x=b.x+Math.sin(t*.8+b.ph)*6;c.globalAlpha=Math.min(1,Math.max(0,b.y/(H*.12)))*.8;c.drawImage(sp.cv,x-sp.d/2,b.y-sp.d/2,sp.d,sp.d)}
  if(SPK.length){if(!spkSpr||spkSpr.q!==SQ){const q=SQ,cv2=document.createElement('canvas');cv2.width=cv2.height=Math.ceil(32*q);const X=cv2.getContext('2d');X.setTransform(q,0,0,q,0,0);X.translate(16,16);X.fillStyle='#fffbe0';X.beginPath();X.moveTo(0,-15);X.lineTo(4,-5);X.lineTo(15,0);X.lineTo(4,5);X.lineTo(0,15);X.lineTo(-4,5);X.lineTo(-15,0);X.lineTo(-4,-5);X.closePath();X.fill();spkSpr={cv:cv2,q}}
    for(const s of SPK){const a=Math.max(0,Math.sin(t*s.sp+s.ph));if(a<.06)continue;const z=s.z*(.35+.65*a)*Z;c.globalAlpha=a*.85;c.drawImage(spkSpr.cv,s.x*W-z/2,s.y*H-z/2,z,z)}}
  c.globalAlpha=1;
}
buildFx();
