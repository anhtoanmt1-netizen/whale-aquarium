// ---- Vòng lặp chính: giữ đúng số khung hình mỗi giây theo chế độ hiệu năng (30 / 45 / 60 FPS)
let last=performance.now(),lastDraw=last,acc=0,fpsN=0,fpsT=last,slowN=0,slowWarned=false,errN=0;
// ---- Tự điều chỉnh chất lượng (QL 0→3): máy yếu → giảm độ phân giải canvas, tắt hiệu ứng nền, giảm chi tiết cá; máy khỏe lại → thử tăng trở lại
let lastQ=performance.now(),lowN=0,goodN=0,recoverTry=0;const BOOT=performance.now();
function applyQ(){resize();buildFx();if(typeof menuQ=='function')menuQ();S.ql0=QL;try{save()}catch(e){}}
function qGov(fp,target,now){
  if(S.autoq===false||document.hidden||now-BOOT<3500)return;
  if(fp<target*.8){goodN=0;if(++lowN>=2&&QL<3&&now-lastQ>2500){QL++;lastQ=now;lowN=0;applyQ();say('Máy hơi nặng: tự giảm chất lượng (mức '+QL+'/3) để chơi mượt hơn')}}
  else{lowN=0;if(fp>=target*.97){if(++goodN>=40&&QL>0&&now-lastQ>40000&&recoverTry<2){QL--;recoverTry++;lastQ=now;goodN=0;applyQ()}}else goodN=0}
}
function loop(n){requestAnimationFrame(loop);
  acc+=Math.min(n-last,100);last=n;const iv=1000/PF.fps;if(acc<iv-2)return;acc=(acc-iv>iv)?0:acc-iv;
  const dt=Math.min(.06,(n-lastDraw)/1000);lastDraw=n;
  try{if(MODE!=='menu'){update(dt);draw()}}catch(err){if(++errN<=3&&window.__bar)__bar('Lỗi khi chạy game: '+err.message,String(err.stack||'').split('\n').slice(0,3).join(' | '));console.error(err)}
  fpsN++;if(n-fpsT>=1000){const fp=Math.round(fpsN*1000/(n-fpsT));if(S.showfps)$('fpsb').textContent='FPS '+fp+' / '+PF.fps+' · '+PN[S.perf]+' · ×'+DPR.toFixed(2)+' · Q'+QL;qGov(fp,PF.fps,n);
    if(fp<PF.fps*.6&&S.perf!=='eco'){if(++slowN>=4&&!slowWarned){slowWarned=true;say('Máy đang hơi nặng ('+fp+' FPS). Thử chế độ 🔋 Tiết kiệm trong ⚙️ → Hiển thị')}}else slowN=0;
    fpsN=0;fpsT=n}}
WR=1;
if(S.autoq!==false){const q=Math.floor(+S.ql0||0);if(q>0&&q<=3){QL=q;resize();buildFx()}}   // máy yếu: bắt đầu ngay ở mức chất lượng đã học được lần trước
document.addEventListener('visibilitychange',()=>{if(document.hidden)try{save()}catch(e){}});addEventListener('pagehide',()=>{try{save()}catch(e){}});
requestAnimationFrame(loop);
$('fpsb').style.display=S.showfps?'block':'none';
window.__booted=true;
if('serviceWorker' in navigator)addEventListener('load',()=>{const had=!!navigator.serviceWorker.controller;let rl=false;
  navigator.serviceWorker.register('sw.js').catch(()=>{});
  navigator.serviceWorker.addEventListener('controllerchange',()=>{if(had&&!rl){rl=true;location.reload()}})});
