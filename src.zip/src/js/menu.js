// ================= MENU CHÍNH: thế giới đại dương sống động + chuyển chế độ =================
(function buildMenu(){
  const d=document.createElement('div');d.innerHTML=`
<div id="menu"><canvas id="mc"></canvas>
 <div class="mwrap">
  <div class="mhead"><div class="mlogo" id="mlogo"></div><div class="msub">Thế giới đại dương đang chờ bạn</div></div>
  <div class="mlist" id="mlist">
   <button class="mb b1" data-m="peace" style="--i:0"><i class="mi">🐠</i><span><b>Thủy Cung Bình Yên</b><small>Nuôi cá · chăm sóc · thư giãn</small></span><u>›</u></button>
   <button class="mb b2" data-m="camp" style="--i:1"><i class="mi">⚔️</i><span><b>Hải Vực Chinh Phục</b><small id="mcsub">60 ải · 20 Boss khổng lồ</small></span><u>›</u></button>
   <button class="mb b3" data-m="surv" style="--i:2"><i class="mi">💀</i><span><b>Sinh Tồn</b><small>Đang phát triển</small></span><em>Sắp ra mắt</em></button>
   <div class="mrow"><button class="mb b4" data-m="set" style="--i:3"><i class="mi">⚙️</i><span><b>Cài Đặt</b></span></button><button class="mb b5" data-m="guide" style="--i:4"><i class="mi">📖</i><span><b>Hướng Dẫn</b></span></button></div>
  </div>
  <div class="mfoot">Phiên bản 16 · Chạm vào các bạn cá để chào hỏi 👋</div>
 </div></div>
<div id="xf"></div>
<div class="ov" id="svm"><div class="pn svp"><div class="svi">💀</div><h3>Sinh Tồn</h3><p>Chế độ Sinh Tồn hiện đang được phát triển.<br>Hẹn gặp bạn trong bản cập nhật tiếp theo!</p><div class="svb"><i></i><i></i><i></i><i></i><i></i></div><button class="m p" id="svok">Đã hiểu</button></div></div>`;
  while(d.firstChild)document.body.appendChild(d.firstChild);
  $('mlogo').innerHTML='Cá Voi Nhỏ'.split('').map((ch,i)=>`<span style="--k:${i}">${ch==' '?'&nbsp;':ch}</span>`).join('');
})();

const MENU={run:false,raf:0,last:0,w:0,h:0,dpr:1,U:1,mx:.5,my:.5,sx:.5,sy:.5,intro:0,chars:[],bub:[],mote:[],hearts:[],ghost:[],weeds:[],corals:[],bg:{p:new Image(),l:new Image()},chatT:2,sch:[]};
MENU.bg.p.src='bg-port.jpg';MENU.bg.l.src='bg-land.jpg';
const mcv=$('mc'),mx2=mcv.getContext('2d');
const MLINES=['Chọn chế độ đi nè!','Hải Vực Chinh Phục khó lắm đó!','Ai mới tới thế? Chào nha 👋','Hôm nay biển đẹp ghê','Sinh Tồn sắp ra mắt đó!','Bơi vòng vòng cho vui','Nước hôm nay mát ghê~','Chạm vào tui đi, tui hiền!','Cho tui thức ăn đi mà','Lên level thôi nào!'];
const MQ={war:['Sẵn sàng chiến Boss chưa?','60 ải, tui không sợ!'],sup:['Đã có tui hồi máu!','Ai đói báo tui nha'],crab:['Xu đâu xu đâu?','Cua đi ngang cho ngầu']};
function mrr(X,x,y,w,h,r){X.beginPath();X.moveTo(x+r,y);X.arcTo(x+w,y,x+w,y+h,r);X.arcTo(x+w,y+h,x,y+h,r);X.arcTo(x,y+h,x,y,r);X.arcTo(x,y,x+w,y,r);X.closePath()}
function mHeart(X,x,y,r,a){X.save();X.globalAlpha=a;X.translate(x,y);X.scale(r/10,r/10);X.fillStyle='#ff6b9a';X.strokeStyle='#fff';X.lineWidth=1.6;X.beginPath();X.moveTo(0,8);X.bezierCurveTo(-14,-2,-8,-12,0,-5);X.bezierCurveTo(8,-12,14,-2,0,8);X.closePath();X.fill();X.stroke();X.restore()}
function mResize(){
  const dpr=Math.max(.5,Math.min(devicePixelRatio||1,1.5)*QDPR[QL]);MENU.dpr=dpr;MENU.w=innerWidth;MENU.h=innerHeight;mcv.width=Math.round(MENU.w*dpr);mcv.height=Math.round(MENU.h*dpr);
  MENU.U=Math.max(.8,Math.min(1.6,Math.min(MENU.w,MENU.h)/420));const w=MENU.w,h=MENU.h,U=MENU.U;
  MENU.weeds=Array.from({length:Math.round(w/34)},(_,i)=>({x:(i+Math.random()*.8)*w/Math.round(w/34),h:R(60,150)*U,ph:R(0,6),c:['#2fae7a','#3cc79a','#1f9a8a','#56d6a0'][i%4],w:R(5,9)*U}));
  MENU.corals=Array.from({length:Math.max(5,Math.round(w/90))},(_,i)=>({x:(i+.3+Math.random()*.4)*w/Math.max(5,Math.round(w/90)),s:R(.7,1.3)*U,c:['#ff7aa8','#ffa05e','#c58cff','#ff8f7a','#7ad7ff'][i%5],ph:R(0,6),k:i%3}));
  // lớp tĩnh vẽ sẵn 1 lần (vignette + lớp cát) → mỗi khung chỉ còn drawImage
  const vc=document.createElement('canvas');vc.width=Math.ceil(w/2);vc.height=Math.ceil(h/2);const vx=vc.getContext('2d'),vg=vx.createRadialGradient(vc.width/2,vc.height*.45,Math.min(vc.width,vc.height)*.3,vc.width/2,vc.height*.5,Math.max(vc.width,vc.height)*.75);vg.addColorStop(0,'rgba(0,20,50,0)');vg.addColorStop(1,'rgba(0,20,50,.5)');vx.fillStyle=vg;vx.fillRect(0,0,vc.width,vc.height);MENU.vgc=vc;
  const sc=document.createElement('canvas');sc.width=Math.ceil(w/2);sc.height=Math.ceil(70*U/2);const sx=sc.getContext('2d'),sg=sx.createLinearGradient(0,0,0,sc.height);sg.addColorStop(0,'rgba(210,190,140,0)');sg.addColorStop(1,'rgba(216,196,148,.85)');sx.fillStyle=sg;sx.fillRect(0,0,sc.width,sc.height);MENU.sandc=sc;
  if(!MENU.chars.length)mChars();
}
function mChars(){
  const w=MENU.w,h=MENU.h,U=MENU.U,C=MENU.chars;
  const mk=(kind,o)=>C.push(Object.assign({kind,x:R(.1,.9)*w,y:R(.3,.85)*h,vx:0,vy:0,tx:R(.1,.9)*w,ty:R(.3,.85)*h,dir:1,ph:R(0,6),say:null,rep:null,id:'m'+C.length,hit:0},o));
  for(let i=0;i<3;i++)mk('fish',{size:30*U+i*4,name:['Bông','Mochi','Cốm'][i],cf:{ph:R(0,1)}});
  mk('war',{size:112*U,name:'Kiếm Sĩ',role:'war'});mk('war',{size:100*U,name:'Thần Tốc',role:'war'});mk('sup',{size:92*U,name:'Hải Mã',role:'sup'});
  mk('crab',{size:78*U,name:'Càng Bự',role:'crab',y:h-34*U,ty:h-34*U});
  MENU.sch=Array.from({length:3},(_,g)=>({x:R(0,w),y:R(.2,.7)*h,dir:g%2?-1:1,sp:R(24,40),n:5,fs:Array.from({length:5},(_,i)=>({cf:{ph:R(0,1)},ox:-i*26*U-R(0,10),oy:R(-14,14)*U}))}));
  MENU.ghost=[0,1,2].map(i=>({id:[5,16,12,18,8,3][Math.floor(Math.random()*6)],x:R(0,w),y:R(.12,.42)*h,dir:i%2?-1:1,sp:R(6,14),sc:R(.5,.8)}));
}
function mBurst(x,y,n){for(let i=0;i<(n||8);i++)MENU.bub.push({x:x+R(-14,14),y:y+R(-6,6),r:R(2,6),vy:R(-30,-80),ph:R(0,6),life:R(1.5,3)})}
function mSay(o,t,l){o.say={t,l:l||3}}
function mUpdate(dt){
  const w=MENU.w,h=MENU.h,U=MENU.U;t+=dt;MENU.intro=Math.min(1,MENU.intro+dt/1.8);
  MENU.sx+=(MENU.mx-MENU.sx)*Math.min(1,dt*3);MENU.sy+=(MENU.my-MENU.sy)*Math.min(1,dt*3);
  if(Math.random()<dt*5&&MENU.bub.length<46)MENU.bub.push({x:R(0,w),y:h+10,r:R(1.5,5),vy:R(-24,-60),ph:R(0,6),life:9});
  for(let i=MENU.bub.length-1;i>=0;i--){const b=MENU.bub[i];b.y+=b.vy*dt;b.life-=dt;if(b.y<-10||b.life<=0)MENU.bub.splice(i,1)}
  for(let i=MENU.hearts.length-1;i>=0;i--){const q=MENU.hearts[i];q.y-=40*dt;q.l-=dt;if(q.l<=0)MENU.hearts.splice(i,1)}
  for(const g of MENU.ghost){g.x+=g.dir*g.sp*dt;if(g.x>w+160)g.x=-160;if(g.x<-160)g.x=w+160}
  for(const s of MENU.sch){s.x+=s.dir*s.sp*dt;s.y+=Math.sin(t*.5+s.sp)*8*dt;if(s.x>w+200)s.x=-200;if(s.x<-200)s.x=w+200}
  for(const o of MENU.chars){
    o.hit-=dt;if(o.say){o.say.l-=dt;if(o.say.l<=0)o.say=null}if(o.rep){o.rep.d-=dt;if(o.rep.d<=0){o.say={t:o.rep.t,l:3};o.rep=null}}
    const bot=o.kind=='crab';
    if(Math.hypot(o.tx-o.x,o.ty-o.y)<30||Math.random()<dt*.05){o.tx=R(.06,.94)*w;o.ty=bot?h-34*U:R(.22,.9)*h}
    const dx=o.tx-o.x,dy=bot?0:o.ty-o.y,d=Math.hypot(dx,dy)||1,sp=(o.kind=='fish'?62:o.kind=='crab'?34:46)*U;
    o.vx+=(dx/d*sp-o.vx)*dt*1.2;o.vy+=(dy/d*sp-o.vy)*dt*1.2;o.x+=o.vx*dt;o.y+=o.vy*dt;if(!bot)o.y=cl(o.y,h*.18,h-60*U);o.x=cl(o.x,20,w-20);
    if(Math.abs(o.vx)>6)o.dir=o.vx>0?1:-1;
  }
  MENU.chatT-=dt;
  if(MENU.chatT<=0){MENU.chatT=R(2,4);const C=MENU.chars,free=C.filter(o=>!o.say&&!o.rep);if(free.length){const o=free[Math.floor(Math.random()*free.length)],near=C.filter(q=>q!==o&&!q.say&&!q.rep&&Math.hypot(q.x-o.x,q.y-o.y)<300*U);
    if(near.length&&Math.random()<.6){const q=near[Math.floor(Math.random()*near.length)],L=typeof DLG!='undefined'&&DLG[(o.role||'fish')+'>'+(q.role||'fish')];
      if(L){const p=L[Math.floor(Math.random()*L.length)];mSay(o,fmtN(p[0],q),3.2);q.rep={t:fmtN(p[1][Math.floor(Math.random()*p[1].length)],o),d:1.7};return}}
    const L=o.kind=='fish'?MLINES:MQ[o.kind];mSay(o,L[Math.floor(Math.random()*L.length)])}}
}
function mDraw(){
  const X=mx2,w=MENU.w,h=MENU.h,U=MENU.U,dpr=MENU.dpr,px=MENU.sx-.5,py=MENU.sy-.5,ik=1-Math.pow(1-MENU.intro,3);
  X.setTransform(dpr,0,0,dpr,0,0);X.globalAlpha=1;X.globalCompositeOperation='source-over';
  // 1. nền đại dương (trôi chậm + thở nhẹ + hiệu ứng zoom khi vào menu)
  const im=w>h?MENU.bg.l:MENU.bg.p,zm=(1.1+.02*Math.sin(t*.3))*(1+.22*(1-ik));
  if(im.complete&&im.naturalWidth){const k=Math.max(w/im.naturalWidth,h/im.naturalHeight)*zm,iw=im.naturalWidth*k,ih=im.naturalHeight*k;X.drawImage(im,(w-iw)/2-px*18+Math.sin(t*.1)*10,(h-ih)/2-py*12,iw,ih)}
  else{const g=X.createLinearGradient(0,0,0,h);g.addColorStop(0,'#4cc3f0');g.addColorStop(1,'#0b4f80');X.fillStyle=g;X.fillRect(0,0,w,h)}
  X.fillStyle='rgba(6,40,80,.28)';X.fillRect(0,0,w,h);
  // 2. tia sáng đại dương
  X.globalCompositeOperation='lighter';
  if(!MENU.rayG||MENU.rayH!==h){const g=X.createLinearGradient(0,0,0,h*.95);g.addColorStop(0,'rgba(190,240,255,.20)');g.addColorStop(1,'rgba(190,240,255,0)');MENU.rayG=g;MENU.rayH=h}
  const nR=[6,4,2,0][QL];for(let i=0;i<nR;i++){const x0=(i+.5)/nR*w+Math.sin(t*.25+i*2)*50-px*30,wd=(40+i%3*26)*U,sk=Math.sin(t*.2+i)*90+80;X.fillStyle=MENU.rayG;X.beginPath();X.moveTo(x0-wd,-10);X.lineTo(x0+wd,-10);X.lineTo(x0+wd+sk+60,h);X.lineTo(x0-wd+sk-60,h);X.closePath();X.fill()}
  X.globalCompositeOperation='source-over';
  // 3. Boss mờ ảo lấp ló phía xa
  for(const g of MENU.ghost){X.save();X.globalAlpha=.17*ik;X.translate(g.x-px*14,g.y+Math.sin(t*.4+g.x*.01)*10);X.scale(g.dir*g.sc*U,g.sc*U);try{ART[g.id](X,60,t,{c:BD[g.id].c,cast:0,ph:0,look:1})}catch(e){}X.restore()}
  // 4. đàn cá nhỏ phía xa
  if(CF.state==='ready'){for(const s of MENU.sch){X.globalAlpha=.8;for(const f of s.fs){const fx0=s.x+f.ox*s.dir-px*22,fy0=s.y+f.oy+Math.sin(t*2+f.ox)*4;cfStep(f.cf,1/40,s.dir*s.sp*1.4,Math.sin(t*2+f.ox)*8,s.dir,0,13*U);cfRender(X,f.cf,fx0,fy0,13*U,'n',null)}}X.globalAlpha=1}
  // 5. phù du lấp lánh
  X.fillStyle='#fff';for(let i=0;i<34;i++){const x=((i*97.3+t*(4+i%5))%(w+20))-10-px*26,y=(i*61.7+Math.sin(t*.6+i)*14)%h;X.globalAlpha=.25+.3*Math.sin(t*2+i);X.beginPath();X.arc(x,y,1+i%3*.5,0,7);X.fill()}X.globalAlpha=1;
  // 6. san hô & rong biển (nhấp nhô theo sóng)
  const fl=h;X.fillStyle='rgba(20,70,90,.0)';
  X.drawImage(MENU.sandc,0,h-70*U,w,70*U);
  for(const c0 of MENU.corals){const bx=c0.x-px*30,by=fl-6*U,s=c0.s;X.strokeStyle=c0.c;X.lineCap='round';X.lineWidth=7*s;
    const br=(x,y,a,l,dp)=>{const sw=Math.sin(t*1.2+c0.ph+dp)*.06,ex=x+Math.cos(a+sw)*l,ey=y+Math.sin(a+sw)*l;X.beginPath();X.moveTo(x,y);X.lineTo(ex,ey);X.stroke();if(dp<2){br(ex,ey,a-.5,l*.65,dp+1);br(ex,ey,a+.5,l*.65,dp+1)}else{X.fillStyle='#fff8';X.beginPath();X.arc(ex,ey,3*s,0,7);X.fill()}};
    if(c0.k==0){br(bx,by,-Math.PI/2,34*s,0)}else if(c0.k==1){X.fillStyle=c0.c;X.beginPath();X.ellipse(bx,by-14*s,26*s,18*s,0,Math.PI,0);X.fill();X.strokeStyle='#ffffff55';X.lineWidth=2;for(let i=-2;i<=2;i++){X.beginPath();X.arc(bx+i*9*s,by-12*s,6*s,Math.PI,0);X.stroke()}}
    else{for(let i=-1;i<=1;i++){br(bx+i*10*s,by,-Math.PI/2+i*.25,26*s,1)}}}
  for(const wd of MENU.weeds){const bx=wd.x-px*40,N=9;X.strokeStyle=wd.c;X.lineWidth=wd.w;X.lineCap='round';X.beginPath();for(let i=0;i<=N;i++){const u=i/N,sw=Math.sin(t*1.4+wd.ph-u*3)*u*u*26*U,x=bx+sw,y=fl-u*wd.h;i?X.lineTo(x,y):X.moveTo(x,y)}X.stroke()}
  // 7. nhân vật bơi qua lại
  for(const o of MENU.chars){const k=o.hit>0?1+.15*Math.sin(o.hit*30):1;
    const sx=o.x-px*(o.kind=='crab'?44:24),sy=o.y-py*10;
    if(o.kind=='fish'){if(CF.state==='ready'){cfStep(o.cf,1/40,o.vx,o.vy,o.dir,o.say?1:0,o.size*.5);cfRender(X,o.cf,sx,sy,o.size*.5,'n',null)}}
    else{const im=img(o.kind=='war'?'sword':o.kind=='sup'?'horse':'crab');if(im&&im.naturalWidth){const ww=o.size,hh=ww*im.naturalHeight/im.naturalWidth,bob=Math.sin(t*(o.kind=='crab'?9:2.2)+o.ph)*(o.kind=='crab'?Math.abs(Math.sin(t*9))*3:5);
      X.save();X.translate(sx,sy+bob);if(o.kind=='war')X.rotate(Math.atan2(o.vy,Math.abs(o.vx)+30)*o.dir*.6);X.scale(o.dir*(o.kind=='sup'?-1:1)*k,k);X.drawImage(im,-ww/2,-hh/2,ww,hh);X.restore()}}
  }
  for(const q of MENU.hearts)mHeart(X,q.x,q.y,7+q.l*3,Math.min(1,q.l*1.5));
  // 8. bong bóng
  X.lineWidth=1.3;for(const b of MENU.bub){const x=b.x+Math.sin(t*1.2+b.ph)*7-px*16;X.globalAlpha=.65;X.strokeStyle='#fff';X.fillStyle='rgba(255,255,255,.14)';X.beginPath();X.arc(x,b.y,b.r,0,7);X.fill();X.stroke();X.fillStyle='#fff';X.globalAlpha=.8;X.beginPath();X.arc(x-b.r*.3,b.y-b.r*.3,b.r*.22,0,7);X.fill()}X.globalAlpha=1;
  // 9. bong bóng chat
  X.font='700 12px Montserrat,sans-serif';X.textAlign='center';X.textBaseline='middle';
  for(const o of MENU.chars){if(!o.say)continue;const sy0=o.say;if(!sy0.ls){sy0.ls=wrapT(sy0.t,128);sy0.w=Math.max(...sy0.ls.map(l=>X.measureText(l).width))+20;sy0.h=sy0.ls.length*15+12}
    const bx=cl(o.x-sy0.w/2-px*24,6,w-sy0.w-6),top=o.y-(o.kind=='fish'?o.size*.6:o.size*.6)-8,by=Math.max(8,top-sy0.h-6);X.globalAlpha=Math.min(1,o.say.l*3);X.fillStyle='rgba(255,255,255,.96)';X.strokeStyle='#bcd8ee';X.lineWidth=1.5;mrr(X,bx,by,sy0.w,sy0.h,10);X.fill();X.stroke();
    const tx=cl(o.x-px*24,bx+14,bx+sy0.w-14);X.beginPath();X.moveTo(tx-5,by+sy0.h-.5);X.lineTo(tx+5,by+sy0.h-.5);X.lineTo(tx,by+sy0.h+7);X.closePath();X.fill();X.fillStyle='#35506b';sy0.ls.forEach((l,i)=>X.fillText(l,bx+sy0.w/2,by+6+i*15+7.5))}
  X.globalAlpha=1;
  // 10. tối viền & ánh sáng mở màn
  X.drawImage(MENU.vgc,0,0,w,h);
  if(MENU.intro<1){X.fillStyle='rgba(220,248,255,'+(1-ik)*.85+')';X.fillRect(0,0,w,h)}
}
function mLoop(n){
  if(!MENU.run)return;MENU.raf=requestAnimationFrame(mLoop);const iv=1000/Math.min(45,PF.fps);if(n-MENU.last<iv-2)return;const dt=Math.min(.06,(n-MENU.last)/1000);MENU.last=n;
  try{dfmWarm();mUpdate(dt);mDraw()}catch(e){console.error(e)}
  MENU.fn=(MENU.fn||0)+1;if(!MENU.ft)MENU.ft=n;if(n-MENU.ft>=1000){qGov(MENU.fn*1000/(n-MENU.ft),Math.min(45,PF.fps),n);MENU.fn=0;MENU.ft=n}
}
MENU.start=()=>{if(MENU.run)return;MENU.run=true;MENU.last=performance.now();MENU.intro=0;mResize();MENU.raf=requestAnimationFrame(mLoop)};
MENU.stop=()=>{MENU.run=false;cancelAnimationFrame(MENU.raf)};
addEventListener('resize',()=>{if(MENU.run){MENU.chars=[];mResize()}});
function menuQ(){if(MENU.run){MENU.chars.length=0;mResize()}}
document.addEventListener('visibilitychange',()=>{if(document.hidden)MENU.stop();else if($('menu').classList.contains('on'))MENU.start()});
mcv.addEventListener('pointermove',e=>{MENU.mx=e.clientX/MENU.w;MENU.my=e.clientY/MENU.h});
mcv.addEventListener('pointerdown',e=>{   // chạm vào nhân vật → chào lại + thả tim; chạm nước → bong bóng
  let hit=null;for(const o of MENU.chars){const d=Math.hypot(o.x-e.clientX,o.y-e.clientY);if(d<o.size*.7+10&&(!hit||d<hit.d))hit={o,d}}
  if(hit){const o=hit.o;o.hit=.35;mSay(o,(o.kind=='fish'?['Hi hi!','Nhột quá~','Chào bạn!','Yêu bạn 💗']:MQ[o.kind]).slice().sort(()=>Math.random()-.5)[0],2.4);for(let i=0;i<3;i++)MENU.hearts.push({x:o.x+R(-16,16),y:o.y-20,l:1.1});mBurst(o.x,o.y,6);if(AC&&S.snd!='off')ting()}
  else mBurst(e.clientX,e.clientY,7)});

// ---------- chuyển chế độ ----------
const bodyCls=(c,on)=>document.body.classList.toggle(c,on);
function xfade(el,fn){
  const f=$('xf'),r=el?el.getBoundingClientRect():{left:innerWidth/2,top:innerHeight/2,width:0,height:0};
  f.style.setProperty('--x',(r.left+r.width/2)+'px');f.style.setProperty('--y',(r.top+r.height/2)+'px');f.classList.add('in');
  setTimeout(()=>{try{fn()}finally{requestAnimationFrame(()=>f.classList.remove('in'))}},560);
}
function resetClock(){last=performance.now();lastDraw=last;acc=0}
function menuShow(){
  MODE='menu';bodyCls('inmenu',true);bodyCls('incamp',false);const m=$('menu');m.classList.remove('intro');void m.offsetWidth;m.classList.add('on','intro');
  const st=campStats();$('mcsub').textContent=st.done?'✅ '+st.done+'/60 ải · ⭐ '+st.st+'/180':'60 ải · 20 Boss khổng lồ';MENU.start();
}
function menuHide(){$('menu').classList.remove('on');MENU.stop();bodyCls('inmenu',false)}
function goPeace(el){xfade(el,()=>{menuHide();MODE='peace';resetClock();say('Chạm màn hình để thả thức ăn 🍤 · vuốt ve cá để thả tim 💗');
  if(!localStorage.getItem('whale_guided')){setTimeout(()=>{openGuide();try{localStorage.setItem('whale_guided','1')}catch(e){}},700)}})}
function goMenu(){if(MODE==='camp'){$('chexit').onclick();return}save();menuShow()}
function beginCampLevel(L){xfade(null,()=>{$('lvsel').classList.remove('on');$('lvinfo').classList.remove('on');$('cres').classList.remove('on');
  if(!campStart(L)){menuShow();return}menuHide();bodyCls('incamp',true);resetClock();campHud(true)})}
function leaveCamp(){if(MODE==='camp')campExit();bodyCls('incamp',false);$('cres').classList.remove('on');menuShow();openLvSel()}
$('mlist').addEventListener('click',e=>{
  const b=e.target.closest('.mb');if(!b)return;const m=b.dataset.m;b.classList.remove('pop');void b.offsetWidth;b.classList.add('pop');
  const r=b.getBoundingClientRect();mBurst(r.left+r.width/2,r.top+r.height/2,12);
  if(m=='peace')goPeace(b);else if(m=='camp')openLvSel();else if(m=='surv')$('svm').classList.add('on');else if(m=='set')openSet();else if(m=='guide')openGuide();
});
$('mlist').addEventListener('pointerover',e=>{const b=e.target.closest('.mb');if(b&&b!==MENU.hov){MENU.hov=b;const r=b.getBoundingClientRect();mBurst(r.left+r.width*(.2+Math.random()*.6),r.top+r.height/2,4);if(AC&&S.snd!='off'&&e.pointerType=='mouse')ting()}});
$('mlist').addEventListener('pointerleave',()=>{MENU.hov=null});
$('svok').onclick=()=>$('svm').classList.remove('on');
$('svm').addEventListener('pointerdown',e=>{if(e.target==$('svm'))$('svm').classList.remove('on')});
menuShow();
$('menub').onclick=goMenu;
