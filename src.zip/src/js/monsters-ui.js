// ---- Bảng thông tin quái vật: 4 quái Thủy Cung · 20 Boss Hải Vực Chinh Phục · quái phụ (quái con, phân thân)
let mTab='a';
const SKI={heal:'💚',pulse:'💥',stunall:'⚡',hole:'🌀',laser:'🔴',summon:'👥',shield:'🛡️',meteor:'☄️',poison:'☠️',clone:'🪞',dash:'💨',burst:'🌵',leech:'🩸'};
const SKD={heal:'Tự hồi 6–10% máu trong ~2 giây (ánh sáng xanh lá)',pulse:'Sóng xung kích quanh người: gây sát thương và làm choáng 1,6 giây',stunall:'Tích tụ năng lượng 2,4 giây (có cảnh báo) rồi làm choáng TOÀN BẢN ĐỒ 2,6 giây, rung màn hình',hole:'Hố đen 4 giây hút mọi đơn vị về phía Boss, chạm vào bị sát thương',laser:'Ngắm 1,5 giây (đường cảnh báo đỏ) rồi bắn tia năng lượng xuyên màn hình',summon:'Triệu hồi quái con (tối đa 4, riêng Hải Vương 6), tồn tại 18 giây',shield:'Khiên hấp thụ 10–14% máu tối đa trong 9 giây (thanh khiên xanh)',meteor:'Hiện vùng cảnh báo đỏ, ~1,7 giây sau thiên thạch rơi gây sát thương và choáng nhẹ',poison:'Tạo vùng nước độc 7 giây gây mất máu theo thời gian',clone:'Tạo 2–3 phân thân giả (10 giây) để đánh lừa, vỡ ngay khi bị đánh',dash:'Báo hiệu rồi lao thẳng vào mục tiêu, gây sát thương và choáng 0,8 giây cho mọi đơn vị trên đường',burst:'Bắn tỏa tròn 10–16 mũi gai theo mọi hướng',leech:'Hút máu tối đa 3 đơn vị gần nhất trong 2,6 giây và hồi máu cho Boss'};
const PHT=['Bình thường','Tăng cường','Cuồng nộ','Bùng nổ'];
function bossLevels(bid){const o=[];for(const l of LV)if(l.wv.flat().includes(bid))o.push(l.n);return o}
function openMInfo(){renderM();$('minfo').classList.add('on')}
function renderM(){
  document.querySelectorAll('#mtabs .chip').forEach(b=>b.classList.toggle('on',b.dataset.t==mTab));
  const intro={a:'Quái vật Thủy Cung xuất hiện ngẫu nhiên theo tỉ lệ bên dưới. Chạm vào <b>hình quái vật</b> để đổi hình (PNG, có cắt ảnh).',b:'20 Boss của chế độ <b>Hải Vực Chinh Phục</b>, chia theo 6 vùng. Máu tăng dần theo ải; mỗi Boss có kỹ năng và giai đoạn riêng.',c:'Các đơn vị phụ do Boss tạo ra trong chế độ Hải Vực Chinh Phục.'}[mTab];
  $('mintro').innerHTML=intro;let h='';
  if(mTab=='a'){
    const bg={green:'#e4f6ee',blue:'#e2f0fb',purple:'#efeafd',red:'#ffe4e0'};
    for(const k of MK){const m=MON[k],cust=G['m'+k].sel;
      h+=`<div class="fc mc" style="background:${bg[k]}"><div class="mcv"><canvas class="mth" data-k="${k}" width="96" height="96"></canvas><small>✏️ Chạm để đổi hình</small>${cust?`<button class="rs" data-reset="${k}">↺ Hình gốc</button>`:''}</div><div class="fi"><b class="mn">${m.n}</b><div class="fa">❤️ Máu: <b>${m.hp}</b></div><div class="fa">⚔️ Sát thương: <b>${m.dmg}</b> mỗi lần đánh (~1,2 giây/lần)</div><div class="fa">🏃 Tốc độ: <b>${k=='red'?48:55}</b></div><div class="fa">🐟 Nuốt cá sau <b>4,5 giây</b> tiếp xúc</div><div class="bar"><label>🎲 Xuất hiện</label><span class="bg"><i style="width:${m.p}%;background:${m.c2}"></i></span><em>${m.p}%</em></div><div class="fa">🪙 Thưởng khi diệt: <b>${m.rw}</b></div><div class="fa sm2">Ưu tiên mục tiêu gần nhất: Chiến Binh, Support, Cua hoặc cá (cua bị nhắm ít hơn)</div></div></div>`}
  }else if(mTab=='b'){
    let zc=-1;
    BD.forEach((d,i)=>{
      if(d.z!==zc){zc=d.z;const Z=ZONES[zc];h+=`<div class="mzh" style="--z1:${Z.c1};--z2:${Z.c2}"><i>${Z.ic}</i><b>Vùng ${zc+1} · ${Z.n}</b><small>${Z.d}</small></div>`}
      const Z=ZONES[d.z],lv=bossLevels(i),lo=Math.min(...lv),hi=Math.max(...lv),hpA=Math.round(d.hp*LV[lo-1].hpM),hpB=Math.round(d.hp*LV[hi-1].hpM);
      const sks=d.sk.map(s=>`<div class="skc"><i>${SKI[s[0]]}</i><div><b>${SKN[s[0]]}</b><small>${SKD[s[0]]} · hồi chiêu ~${s[1]}s${s[2]?' · từ giai đoạn '+(s[2]+1):''}</small></div></div>`).join('');
      const ph=d.ph.map((p,j)=>`<span>${Math.round(p*100)}% → ${PHT[j+1]}</span>`).join('');
      h+=`<div class="fc bcc" style="--z1:${Z.c1};--z2:${Z.c2}"><div class="mcv"><canvas class="bth" data-b="${i}" width="96" height="96"></canvas><small>Boss ${i+1}/20</small></div><div class="fi"><b class="mn">${i+1}. ${d.nm}</b><div class="tg">${d.tag}</div>
        <div class="fa">❤️ Máu: <b>${nf(hpA)}${hpB!==hpA?' → '+nf(hpB):''}</b> <span class="sm2">(tăng theo ải)</span></div><div class="fa">⚔️ Sát thương chạm: <b>${d.dmg}</b> · 🏃 Tốc độ: <b>${d.spd}</b></div><div class="fa">⏱ Nhịp đánh: <b>${d.atk}s</b> · 🐟 Nuốt cá: <b>${d.eat}s</b></div>
        <div class="fa">🎯 Lối đánh: <b>${d.ai=='k'?'giữ khoảng cách, bắn từ xa':'đuổi sát mục tiêu'}</b></div><div class="fa">🔥 Giai đoạn: <span class="phs">${ph}</span></div><div class="fa">🪙 Thưởng: <b>${d.rw}</b> · 📍 Ải: <b>${lv.length>8?lv.slice(0,8).join(', ')+'…':lv.join(', ')}</b></div>
        <div class="sks">${sks}</div></div></div>`;
    });
  }else{
    h=`<div class="fc bcc" style="--z1:#b6a0d0;--z2:#6a4fc0"><div class="mcv"><canvas class="bth" data-b="8" data-mini="1" width="96" height="96"></canvas><small>Quái phụ</small></div><div class="fi"><b class="mn">Quái con (triệu hồi)</b><div class="tg">Do kỹ năng Triệu hồi tạo ra</div><div class="fa">❤️ Máu: <b>60 + 1,2% máu Boss</b></div><div class="fa">⚔️ Sát thương: <b>30% sát thương Boss</b> · 🏃 Tốc độ: <b>78</b></div><div class="fa">⏳ Tồn tại: <b>18 giây</b> · 👥 Tối đa <b>4</b> (Hải Vương: 6)</div><div class="fa sm2">Biến mất khi Boss chủ bị hạ. Không tính vào điều kiện hạ Boss của ải.</div></div></div>
      <div class="fc bcc" style="--z1:#b6a0d0;--z2:#6a4fc0"><div class="mcv"><canvas class="bth" data-b="9" data-fake="1" width="96" height="96"></canvas><small>Quái phụ</small></div><div class="fi"><b class="mn">Phân thân (ảo ảnh)</b><div class="tg">Do kỹ năng Phân thân tạo ra</div><div class="fa">❤️ Máu: <b>rất thấp</b> (vỡ ngay khi bị đánh)</div><div class="fa">⚔️ Sát thương: <b>không gây sát thương</b></div><div class="fa">⏳ Tồn tại: <b>10 giây</b> · 🪞 Mỗi lần <b>2–3</b> bản sao (hình hơi trong suốt, nhấp nháy)</div><div class="fa sm2">Dùng để đánh lừa Chiến Binh và lượt chạm: hãy nhìn thanh máu và tên Boss.</div></div></div>`;
  }
  $('mcards').innerHTML=h;
  document.querySelectorAll('#mcards .bth').forEach(cv=>{const X=cv.getContext('2d');X.globalAlpha=cv.dataset.fake?.6:1;portrait(cv,+cv.dataset.b,false,cv.dataset.mini?.45:1);X.globalAlpha=1});
}
function drawMThumbs(){
  if(!$('minfo').classList.contains('on')||mTab!=='a')return;
  for(const cvs of document.querySelectorAll('#mcards .mth')){const k=cvs.dataset.k,m=MON[k],x=cvs.getContext('2d');x.clearRect(0,0,cvs.width,cvs.height);drawMon(x,k,48,46+Math.sin(t*2)*2,Math.min(1,30/m.r),t)}
}
setInterval(drawMThumbs,100);
function changeMon(k){const n='m'+k,g=G[n];
  if(g.list.length>=5){say('Đã đủ 5 hình, hãy xoá bớt trong ⚙️ → Hình ảnh');$('minfo').classList.remove('on');tab=n;spane='img';openSet();return}
  pick=n;retTo='minfo';$('file').click()}
$('mcards').addEventListener('click',e=>{
  const r=e.target.closest('[data-reset]');if(r){const n='m'+r.dataset.reset;G[n].sel='';gSave(n);gApply(n);renderM();return}
  const th=e.target.closest('.mth');if(th)changeMon(th.dataset.k)});
$('mtabs').addEventListener('click',e=>{const b=e.target.closest('.chip');if(!b)return;mTab=b.dataset.t;renderM();$('mcards').parentElement.scrollTop=0});
$('miclose').onclick=()=>$('minfo').classList.remove('on');
$('minfo').addEventListener('pointerdown',e=>{if(e.target==$('minfo'))$('minfo').classList.remove('on')});
$('minfob').onclick=openMInfo;
