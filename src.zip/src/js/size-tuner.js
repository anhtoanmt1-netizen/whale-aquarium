// ===== Chỉnh kích thước (px) cho Cá voi / Cá Chiến Binh / Cá Support / Cua — trong ⚙️ → Hình ảnh =====
const SZN={fish:'Cá voi',sword:'Cá Chiến Binh',horse:'Cá Support',crab:'Cua'};
const SZD={fish:'chiều dài cá mới mua',sword:'chiều dài',horse:'chiều cao',crab:'chiều rộng'};
const szLim=k=>[Math.ceil(SZB[k]*(.35-1)),Math.floor(SZB[k]*2)];          // nhỏ nhất 35%, lớn nhất 300% kích thước mặc định
function szDims(k,im,K){const r=im&&im.naturalWidth?im.naturalHeight/im.naturalWidth:.7;
  if(k=='crab'){let w=64*K,h=w*r;if(h>72*K){h=72*K;w=h/r}return{w,h}}
  if(k=='sword'){const w=120*K;return{w,h:w*r}}
  const h=96*K;return{w:h/r,h}}
function szPreview(){
  const cv=$('szpv');if(!cv||!SZB[tab])return;const X=cv.getContext('2d'),PW=cv.width/2,PH=cv.height/2,k=tab;
  X.setTransform(2,0,0,2,0,0);const g=X.createLinearGradient(0,0,0,PH);g.addColorStop(0,'#cfeaff');g.addColorStop(1,'#8fd0f0');X.fillStyle=g;X.fillRect(0,0,PW,PH);
  const im=img(k);let dw,dh,cw,ch;
  if(k=='fish'){dw=SZB.fish;dh=SZB.fish*.62;cw=SZB.fish*SZK.fish;ch=cw*.62}else{const a=szDims(k,im,1),b=szDims(k,im,SZK[k]);dw=a.w;dh=a.h;cw=b.w;ch=b.h}
  const fit=Math.min(1,(PW-16)/Math.max(dw,cw),(PH-26)/Math.max(dh,ch));
  X.save();X.translate(PW/2,PH/2-4);X.scale(fit,fit);
  X.setLineDash([4/fit,3/fit]);X.strokeStyle='#3f8cc6';X.lineWidth=1/fit;X.strokeRect(-dw/2,-dh/2,dw,dh);X.setLineDash([]);   // khung nét đứt = kích thước mặc định
  if(k=='fish'){const L=SZB.fish*SZK.fish;
    if(IM.fish){const z=L*.91;X.drawImage(IM.fish,-z/2,-z/2,z,z)}
    else if(CF.state==='ready'){const s={ph:1};cfStep(s,.03,40,0,1,0,L/2.85);cfRender(X,s,0,0,L/2.85,'n',null)}}
  else if(im&&im.naturalWidth){X.drawImage(im,-cw/2,-ch/2,cw,ch)}
  X.restore();
  X.fillStyle='#2d4a66';X.font='700 10px Montserrat,system-ui,sans-serif';X.textAlign='center';X.fillText('Nét đứt = mặc định'+(fit<1?' · xem thử thu nhỏ ×'+fit.toFixed(2):''),PW/2,PH-6);
}
function szTxt(){
  const k=tab;if(!SZB[k])return;const o=S.sz[k]||0,l=szLim(k),cur=Math.round(SZB[k]+o);
  $('szname').textContent=SZN[k];
  $('szhint').textContent='Mặc định '+SZB[k]+' px ('+SZD[k]+') · hiện tại '+cur+' px ('+(o>0?'+':'')+o+'). Nhập số px muốn tăng (+) hoặc giảm (−), từ '+l[0]+' đến +'+l[1]+'.'+(k=='fish'?' Mỗi lần lớn cá to thêm 25%.':'');
}
function szUI(){const on=!!SZB[tab];$('szbox').style.display=on?'':'none';if(!on)return;$('szin').value=S.sz[tab]||0;szTxt();szPreview()}
function szSet(k,v,typing){
  const l=szLim(k);v=Math.max(l[0],Math.min(l[1],Math.round(+v||0)));S.sz[k]=v;szApply();save();
  if(!typing)$('szin').value=v;szTxt();szPreview()}
$('szin').oninput=e=>{const v=parseInt(e.target.value,10);if(Number.isFinite(v)&&SZB[tab])szSet(tab,v,true)};
$('szin').onchange=e=>{if(SZB[tab])szSet(tab,parseInt(e.target.value,10)||0)};
$('szm').onclick=()=>{if(SZB[tab])szSet(tab,(S.sz[tab]||0)-5)};
$('szp').onclick=()=>{if(SZB[tab])szSet(tab,(S.sz[tab]||0)+5)};
$('szr').onclick=()=>{if(SZB[tab])szSet(tab,0)};
