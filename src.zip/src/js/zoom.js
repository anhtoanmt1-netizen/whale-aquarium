// ---- Tầm nhìn (thu phóng): 0 Gần (như cũ) · 1 Rộng · 2 Siêu rộng. Hồ cá trong game được mở rộng ra, vật thể nhỏ lại tương ứng.
const ZNAME=['🔎 Gần','🔍 Rộng','🔭 Siêu rộng'];
function zoomUI(){
  document.querySelectorAll('#zoom .chip').forEach(b=>b.classList.toggle('on',+b.dataset.z==S.zoom));
  const zb=$('zoomb');if(zb)zb.textContent=['🔎','🔍','🔭'][S.zoom]||'🔎';
}
function remapWorld(kx,ky){   // đổi cỡ khung hình (xoay màn hình / đổi tầm nhìn): co giãn vị trí và mục tiêu của mọi thứ → không đơn vị nào bị kẹt ngoài khung mới
  const mv=a=>{for(const o of a){if(o.x!=null)o.x*=kx;if(o.y!=null)o.y*=ky;if(o.tx!=null)o.tx*=kx;if(o.ty!=null)o.ty*=ky}};
  mv(fish);mv(food);mv(coins);mv(swords);mv(horses);mv(crabs);mv(fx);mv(bubbles);mv(dn);mv(cHeart);mv(bosses);mv(bfx);mv(ambBub);if(alien)mv([alien]);SHL=null;
  for(const L of[swords,horses])for(const o of L)o.stuck=0;
}
function setZoom(z){
  z=Math.max(0,Math.min(2,z|0));if(z===S.zoom&&Z===ZM[z]){zoomUI();return}
  S.zoom=z;Z=ZM[z];resize();   // resize() tự co giãn vị trí theo tỉ lệ khung mới
  save();zoomUI();say('Tầm nhìn: '+ZNAME[z]+(z?' · hồ rộng hơn, mọi thứ nhìn nhỏ lại':' · như ban đầu'));
}
$('zoom').onclick=e=>{const b=e.target.closest('.chip');if(b)setZoom(+b.dataset.z)};
$('zoomb').onclick=()=>setZoom((S.zoom+1)%3);
zoomUI();
