// ---- Tầm nhìn (thu phóng): 0 Gần (như cũ) · 1 Rộng · 2 Siêu rộng. Hồ cá trong game được mở rộng ra, vật thể nhỏ lại tương ứng.
const ZNAME=['🔎 Gần','🔍 Rộng','🔭 Siêu rộng'];
function zoomUI(){
  document.querySelectorAll('#zoom .chip').forEach(b=>b.classList.toggle('on',+b.dataset.z==S.zoom));
  const zb=$('zoomb');if(zb)zb.textContent=['🔎','🔍','🔭'][S.zoom]||'🔎';
}
function setZoom(z){
  z=Math.max(0,Math.min(2,z|0));if(z===S.zoom&&Z===ZM[z]){zoomUI();return}
  const ow=W,oh=H;S.zoom=z;Z=ZM[z];resize();
  const kx=W/ow,ky=H/oh,mv=a=>{for(const o of a){if(o.x!=null)o.x*=kx;if(o.y!=null)o.y*=ky;if(o.tx!=null)o.tx*=kx;if(o.ty!=null)o.ty*=ky}};
  mv(fish);mv(food);mv(coins);mv(swords);mv(horses);mv(crabs);mv(fx);mv(bubbles);mv(dn);mv(cHeart);if(alien)mv([alien]);SHL=null;
  save();zoomUI();say('Tầm nhìn: '+ZNAME[z]+(z?' · hồ rộng hơn, mọi thứ nhìn nhỏ lại':' · như ban đầu'));
}
$('zoom').onclick=e=>{const b=e.target.closest('.chip');if(b)setZoom(+b.dataset.z)};
$('zoomb').onclick=()=>setZoom((S.zoom+1)%3);
zoomUI();
